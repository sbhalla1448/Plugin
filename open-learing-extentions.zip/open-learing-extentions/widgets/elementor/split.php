<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Split_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'split';
	}

	/**
	 * Get widget split.
	 *
	 * Retrieve button widget split.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget split.
	 */
	public function get_title() {
		return esc_html__( 'Split', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <div class="rbt-split-area overflow-hidden">
            <div class="container-fluid g-0">
                <div class="rbt-splite-style">
                    <div class="split-wrapper">
                        <div class="row g-0 align-items-center">
                            <div class="col-lg-12 col-xl-6 col-12">
                                <div class="thumbnail image-left-content">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/split/split-02.jpg" alt="split Images">
                                </div>
                            </div>
                            <div class="col-lg-12 col-xl-6 col-12">
                                <div class="split-inner text-start">
                                    <div class="shape">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/workout.png" alt="Shape Images">
                                    </div>
                                    <h2 class="title sal-animate">Become Your Strongest Self</h2>
                                    <p class="description sal-animate">Histudy we prepare you to launch your career by providing a supportive, creative, and professional environment from which to learn practical skills, build a network of industry contacts.</p>
                                    <ul class="split-list sal-animate">
                                        <li>- Doug DeMarco, Design Prototyping Manager</li>
                                        <li>- 108 million paying subscribers</li>
                                        <li>- Over 1.7 billion hours of music played monthly</li>
                                        <li>- 4,000+ employees working across 16 offices</li>
                                    </ul>
                                    <div class="view-more-button mt--35 sal-animate">
                                        <a class="rbt-btn btn-gradient rbt-marquee-btn radius-round" href="#">
                                            <span data-text="Let's Trian Now">Let's Trian Now</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
		<div class="rbt-split-area bg-color-white overflow-hidden rbt-section-gapTop">
			<div class="wrapper">
				<div class="rbt-splite-style">
					<div class="split-wrapper">
						<div class="row g-0 align-items-center">
							<div class="col-lg-12 col-xl-6 col-12">
								<div class="thumbnail image-left-content">
									<img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/split/split-01.jpg" alt="split Images">
								</div>
							</div>
							<div class="col-lg-12 col-xl-6 col-12">
								<div class="split-inner">
									<div class="shape">
										<img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/school.png" alt="Shape Images">
									</div>
									<h4 class="title sal-animate">Campus Information</h4>
									<p class="description sal-animate">Histudy we prepare you to launch your career by providing a supportive, creative, and professional environment from which to learn practical skills, build a network of industry contacts.</p>
									<ul class="split-list sal-animate">
										<li>- Doug DeMarco, Design Prototyping Manager</li>
										<li>- 108 million paying subscribers</li>
										<li>- Over 1.7 billion hours of music played monthly</li>
										<li>- 4,000+ employees working across 16 offices</li>
									</ul>
									<div class="view-more-button mt--35 sal-animate">
										<a class="rbt-moderbt-btn" href="#">
											<span class="moderbt-btn-text">Schedule A Tour</span>
											<i class="feather-arrow-right"></i>
										</a>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Split_Widget() );