jQuery(document).ready(function($){
   // show additional requirement
   $(document).on('click','#additional_requirement_switch-input',function(){
      let $this = $(this)
      console.log('checked')
      if( $this.is(':checked') ) {
         $('.additional_requirements_area').show('slow')
      } else {
         $('.additional_requirements_area').hide()
      }
   })
   // show the billing address for parents
   $(document).on('click','input[name="student-billing"]',function(){
      let $this = $(this)
      let checkbox = $this.closest('.checkbox')
      $('.checkbox').removeClass('is-active')
      checkbox.addClass('is-active')
      if( $this.is(':checked') && $this.val() == "parent" ) {
         $('#billing_details_container').show('slow')
      } else {
         $('#billing_details_container').hide()
      }
   })
   // show the discount
   $(document).on('click','#discount-code-btn',function(){
      $('.discount-code').show()
   })
})