<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Counter_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'counter';
	}

	/**
	 * Get widget counter.
	 *
	 * Retrieve button widget counter.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget counter.
	 */
	public function get_title() {
		return esc_html__( 'Counter', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'counter_contents',
            [
                'label' => esc_html__('Counter Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 6, '');
        $this->text_control('_style_1_title', 'Title', null, array(
            '_style'        => 'style_1'
        ));
        $this->switch_control('_switch', null, null, array(
            '_style' => 'style_6'
        ));
        $this->switch_control('_show_cta', 'Show Call To Action', null, array(
            '_style' => 'style_1'
        ));
        $this->switch_control('_show_text', 'Show Text', null, array(
            '_style' => 'style_1'
        ));
        $this->text_control('_style_1_text', 'Text', null, array(
            '_style'        => 'style_1',
            '_show_text'    => 'yes'
        ));
        
        $this->repeater_controls('style_3_counter_list', 'Counter List', 
            array(
                array(
                    'name'      => 'counter_image',
                    'label'     => esc_html__( 'Counter Image', 'open-learning-ex' ),
                    'type'      => \Elementor\Controls_Manager::MEDIA,
                    'default'   => array(
                        'url'   => \Elementor\Utils::get_placeholder_image_src()
                    )
                ),
                array(
                    'name' => 'number_of_count',
                    'label' => esc_html__( 'Number of count', 'open-learning-ex' ),
                    'type' => \Elementor\Controls_Manager::NUMBER,
                    'default' => 0
                ),
                array(
                    'group'     => \Elementor\Group_Control_Typography::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Number of count text typography', 'open-learning-ex' ),
                        'name'      => 'number_of_text_typo',
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .odometer',
                    )
                ),
                array(
                    'name' => 'number_of_count_color',
                    'label' => esc_html__( 'Number of count color', 'open-learning-ex' ),
                    'type' => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .counter' => 'color: {{VALUE}}',
                    ],
                ),
                array(
                    'name' => 'counter_text',
                    'label' => esc_html__( 'Counter Text', 'open-learning-ex' ),
                    'type' => \Elementor\Controls_Manager::TEXT,
                    'default' => esc_html__('Your text...', 'open-learning-ex')
                ),
                array(
                    'group'     => \Elementor\Group_Control_Typography::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Counter text typography', 'open-learning-ex' ),
                        'name'      => 'counter_text_typo',
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .subtitle',
                    )
                ),
                array(
                    'name'  => 'counter_text_color',
                    'label' => esc_html__( 'Counter text color', 'open-learning-ex' ),
                    'type'  => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{WRAPPER}} {{CURRENT_ITEM}} .subtitle' => 'color: {{VALUE}}',
                    ],
                ),
                array(
                    'group'     => \Elementor\Group_Control_Background::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Background', 'open-learning-ex' ),
                        'name'      => 'counter_background',
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-counterup',
                    )
                ),
                array(
                    'group'     => \Elementor\Group_Control_Box_Shadow::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Box Shadow', 'open-learning-ex' ),
                        'name'      => 'counter_box_shadow',
                        'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-counterup',
                    )
                ),
            ), 
            array(
                array(
                    'counter_image'   => array(
                        'url'         => get_theme_file_uri() . '/assets/images/icons/counter-01.png'
                    ),
                    'number_of_count' => 0,
                    'counter_text'    => esc_html__('Learners &amp; counting', 'open-learning-ex')
                ),
                array(
                    'counter_image'   => array(
                        'url'         => get_theme_file_uri() . '/assets/images/icons/counter-02.png'
                    ),
                    'number_of_count' => 0,
                    'counter_text'    => esc_html__('Courses & Video', 'open-learning-ex')
                ),
                array(
                    'counter_image'   => array(
                        'url'         => get_theme_file_uri() . '/assets/images/icons/counter-03.png'
                    ),
                    'number_of_count' => 0,
                    'counter_text'    => esc_html__('Certified Students', 'open-learning-ex')
                ),
                array(
                    'counter_image'   => array(
                        'url'         => get_theme_file_uri() . '/assets/images/icons/counter-04.png'
                    ),
                    'number_of_count' => 0,
                    'counter_text'    => esc_html__('Certified Students', 'open-learning-ex')
                )
            )
        );

        $this->end_controls_section();

        $this->start_controls_section(
            'counter_right_contents',
            [
                'label' => esc_html__('Right Content Controls', 'open-learning-ex'),
            ]
        );

        $this->text_control('style_3_right_badge_text', 'Badge Text', 'Why Choose Us', array(
            '_style'        => 'style_3'
        ));

        $this->textarea_control('style_3_right_title', 'Title Text', 'Creating A Community Of <br /> Life Long Learners.', array(
            '_style'        => 'style_3'
        ));

        $this->textarea_control('style_3_right_description', 'Description', 'There are many variations of passages of the Ipsum available, but the majority have suffered alteration in some form, by injected humour.', array(
            '_style'        => 'style_3'
        ));

        $this->repeater_controls('style_3_feautures_list', 'Feautes List', 
            array(
                array(
                    'name'      => 'list_icon',
                    'label'     => esc_html__( 'Icon', 'open-learning-ex' ),
                    'type'      => \Elementor\Controls_Manager::ICONS,
                    'default'   => array(
                        'value' => 'fas fa-heart',
					    'library' => 'fa-solid',
                    )
                ),
                array(
                    'group'     => \Elementor\Group_Control_Background::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Icon Background', 'open-learning-ex' ),
                        'name'      => 'icon_background',
                        'selector'  => '{{ WRAPPER }} .rbt-feature .icon',
                    )
                ),
                array(
                    'group'     => \Elementor\Group_Control_Typography::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'Icon typography', 'open-learning-ex' ),
                        'name'      => 'icon_typo',
                        'selector'  => '{{ WRAPPER }} .rbt-feature .icon i',
                    )
                ),
                array(
                    'name'  => 'list_text',
                    'label' => esc_html__( 'List text', 'open-learning-ex' ),
                    'type'  => \Elementor\Controls_Manager::TEXTAREA,
                    'default' => esc_html__('Your text...', 'open-learning-ex')
                ),
                array(
                    'group'     => \Elementor\Group_Control_Typography::get_type(),
                    'args'      => array(
                        'label'     => esc_html__( 'List text typography', 'open-learning-ex' ),
                        'name'      => 'list_text_typo',
                        'selector'  => '{{ WRAPPER }} .rbt-feature .feature-content .feature-title',
                    )
                ),
                array(
                    'name'  => 'list_text_color',
                    'label' => esc_html__( 'List text color', 'open-learning-ex' ),
                    'type'  => \Elementor\Controls_Manager::COLOR,
                    'selectors' => [
                        '{{ WRAPPER }} .rbt-feature .feature-content .feature-title' => 'color: {{VALUE}}',
                    ],
                )
            ), 
            array(
                array(
                    'list_text' => esc_html__('Flexible Classes', 'open-learning-ex')
                ),
                array(
                    'list_text' => esc_html__('Flexible Classes', 'open-learning-ex')
                ),
                array(
                    'list_text' => esc_html__('Flexible Classes', 'open-learning-ex')
                ),
            )
        );

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section Styles', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
                'label'     => esc_html__( 'Section Background', 'open-learning-ex' ),
				'name'      => 'section_background',
				'selector'  => '{{ WRAPPER }} .rbt-counterup-area',
			]
		);

        $this->end_controls_section();

        $this->start_controls_section(
			'right_contents_style',
			[
				'label' => esc_html__( 'Right Contents Styles', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Badge Typography', 'open-learning-ex' ),
				'name'      => 'badge_typo',
				'selector'  => '{{ WRAPPER }} .rbt-counterup-area .section-title .subtitle',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
                'label'     => esc_html__( 'Badge Background', 'open-learning-ex' ),
				'name'      => 'badge_background',
				'selector'  => '{{ WRAPPER }} .rbt-counterup-area .section-title .subtitle',
			]
		);

        $this->add_control(
			'badge_color',
			[
				'label' => esc_html__( 'Badge text color', 'open-learning-ex' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{ WRAPPER }} .rbt-counterup-area .section-title .subtitle' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Title typography', 'open-learning-ex' ),
				'name'      => 'title_typo',
				'selector'  => '{{ WRAPPER }} .rbt-counterup-area .section-title .title',
			]
		);

        $this->add_control(
			'title_color',
			[
				'label' => esc_html__( 'Title color', 'open-learning-ex' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{ WRAPPER }} .rbt-counterup-area .section-title .title' => 'color: {{VALUE}}',
				],
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Description typography', 'open-learning-ex' ),
				'name'      => 'description_typo',
				'selector'  => '{{ WRAPPER }} .rbt-counterup-area .section-title .description',
			]
		);

        $this->add_control(
			'description_color',
			[
				'label' => esc_html__( 'Description color', 'open-learning-ex' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{ WRAPPER }} .rbt-counterup-area .section-title .description' => 'color: {{VALUE}}',
				],
			]
		);

        $this->end_controls_section();
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
            $wrapper_class = 'bg-gradient-1';
		?>
        <?php if( $settings['_show_cta'] == 'yes' ): 
            $wrapper_class = 'bg-color-extra2 default-callto-action-overlap';
        ?>
        <!-- Start Call To Action  -->
        <div class="rbt-callto-action-area mt_dec--half">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12 col-xl-5">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">New Collection</a>
                                        </div>
                                        <h4 class="title mb--15">Online Courses from Histudy</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-xl-7">
                                    <div class="video-popup-wrapper mt_lg--10 mt_md--20 mt_sm--20">
                                        <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-01.jpg" alt="Video Images">
                                        <a class="rbt-btn rounded-player-2 sm-size popup-video position-to-top with-animation" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                            <span class="play-icon"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">Top Teacher</a>
                                        </div>
                                        <h4 class="title mb--10">Free Online Courses from Histudy School To Education</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                        <div class="read-more-btn">
                                            <a class="rbt-btn rbt-switch-btn btn-gradient btn-sm" href="#">
                                                <span data-text="Join Now">Join Now</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Call To Action  -->
        <?php endif; ?>
		<!-- Start Counterup Area  -->
        <div class="rbt-counterup-area <?php echo esc_attr($wrapper_class); ?>">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">Why Choose Us</span>
                            <h2 class="title"><?php echo wp_kses_post($settings['_style_1_title']); ?></h2>
                            <?php if( $settings['_show_text'] == 'yes' ): ?>
                            <p class="description has-medium-font-size mt--20 mb--0"><?php echo wp_kses_post($settings['_style_1_text']); ?></p>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="row g-5 hanger-line">
                    <!-- Start Single Counter  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                            <div class="top-circle-shape"></div>
                            <div class="inner">
                                <div class="rbt-round-icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/counter-01.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h3 class="counter"><span class="odometer" data-count="500">00</span>
                                    </h3>
                                    <span class="subtitle">Learners &amp; counting</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->

                    <!-- Start Single Counter  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--60 mt_md--30 mt_sm--30 mt_mobile--60">
                        <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                            <div class="top-circle-shape"></div>
                            <div class="inner">
                                <div class="rbt-round-icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/counter-02.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h3 class="counter"><span class="odometer" data-count="800">00</span>
                                    </h3>
                                    <span class="subtitle">Courses & Video</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->

                    <!-- Start Single Counter  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt_md--60 mt_sm--60">
                        <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                            <div class="top-circle-shape"></div>
                            <div class="inner">
                                <div class="rbt-round-icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/counter-03.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h3 class="counter"><span class="odometer" data-count="1000">00</span>
                                    </h3>
                                    <span class="subtitle">Certified Students</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->

                    <!-- Start Single Counter  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--60 mt_md--60 mt_sm--60">
                        <div class="rbt-counterup rbt-hover-03 border-bottom-gradient">
                            <div class="top-circle-shape"></div>
                            <div class="inner">
                                <div class="rbt-round-icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/counter-04.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h3 class="counter"><span class="odometer" data-count="100">00</span>
                                    </h3>
                                    <span class="subtitle">Registered Enrolls</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->
                </div>
            </div>
        </div>
        <!-- End Counterup Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>

        <div class="rbt-counterup-area bg_image bg_image_fixed bg_image--20 ptb--170 bg-black-overlay" data-black-overlay="2">
            <div class="conter-style-2">
                <div class="container">
                    <div class="row g-5">
                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="500">00</span>
                                        </h3>
                                        <span class="subtitle">Learners &amp; counting</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="800">00</span>
                                        </h3>
                                        <span class="subtitle">Courses & Video</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="1000">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="100">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <script>
            (function($){
                "use strict";

                var odo = $('.odometer');
                odo.each(function() {
                    $('.odometer').appear(function(e) {
                        var countNumber = $(this).attr('data-count');
                        $(this).html(countNumber);
                    });
                });
            })(jQuery)
        </script>
        <div class="rbt-counterup-area">
            <div class="conter-style-2">
                <div class="container">
                    <div class="row g-5 align-items-center">
                        <div class="col-lg-6 order-2 order-lg-1">
                            <div class="row row--30">
                                <?php
                                $count_loop = 0;
                                $counter_class = '';
                                foreach( $settings['_style_3_counter_list'] as $counter ): 
                                ?>
                                <!-- Start Single Counter  -->
                                <div class="col-lg-6 col-md-6 col-sm-6 col-12 mt--60 <?php echo 'elementor-repeater-item-' . esc_attr( $counter['_id'] ); ?>">
                                    <div class="rbt-counterup rbt-hover-03">
                                        <div class="inner">
                                            <div class="icon">
                                                <img src="<?php echo esc_url($counter['counter_image']['url']); ?>" alt="<?php echo \Elementor\Control_Media::get_image_alt($counter['counter_image']); ?>">
                                            </div>
                                            <div class="content">
                                                <h3 class="counter"><span class="odometer" data-count="<?php echo esc_html($counter['number_of_count']); ?>">00</span>
                                                </h3>
                                                <span class="subtitle"><?php echo esc_html($counter['counter_text']); ?></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Counter  -->
                                <?php $count_loop++; endforeach; ?>
                            </div>
                        </div>
                        <div class="col-lg-6 order-1 order-lg-2">
                            <div class="inner pl--50 pl_sm--0 pl_md--0">
                                <div class="section-title text-start">
                                    <span class="subtitle badge-title"><?php echo esc_html($settings['style_3_right_badge_text']); ?></span>
                                    <h2 class="title"><?php echo wp_kses_post($settings['style_3_right_title']); ?></h2>
                                    <p class="description mt--20 mb--0"><?php echo wp_kses_post($settings['style_3_right_description']); ?></p>
                                </div>

                                <div class="rbt-feature-wrapper mt--30">
                                    <?php foreach($settings['_style_3_feautures_list'] as $item): ?>
                                    <div class="rbt-feature feature-style-1 align-items-center">
                                        <div class="icon list-icon">
                                           <?php \Elementor\Icons_Manager::render_icon( $item['list_icon'], array('area-hidden' => 'true') ); ?>
                                        </div>
                                        <div class="feature-content">
                                            <h6 class="feature-title"><?php echo esc_html($item['list_text']); ?></h6>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-counterup-area bg_image bg_image_fixed bg_image--18 ptb--170 ptb_md--50 ptb_sm--50 bg-black-overlay" data-black-overlay="1">
            <div class="conter-style-2">
                <div class="container">
                    <div class="row g-5">
                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="500">00</span>
                                        </h3>
                                        <span class="subtitle">Learners &amp; counting</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="800">00</span>
                                        </h3>
                                        <span class="subtitle">Courses & Video</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="1000">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="100">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <div class="rbt-counterup-area bg_image bg_image_fixed bg_image--18 ptb--170 ptb_md--50 ptb_sm--50 bg-black-overlay" data-black-overlay="1">
            <div class="conter-style-2">
                <div class="container">
                    <div class="row g-5">
                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="500">00</span>
                                        </h3>
                                        <span class="subtitle">Learners &amp; counting</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="800">00</span>
                                        </h3>
                                        <span class="subtitle">Courses & Video</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="1000">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->

                        <!-- Start Single Counter  -->
                        <div class="col-lg-3 col-md-6 col-sm-6 col-12 single-counter">
                            <div class="rbt-counterup style-2">
                                <div class="inner">
                                    <div class="content">
                                        <h3 class="counter"><span class="odometer" data-count="100">00</span>
                                        </h3>
                                        <span class="subtitle">Certified Students</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Counter  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_6' ): 
            $wrapper_class = 'bg-color-white rbt-section-gapTop';
            if( $settings['_switch'] == 'yes' ){
                $wrapper_class = 'bg-gradient-6 rbt-section-gap';
            }
        ?>
        <div class="rbt-counterup-area <?php echo esc_attr($wrapper_class); ?>">
            <div class="container">
                <?php if($settings['_switch'] == 'yes'): ?>
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title"><span class="theme-gradient">Why</span> Choose My Courses</h2>
                            <p class="description has-medium-font-size mt--20">Learning new technology, data sience,
                                university, communicate to global world and build a bright future with our histudy.</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row g-5">
                    <!-- Start Single Counter  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-counterup style-3">
                            <div class="inner">
                                <div class="content">
                                    <h2 class="counter"><span class="odometer" data-count="500">00</span>
                                    </h2>
                                    <span class="subtitle">Learners &amp; counting</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->

                    <!-- Start Single Counter  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-counterup style-3">
                            <div class="inner">
                                <div class="content">
                                    <h2 class="counter"><span class="odometer" data-count="800">00</span>
                                    </h2>
                                    <span class="subtitle">Courses & Video</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->

                    <!-- Start Single Counter  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-counterup style-3">
                            <div class="inner">
                                <div class="content">
                                    <h2 class="counter"><span class="odometer" data-count="1000">00</span>
                                    </h2>
                                    <span class="subtitle">Certified Students</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Counter  -->
                </div>
            </div>
        </div>

		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Counter_Widget() );