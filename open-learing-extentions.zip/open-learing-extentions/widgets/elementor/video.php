<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Video_Widget extends OLX_Wc_Base_Widget {
    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'video';
	}

	/**
	 * Get widget video.
	 *
	 * Retrieve button widget video.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget video.
	 */
	public function get_title() {
		return esc_html__( 'Video', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Left Contents', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '', 'style_1');
        $this->text_control('_section_subtitle', 'Subtitle', 'How We Work', array(
            '_style'    => 'style_1'
        ));
        $this->textarea_control('_section_title', 'Title', 'Build your Career And Upgrade Your Life', array(
            '_style'    => 'style_1'
        ));
        $this->textarea_control('_section_description', 'Description', 'Far far away, behind the word mountains, far from the
        countries Vokalia and Consonantia, there live the blind texts. Separated they live in
        Bookmarksgrove right at the coast of the Semantics, a large language ocean.', array(
            '_style'    => 'style_1'
        ));
        $this->text_control('_section_btn_text', 'Button text', 'Learn More About Us', array(
            '_style'    => 'style_1'
        ));
        $this->url_control('_section_btn_link', 'Button link', '#', array(
            '_style'    => 'style_1'
        ));

        $this->end_controls_section();

        $this->start_controls_section(
            'section_content_2',
            [
                'label' => esc_html__('Right Contents', 'open-learning-ex'),
            ]
        );
        $this->url_control('_video_link', 'Video link', '#', array(
            '_style'    => 'style_1'
        ));
        $this->image_control('_video_thumbnail', 'Video thumbnail', array(
            '_style'    => 'style_1'
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_section_subtitle_typo', 'Subtitle typography', '.rbt-video-area .section-title .subtitle');
        $this->color_control('_section_subtitle_color', 'Subtitle color', '.rbt-video-area .section-title .subtitle');
        $this->background_control('_section_subtitle_back', 'Subtitle background', '.rbt-video-area .section-title .subtitle');

        $this->typography_control('_section_title_typo', 'Title typography', '.rbt-video-area .section-title .title');
        $this->color_control('_section_title_color', 'Title color', '.rbt-video-area .section-title .title');

        $this->typography_control('_section_des_typo', 'Description typography', '.rbt-video-area .section-title .description');
        $this->color_control('_section_des_color', 'Description color', '.rbt-video-area .section-title .description');


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
		<!-- Start Button Area  -->
        <div class="rbt-video-area">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 order-2 order-lg-1">
                        <div class="inner pr--50">
                            <div class="section-title text-start">
                                <span class="subtitle"><?php echo esc_html($settings['_section_subtitle']); ?></span>
                                <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                                <p class="description mt--30"><?php echo wp_kses_post($settings['_section_description']); ?></p>
                                <div class="read-more-btn">
                                    <a class="rbt-moderbt-btn" href="<?php echo esc_html($settings['_section_btn_link']); ?>">
                                        <span class="moderbt-btn-text"><?php echo esc_html($settings['_section_btn_text']); ?></span>
                                        <i class="feather-arrow-right"></i>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2">
                        <div class="video-popup-wrapper">
                            <img class="w-100 rbt-radius" src="<?php echo esc_url($settings['_video_thumbnail']['url']); ?>" alt="Video Images">
                            <a class="popup-video position-to-top" href="<?php echo esc_url($settings['_video_link']['url']); ?>">
                                <span><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/youtube.png" alt=""></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Button Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
         <!-- Start Video Area  -->
        <div class="rbt-video-area">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="video-popup-wrapper">
                            <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/bg/bg-image-12.jpg" alt="Video Images">
                            <a class="rbt-btn rounded-player-2 popup-video position-to-top with-animation btn-theme-color" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                <span class="play-icon"></span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Video Area  -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Video_Widget() );