<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Testimonial_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'testimonial';
	}

	/**
	 * Get widget testimonial.
	 *
	 * Retrieve button widget testimonial.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget testimonial.
	 */
	public function get_title() {
		return esc_html__( 'Testimonial', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 8, '');

        $this->add_control(
			'_bg',
			[
				'label' 		=> esc_html__( 'Choose Background', 'open-learning-ex' ),
				'type' 			=> Controls_Manager::SELECT,
				'default' 		=> 'bg-color-white rbt-section-gapBottom',
				'options' 		=> array(
					'bg-color-white rbt-section-gapBottom' 	=> esc_html__( 'Background 1', 'open-learning-ex' ),
					'bg-color-extra2 rbt-section-gap' 	=> esc_html__( 'Background 2', 'open-learning-ex' ),
				),
				'condition' 	=> array(
                    '_style' => 'style_6'
                )
			]
		);

        $this->switch_control('_show_title', 'Show Title', 'yes', array(
            '_style' => 'style_5'
        ));

        $this->text_control('_section_subtitle', 'Subtitle', 'EDUCATION FOR EVERYONE', array(
            '_style'    => 'style_5'
        ));
        $this->textarea_control('_section_title', 'Title', 'People like histudy education. <br /> No joking - here’s the proof!', array(
            '_style'    => 'style_5'
        ));

        $this->end_controls_section();

        $this->start_controls_section(
            'testimonial_content',
            [
                'label' => esc_html__('Testimonial Content Controls', 'open-learning-ex'),
            ]
        );

        $this->repeater_controls('author_list', 'Author List', array(
            array(
                'name'  => '_author_image',
                'label' => 'Author Image',
                'type'  => \Elementor\Controls_Manager::MEDIA
            ),
            array(
                'name'  => '_author_name',
                'label' => 'Author Name',
                'type'  => \Elementor\Controls_Manager::TEXT
            ),
            array(
                'name'  => '_author_designation',
                'label' => 'Author Designation',
                'type'  => \Elementor\Controls_Manager::TEXTAREA
            ),
            array(
                'name'  => '_author_description',
                'label' => 'Author Description',
                'type'  => \Elementor\Controls_Manager::TEXTAREA
            ),
            array(
                'name'  => '_author_link',
                'label' => 'Author Link',
                'type'  => \Elementor\Controls_Manager::TEXT
            ),
        ), array(
            array(
                '_author_name' => 'Aditya Amin',
                '_author_designation' => 'Wordpress Plugin & Theme Developer',
                '_author_description' => 'Wordpress custom theme development with elementor page builder compatibility and also develop wordpress plugins for specific needs.'
            )
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_section_subtitle_typo', 'Subtitle typography', '.rbt-testimonial-area .section-title .subtitle');
        $this->color_control('_section_subtitle_color', 'Subtitle color', '.rbt-testimonial-area .section-title .subtitle');
        $this->background_control('_section_subtitle_background', 'Subtitle Background', '.rbt-testimonial-area .section-title .subtitle');

        $this->typography_control('_section_title_typo', 'Title typography', '.rbt-testimonial-area .section-title .title');
        $this->color_control('_section_title_color', 'Title color', '.rbt-testimonial-area .section-title .title');


        $this->end_controls_section();

        $this->start_controls_section(
			'testimonial_style',
			[
				'label' => esc_html__( 'Testimonial Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->background_control('_author_box', 'Author Box', '.rbt-testimonial-box .inner');
        $this->boxshadow_control('_author_box_shadow', 'Author Box Shadow', '.rbt-testimonial-box .inner');

        $this->typography_control('_author_name_typo', 'Author name typography', '.rbt-testimonial-box .client-info .title');
        $this->color_control('_author_name_color', 'Author name color', '.rbt-testimonial-box .client-info .title');

        $this->typography_control('_author_info_typo', 'Author info typography', '.rbt-testimonial-box .client-info span');
        $this->color_control('_author_info_color', 'Author info color', '.rbt-testimonial-box .client-info span');

        $this->typography_control('_author_des_typo', 'Author Description typography', '.rbt-testimonial-box .description p.subtitle-3');
        $this->color_control('_author_des_color', 'Author Description color', '.rbt-testimonial-box .description p.subtitle-3');

        $this->typography_control('_author_link_typo', 'Author Link typography', '.rbt-testimonial-box .description .rbt-btn-link');
        $this->color_control('_author_link_color', 'Author Link color', '.rbt-testimonial-box .description .rbt-btn-link');


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <!-- Start Testimonial Area   -->
        <div class="rbt-testimonial-area bg-color-white rbt-section-gap overflow-hidden">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title text-center mb--10">
                                <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                                <h2 class="title">People like histudy education. <br /> No joking - here’s the proof!</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="scroll-animation-wrapper no-overlay mt--50">
                <div class="scroll-animation scroll-right-left">

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/facebook.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Martha Maldonado, <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/google.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Histudy education, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Michael D., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/yelp.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Valerie J., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/facebook.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">People says about, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-04.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Hannah R., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/bing.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Like this histudy, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-05.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Pearl B. Hill, <span>Marketing</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/facebook.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Educational template, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Mandy F. Wood, <span>SR Designer</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/hubs.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Online leaning, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-07.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Mildred W. Diaz, <span>Executive</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/bing.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Remote learning, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-08.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Christopher, <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-odd">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/yelp.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">University managemnet, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Fatima, <span>Child</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                </div>
            </div>

            <div class="scroll-animation-wrapper no-overlay mt--30">
                <div class="scroll-animation scroll-left-right">

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/facebook.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Martha Maldonado, <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/google.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Histudy education, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Michael D., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/yelp.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Valerie J., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/bing.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">People says about, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-04.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Hannah R., <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/hubs.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Like this histudy, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-05.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Pearl B. Hill, <span>Marketing</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/yelp.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Educational template, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Mandy F. Wood, <span>SR Designer</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/bing.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Online leaning, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-07.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Mildred W. Diaz, <span>Executive</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/facebook.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Remote learning, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-08.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Christopher, <span>CEO</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 bg-theme-gradient-even">
                        <div class="rbt-testimonial-box style-2">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/yelp.png" alt="Clint Images">
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">University managemnet, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="clint-info-wrapper">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="Clint Images">
                                        </div>
                                        <div class="client-info">
                                            <h5 class="title">Fatima, <span>Child</span></h5>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                </div>
            </div>
        </div>
        <!-- End Testimonial Area   -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>

        <div class="rbt-testimonial-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mb--60">
                        <div class="section-title text-center">
                            <h2 class="title">Student's Feedback</h2>
                            <p class="description mt--20">Learning communicate to global world and build a bright future and career development, increase your skill with our histudy.</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial-item-3-activation swiper rbt-arrow-between gutter-swiper-30">
                    <div class="swiper-wrapper">

                        <!-- Start Single Testimonial  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-testimonial-box">
                                    <div class="inner bg-no-shadow bg-color-primary-opacity">
                                        <div class="clint-info-wrapper">
                                            <div class="thumb">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                            </div>
                                            <div class="client-info">
                                                <h5 class="title">Martha Maldonado</h5>
                                                <span>Executive Chairman <i>@ Google</i></span>
                                            </div>
                                        </div>
                                        <div class="description">
                                            <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                                auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                            <div class="rating mt--20">
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial  -->

                        <!-- Start Single Testimonial  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-testimonial-box">
                                    <div class="inner bg-no-shadow bg-color-primary-opacity">
                                        <div class="clint-info-wrapper">
                                            <div class="thumb">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Clint Images">
                                            </div>
                                            <div class="client-info">
                                                <h5 class="title">Michael D. Lovelady</h5>
                                                <span>CEO <i>@ Google</i></span>
                                            </div>
                                        </div>
                                        <div class="description">
                                            <p class="subtitle-3">Histudy education, vulputate at sapien sit amet,
                                                auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                            <div class="rating mt--20">
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial  -->

                        <!-- Start Single Testimonial  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-testimonial-box">
                                    <div class="inner bg-no-shadow bg-color-primary-opacity">
                                        <div class="clint-info-wrapper">
                                            <div class="thumb">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                            </div>
                                            <div class="client-info">
                                                <h5 class="title">Valerie J. Creasman</h5>
                                                <span>Executive Designer <i>@ Google</i></span>
                                            </div>
                                        </div>
                                        <div class="description">
                                            <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                                auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                            <div class="rating mt--20">
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial  -->

                        <!-- Start Single Testimonial  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-testimonial-box">
                                    <div class="inner bg-no-shadow bg-color-primary-opacity">
                                        <div class="clint-info-wrapper">
                                            <div class="thumb">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                            </div>
                                            <div class="client-info">
                                                <h5 class="title">Valerie J. Creasman</h5>
                                                <span>Executive Designer <i>@ Google</i></span>
                                            </div>
                                        </div>
                                        <div class="description">
                                            <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                                auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                            <div class="rating mt--20">
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial  -->

                        <!-- Start Single Testimonial  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-testimonial-box">
                                    <div class="inner bg-no-shadow bg-color-primary-opacity">
                                        <div class="clint-info-wrapper">
                                            <div class="thumb">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                            </div>
                                            <div class="client-info">
                                                <h5 class="title">Valerie J. Creasman</h5>
                                                <span>Executive Designer <i>@ Google</i></span>
                                            </div>
                                        </div>
                                        <div class="description">
                                            <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                                auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                            <div class="rating mt--20">
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                                <a href="#"><i class="fa fa-star"></i></a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Testimonial  -->
                    </div>

                    <div class="rbt-swiper-arrow rbt-arrow-left">
                        <div class="custom-overfolow">
                            <i class="rbt-icon feather-arrow-left"></i>
                            <i class="rbt-icon-top feather-arrow-left"></i>
                        </div>
                    </div>

                    <div class="rbt-swiper-arrow rbt-arrow-right">
                        <div class="custom-overfolow">
                            <i class="rbt-icon feather-arrow-right"></i>
                            <i class="rbt-icon-top feather-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="rbt-testimonial-area bg-color-light rbt-section-gap overflow-hidden">
            <div class="wrapper mb--60">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title text-center">
                                <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                                <h2 class="title">People like histudy education. <br /> No joking - Parents Review Here!</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container">
                <div class="row align-items-center row--30">
                    <div class="col-lg-6">
                        <!-- Start Tab Content  -->
                        <div class="rbt-testimonial-content tab-content" id="myTabContent">
                            <div class="tab-pane fade active show" id="testimonial-tab1" role="tabpanel" aria-labelledby="testimonial-tab1-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Histudy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab2" role="tabpanel" aria-labelledby="testimonial-tab2-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Nira </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab3" role="tabpanel" aria-labelledby="testimonial-tab3-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Rafiq The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Jone Jane </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab4" role="tabpanel" aria-labelledby="testimonial-tab4-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Janen The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Janen Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab5" role="tabpanel" aria-labelledby="testimonial-tab5-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Afrin The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Afrin </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab6" role="tabpanel" aria-labelledby="testimonial-tab6-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Education The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab7" role="tabpanel" aria-labelledby="testimonial-tab7-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Mohima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Mohima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab8" role="tabpanel" aria-labelledby="testimonial-tab8-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Nuha The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Nuha </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>
                        </div>
                        <!-- End Tab Content  -->
                    </div>
                    <div class="col-lg-6 mt_md--30 mt_sm--30">
                        <!-- Start Tab Nav  -->
                        <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                            <li>
                                <a class="active" id="testimonial-tab1-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab1" role="tab" aria-controls="testimonial-tab1" aria-selected="true">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-1.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab2-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab2" role="tab" aria-controls="testimonial-tab2" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-2.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab3-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab3" role="tab" aria-controls="testimonial-tab3" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-3.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a id="testimonial-tab4-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab4" role="tab" aria-controls="testimonial-tab4" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-4.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab5-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab5" role="tab" aria-controls="testimonial-tab5" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-5.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab6-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab6" role="tab" aria-controls="testimonial-tab6" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-6.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab7-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab7" role="tab" aria-controls="testimonial-tab7" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-7.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-8.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <!-- End Tab Content  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-testimonial-area bg-color-white rbt-section-gap overflow-hidden" id="testimonial">
            <div class="container">
                <div class="row align-items-center row--30">
                    <div class="col-lg-6">
                        <!-- Start Tab Content  -->
                        <div class="rbt-testimonial-content tab-content" id="myTabContent">
                            <div class="tab-pane fade active show" id="testimonial-tab1" role="tabpanel" aria-labelledby="testimonial-tab1-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Histudy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab2" role="tabpanel" aria-labelledby="testimonial-tab2-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Nira </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab3" role="tabpanel" aria-labelledby="testimonial-tab3-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Rafiq The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Jone Jane </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab4" role="tabpanel" aria-labelledby="testimonial-tab4-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Janen The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Janen Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab5" role="tabpanel" aria-labelledby="testimonial-tab5-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Afrin The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Afrin </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab6" role="tabpanel" aria-labelledby="testimonial-tab6-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Education The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab7" role="tabpanel" aria-labelledby="testimonial-tab7-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Mohima The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Mohima Asrafy </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="testimonial-tab8" role="tabpanel" aria-labelledby="testimonial-tab8-tab">
                                <div class="inner">
                                    <div class="rating mb--30">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <p>Nuha The standard chunk of Lorem Ipsum used since the 1500s is reproduced
                                        below for those interested. Sections Bonorum et Malorum original.</p>
                                </div>
                                <div class="author-info">
                                    <h6><span>Nuha </span> - COO, AMERIMAR ENTERPRISES, INC.</h6>
                                </div>
                            </div>
                        </div>
                        <!-- End Tab Content  -->
                    </div>
                    <div class="col-lg-6 mt_md--30 mt_sm--30">
                        <!-- Start Tab Nav  -->
                        <ul class="testimonial-thumb-wrapper nav nav-tabs" id="myTab" role="tablist">
                            <li>
                                <a class="active" id="testimonial-tab1-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab1" role="tab" aria-controls="testimonial-tab1" aria-selected="true">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-1.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab2-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab2" role="tab" aria-controls="testimonial-tab2" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-2.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab3-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab3" role="tab" aria-controls="testimonial-tab3" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-3.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a id="testimonial-tab4-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab4" role="tab" aria-controls="testimonial-tab4" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-4.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab5-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab5" role="tab" aria-controls="testimonial-tab5" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-5.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab6-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab6" role="tab" aria-controls="testimonial-tab6" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-6.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab7-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab7" role="tab" aria-controls="testimonial-tab7" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-7.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="testimonial-tab8-tab" data-bs-toggle="tab" data-bs-target="#testimonial-tab8" role="tab" aria-controls="testimonial-tab8" aria-selected="false">
                                    <div class="testimonial-thumbnai">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/testimonial-8.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>
                        </ul>
                        <!-- End Tab Content  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): 
            
            $style_5_classes = 'mt_dec--120 mt_lp_dec--30 mt_lg_dec--30 mt_md_dec--30 mt_sm_dec--30';
            if( $settings['_show_title'] == 'yes' ){
                $style_5_classes = '';
            }
            
        ?>
        <div class="rbt-testimonial-area overflow-hidden <?php echo esc_attr($style_5_classes); ?>">
            <?php if($settings['_show_title'] == 'yes'): ?>
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="section-title text-center">
                                <span class="subtitle"><?php echo esc_html($settings['_section_subtitle']); ?></span>
                                <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endif; ?>
            <div class="scroll-animation-wrapper mt--50">
                <div class="scroll-animation scroll-right-left">
                    <?php foreach($settings['_author_list'] as $author): ?>
                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 <?php echo 'elementor-repeater-item-' . esc_attr( $author['_id'] ); ?>">
                        <div class="rbt-testimonial-box">
                            <div class="inner">
                                <div class="clint-info-wrapper">
                                    <div class="thumb">
                                        <img src="<?php echo esc_url($author['_author_image']['url']); ?>" alt="<?php echo esc_attr($author['_author_name']); ?>">
                                    </div>
                                    <div class="client-info">
                                        <h5 class="title"><?php echo esc_html($author['_author_name']); ?></h5>
                                        <span><?php echo esc_html($author['_author_designation']); ?></span>
                                    </div>
                                </div>
                                <div class="description">
                                    <p class="subtitle-3"><?php echo esc_html($author['_author_description']); ?></p>
                                    <a class="rbt-btn-link" href="<?php echo esc_url($author['_author_link']); ?>">Read Project Case Study<i
                                    class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <?php endforeach; ?>
                </div>
            </div>

            <div class="scroll-animation-wrapper mt--50">
                <div class="scroll-animation scroll-left-right">
                    <?php foreach($settings['_author_list'] as $author): ?>
                    <!-- Start Single Testimonial  -->
                    <div class="single-column-20 <?php echo 'elementor-repeater-item-' . esc_attr( $author['_id'] ); ?>">
                        <div class="rbt-testimonial-box">
                            <div class="inner">
                                <div class="clint-info-wrapper">
                                    <div class="thumb">
                                        <img src="<?php echo esc_url($author['_author_image']['url']); ?>" alt="<?php echo esc_attr($author['_author_name']); ?>">
                                    </div>
                                    <div class="client-info">
                                        <h5 class="title"><?php echo esc_html($author['_author_name']); ?></h5>
                                        <span><?php echo esc_html($author['_author_designation']); ?></span>
                                    </div>
                                </div>
                                <div class="description">
                                    <p class="subtitle-3"><?php echo esc_html($author['_author_description']); ?></p>
                                    <a class="rbt-btn-link" href="<?php echo esc_url($author['_author_link']); ?>">Read Project Case Study<i
                                    class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <div class="rbt-testimonial-area <?php echo esc_attr( $settings['_bg'] ); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mb--60">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                            <h2 class="title">Student's Feedback</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Testimonial  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-testimonial-box">
                            <div class="inner">
                                <div class="clint-info-wrapper">
                                    <div class="thumb">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                    </div>
                                    <div class="client-info">
                                        <h5 class="title">Martha Maldonado</h5>
                                        <span>Executive Chairman <i>@ Google</i></span>
                                    </div>
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus velit.</p>
                                    <div class="rating mt--20">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-testimonial-box">
                            <div class="inner">
                                <div class="clint-info-wrapper">
                                    <div class="thumb">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Clint Images">
                                    </div>
                                    <div class="client-info">
                                        <h5 class="title">Michael D. Lovelady</h5>
                                        <span>CEO <i>@ Google</i></span>
                                    </div>
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Histudy education, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                    <div class="rating mt--20">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->

                    <!-- Start Single Testimonial  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-testimonial-box">
                            <div class="inner">
                                <div class="clint-info-wrapper">
                                    <div class="thumb">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                    </div>
                                    <div class="client-info">
                                        <h5 class="title">Valerie J. Creasman</h5>
                                        <span>Executive Designer <i>@ Google</i></span>
                                    </div>
                                </div>
                                <div class="description">
                                    <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget.</p>
                                    <div class="rating mt--20">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Testimonial  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
        <div class="rbt-testimonial-area bg-color-white ptb--100 overflow-hidden">
            <div class="container-fluid">
                <div class="row g-5 align-items-center">
                    <div class="col-xl-3">
                        <div class="section-title pl--100 pl_sm--30">
                            <h2 class="title">What My Learners <span class="theme-gradient">Say</span></h2>
                            <p class="description mt--20">Learning communicate to global world and build a bright future with our histudy.</p>
                            <div class="veiw-more-btn mt--20">
                                <a class="rbt-btn btn-gradient rbt-marquee-btn marquee-text-y" href="#">
                                    <span data-text="Learn More">
                                        Learn More
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <div class="col-xl-9">
                        <div class="overflow-hidden">
                            <div class="scroll-animation-wrapper pt--50 pb--30">
                                <div class="scroll-animation scroll-right-left">

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Martha Maldonado</h5>
                                                        <span>Executive Chairman <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Michael D. Lovelady</h5>
                                                        <span>CEO <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Histudy education, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-03.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Valerie J. Creasman</h5>
                                                        <span>Executive Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Our educational, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-04.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Hannah R. Sutton</h5>
                                                        <span>Executive Chairman <i>@ Facebook</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">People says about, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->
                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-05.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Pearl B. Hill</h5>
                                                        <span>Chairman SR <i>@ Facebook</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Like this histudy, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mandy F. Wood</h5>
                                                        <span>SR Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Educational template, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-07.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mildred W. Diaz</h5>
                                                        <span>Executive Officer <i>@ Yelp</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Online leaning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-08.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Christopher H. Win</h5>
                                                        <span>Product Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Remote learning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Martha Maldonado</h5>
                                                        <span>Executive Chairman <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">University managemnet, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->
                                </div>
                            </div>
                            <div class="scroll-animation-wrapper pb--50">
                                <div class="scroll-animation scroll-left-right">

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Martha Maldonado</h5>
                                                        <span>Executive Chairman <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">University managemnet, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-08.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Christopher H. Win</h5>
                                                        <span>Product Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Remote learning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-07.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mildred W. Diaz</h5>
                                                        <span>Executive Officer <i>@ Yelp</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Online leaning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mandy F. Wood</h5>
                                                        <span>SR Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Educational template, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-05.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Pearl B. Hill</h5>
                                                        <span>Chairman SR <i>@ Facebook</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Like this histudy, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mandy F. Wood</h5>
                                                        <span>SR Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Educational template, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-07.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Mildred W. Diaz</h5>
                                                        <span>Executive Officer <i>@ Yelp</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Online leaning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-08.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Christopher H. Win</h5>
                                                        <span>Product Designer <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">Remote learning, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->

                                    <!-- Start Single Testimonial  -->
                                    <div class="single-column-20">
                                        <div class="rbt-testimonial-box">
                                            <div class="inner">
                                                <div class="clint-info-wrapper">
                                                    <div class="thumb">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                    </div>
                                                    <div class="client-info">
                                                        <h5 class="title">Martha Maldonado</h5>
                                                        <span>Executive Chairman <i>@ Google</i></span>
                                                    </div>
                                                </div>
                                                <div class="description">
                                                    <p class="subtitle-3">University managemnet, vulputate at sapien sit amet,
                                                        auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                        velit.</p>
                                                    <div class="rating mt--20">
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                        <a href="#"><i class="fa fa-star"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Testimonial  -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <div class="rbt-testimonial-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mb--60">
                        <div class="section-title text-center">
                            <span class="subtitle bg-coral-opacity">EDUCATION FOR EVERYONE</span>
                            <h2 class="title">Student's Feedback</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="rbt-accordion-style rbt-accordion-01  accordion">
                            <div class="accordion" id="accordionExamplea1">
                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="headingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                                            What is Histudy ? How does it work?
                                        </button>
                                    </h2>
                                    <div id="collapseOne" class="accordion-collapse collapse show" aria-labelledby="headingOne" data-bs-parent="#accordionExamplea1">

                                        <div class="accordion-body card-body">
                                            <p class="mb--15">You can run Histudy easily. Any School, University, College
                                                can be use this
                                                histudy education template for their educational purpose. A university can
                                                be success you.</p>
                                            <p>Run their online leaning management system by histudy education template any
                                                where and time.</p>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="headingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
                                            How can I get the customer support?
                                        </button>
                                    </h2>
                                    <div id="collapseTwo" class="accordion-collapse collapse" aria-labelledby="headingTwo" data-bs-parent="#accordionExamplea1">
                                        <div class="accordion-body card-body">
                                            After purchasing the product need you any support you can be share with
                                            us with sending mail to rainbowit10@gmail.com.
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="headingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
                                            Can I get update regularly and For how long do I get updates?
                                        </button>
                                    </h2>
                                    <div id="collapseThree" class="accordion-collapse collapse" aria-labelledby="headingThree" data-bs-parent="#accordionExamplea1">
                                        <div class="accordion-body card-body">
                                            Yes, We will get update the Histudy. And you can get it any time. Next
                                            time we will comes with more feature. You can be get update for
                                            unlimited times. Our dedicated team works for update.
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">

                        <div class="swiper testimonial-activation-1 rbt-dot-bottom-left pb--60">
                            <div class="swiper-wrapper">
                                <!-- Start Single Testimonial  -->
                                <div class="swiper-slide">
                                    <div class="rbt-testimonial-box no-box-shadow bg-gradient-7 text-white">
                                        <div class="inner">
                                            <div class="clint-info-wrapper">
                                                <div class="thumb">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                </div>
                                                <div class="client-info">
                                                    <h5 class="title">Martha Maldonado</h5>
                                                    <span class="designation">Executive Chairman <i>@ Google</i></span>
                                                </div>
                                            </div>
                                            <div class="description">
                                                <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                                    auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                    velit. Lorem Ipsum is simply dummy text of the printing and typesetting
                                                    industry. Lorem Ipsum has been the industry's standard dummy text ever
                                                    since the</p>
                                                <div class="rating mt--20">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Testimonial  -->

                                <!-- Start Single Testimonial  -->
                                <div class="swiper-slide">
                                    <div class="rbt-testimonial-box no-box-shadow bg-gradient-7 text-white">
                                        <div class="inner">
                                            <div class="clint-info-wrapper">
                                                <div class="thumb">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                </div>
                                                <div class="client-info">
                                                    <h5 class="title">Martha Maldonado</h5>
                                                    <span class="designation">Executive Chairman <i>@ Google</i></span>
                                                </div>
                                            </div>
                                            <div class="description">
                                                <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                                    auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                    velit. Lorem Ipsum is simply dummy text of the printing and typesetting
                                                    industry. Lorem Ipsum has been the industry's standard dummy text ever
                                                    since the</p>
                                                <div class="rating mt--20">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Testimonial  -->

                                <!-- Start Single Testimonial  -->
                                <div class="swiper-slide">
                                    <div class="rbt-testimonial-box no-box-shadow bg-gradient-7 text-white">
                                        <div class="inner">
                                            <div class="clint-info-wrapper">
                                                <div class="thumb">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-01.png" alt="Clint Images">
                                                </div>
                                                <div class="client-info">
                                                    <h5 class="title">Martha Maldonado</h5>
                                                    <span class="designation">Executive Chairman <i>@ Google</i></span>
                                                </div>
                                            </div>
                                            <div class="description">
                                                <p class="subtitle-3">After the launch, vulputate at sapien sit amet,
                                                    auctor iaculis lorem. In vel hend rerit nisi. Vestibulum eget risus
                                                    velit. Lorem Ipsum is simply dummy text of the printing and typesetting
                                                    industry. Lorem Ipsum has been the industry's standard dummy text ever
                                                    since the</p>
                                                <div class="rating mt--20">
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                    <a href="#"><i class="fa fa-star"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Testimonial  -->

                            </div>
                            <div class="rbt-swiper-pagination"></div>
                        </div>

                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Testimonial_Widget() );