jQuery(document).ready(function( $ ){
   // show enter address manually
   $(document).on('click','.olc-checkout-show-student-address',function(){
      let $this = $(this)
      $this.closest('#olc_checkout_address_lookup').hide()
      $('.olc_checkout_student_address').show()
   })
   $(document).on('click','.olc-checkout-show-parent-address',function(){
      // let $this = $(this)
      $('#olc_checkout_parent_address_lookup').hide()
      $('#olc_checkout_parent_billing_address').show()
   })
   // let keyup_time_out = null
   // $(document).on('keyup','#olc_checkout_autocomplete_field',function(){
   //    let val = $(this).val()
   //    clearTimeout(keyup_time_out)
   //    keyup_time_out = setTimeout(function(){
   //       $.ajax({
   //          url: olc_checkout.ajax_url,
   //          type: "POST",
   //          dataType: "JSON",
   //          data: {
   //             action: "olc_checkout_get_address",
   //             dataset: val
   //          },
   //          success:function(resp){
   //             console.log(resp)
   //             if( resp.success == true ) {
   //                let $suggestions = resp.data.suggestions
   //                let address_list = ''
   //                $.each($suggestions, function(key,value){
   //                   address_list += `<li data-address-id="${value.id}">${value.address}</li>`
   //                })
   //                $('#olc_checkout_suggestion_list').show()
   //                $('#olc_checkout_suggestion_list').html(address_list)
   //             }
   //          },
   //          error:function(error){
   //             console.log(error)
   //          }
   //       })
   //    },1000)
   // })
   // $(document).on('click','#olc_checkout_suggestion_list li[data-address-id]',function(){
   //    let location_id = $(this).attr('data-address-id')
   //    let $this = $(this)
   //    let $this_html = $this.html()
   //    $this.html('<i class="fa fa-spinner fa-spin"></i> ' + $this_html)
   //    $.ajax({
   //       url: olc_checkout.ajax_url,
   //       type: "POST",
   //       dataType: "json",
   //       data: {
   //          action: "get_the_location_data",
   //          dataset: location_id
   //       },
   //       success:function(resp){
   //          console.log(resp)
   //          $('#olc_checkout_suggestion_list').hide()
   //          $this.html($this_html)
   //          $('.olc-checkout-show-student-addres').show()
   //       },
   //       error:function(error){
   //          console.log(error)
   //          $this.html($this_html)
   //       }
   //    })
   // })
   if( $('#olc_checkout_upsell_products_list').length > 0 ) {
      $('#olc_checkout_upsell_products').select2({
         placeholder: "Select upsell products"
      })
      let product_list = $('#olc_checkout_upsell_products_list').val().split(',')
      $('#olc_checkout_upsell_products').val(product_list).trigger('change')
      // retrive select2 data for pages
      $('#olc_checkout_upsell_products').on('select2:unselect', function (e) {
         let products = $(this).select2('data')
         console.log( products )
         $('#olc_checkout_upsell_products_list').val(products.map(product => product.id).join(','))
      })
      $('#olc_checkout_upsell_products').on('select2:select', function (e) {
         let products = $(this).select2('data')
         console.log( products )
         $('#olc_checkout_upsell_products_list').val(products.map(product => product.id).join(','))
      })
   }
   // select addtional charge
   $(document).on('click','.cart-options__label',function(){
      if( $(this).find('.addonrow').length == 0 ) {
         return
      }
      let cart_addon = $('.cart-addons')
      cart_addon.insertBefore('<div class="cart-detail cart-studymethod cart-delivery row addon4"><div class="col-6">Career kickstart package</div><div class="col-6 u-right-align"><span><strong>£29.99</strong></span></div></div>')
      
   })
   // ajax remove the cart item
   $(document).on('click','button[data-cart-item-key]',function(e){
      e.preventDefault()
      let cart_key = $(this).data('cart-item-key')
      console.log(cart_key)
      $.LoadingOverlay("show")
      $.ajax({
         url: olc_checkout.ajax_url,
         type: "POST",
         dataType: "html",
         data: {
            action: "remove_cart_item",
            dataset: cart_key
         },
         success: function( resp ) {
            console.log( resp )
            try{
               let response_obj = JSON.parse( resp )
               if( response_obj.success == false ) {
                  window.location.reload()
               }
            } catch(err) {
               $('.olc-checkout-cart-data').html(resp)
            }
            $.LoadingOverlay("hide")
            // window.location.reload()
         },
         error: function( err ) {
            console.log( err )
            $.LoadingOverlay("hide")
         }
      })
   })
   $(document).on('keyup','#olc_checkout_password',function(){
      let password_message = $('#olc-checkout-password-error')
      password_message.show()
      let password = $(this).val()
      if( password.length == 0 ) {
         password_message.hide()
      }
      if( password.length < 8 ) {
         password_message.html( "Weak (should be atleast 8 characters.)" )
         return
      }
      // if( password.length > 12 ) throw new Error( "Password cannot be more than 12 character.")
      if ( !password.match(/[a-z]+/) || !password.match(/[A-Z]+/) || !password.match(/[0-9]+/) || !password.match(/[!@#\$%\^\&*\)\(+=._-]+/)) {
         password_message.html("Medium (should include uppercase and lowercase alphabets, numbers and special characters.)")
         return
      }
      password_message.html("Strong")
   })
   // continue checkout
   $(document).on('click','#olc_checkout_continue',function(){
      console.log('sent the request')
      try{
         let student_title = $('#student_title').val()
         if( !student_title ) throw new Error( "Student title is required.")
         let student_firstname = $('#student_firstname').val()
         if( !student_firstname ) throw new Error( "Student first name is required.")
         let student_lastname = $('#student_lastname').val()
         if( !student_lastname ) throw new Error( "Student last name is required.")
         let student_dob = $('#student_dob').val()
         if( !student_dob ) throw new Error( "Student date of birth is required.")
         let student_email = $('#student_email').val()
         if( !student_email ) throw new Error( "Student email of birth is required.")
         if( !student_email.match(/^(([^<>()[\]\\.,;:\s@\"]+(\.[^<>()[\]\\.,;:\s@\"]+)*)|(\".+\"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/) ) {
            throw new Error( "Email is invalid.")
         }
         let password, confirm_password
         if( $('#olc_checkout_password').length > 0 ) {
            password = $('#olc_checkout_password').val()
            if( !password ) throw new Error( "Password is required.")
            confirm_password = $('#olc_checkout_confirm_password').val()
            if( !confirm_password ) throw new Error( "Confirm password is required.")
            if( password != confirm_password ) throw new Error( "Password and confirm password has to be same.")
            if( password.length < 8 ) throw new Error( "Password has to be at least 6 character.")
            if( password.length > 12 ) throw new Error( "Password cannot be more than 12 character.")
            if (!password.match(/[a-z]+/)) throw new Error( "Password must need to have lowercase character.")
            if (!password.match(/[A-Z]+/)) throw new Error( "Password must need to have uppercase character.")
            if (!password.match(/[0-9]+/)) throw new Error( "Password must need to have number.")
            //  if (password.match(/[$@#&!]+/)) {
            //    strength += 1;
            //  }
         }
         let required_additional_info = $('#additional_requirement_switch-input').is(':checked')
         let additional_info
         if( required_additional_info ) {
            additional_info = $('#additional_requirements').val()
         }
         // student address
         let student_phone = $('#student_phone').val()
         if( !student_phone ) throw new Error( "Student phone is required.")
         let student_address1 = $('#student_address1').val()
         if( !student_address1 ) throw new Error( "Student house/flat no. is required.")
         let student_address2 = $('#student_address2').val()
         if( !student_address2 ) throw new Error( "Student street address is required.")
         let student_city = $('#student_city').val()
         if( !student_city ) throw new Error( "Student city is required.")
         let student_postcode = $('#student_postcode').val()
         if( !student_postcode ) throw new Error( "Student postcode is required.")
         let student_country = $('#student_country').val()
         if( !student_country ) throw new Error( "Student country is required.")
         let is_student_minor = $('input[name="student-billing"]:checked').val()
         let billing_firstname, billing_lastname, billing_address1, billing_address2, billing_city, billing_postcode, billing_country
         if( is_student_minor == "parent" ) {
            billing_firstname = $('#billing_firstname').val()
            if( !billing_firstname ) throw new Error("First name is required.")
            billing_lastname = $('#billing_lastname').val()
            if( !billing_lastname ) throw new Error("Last name is required.")
            billing_address1 = $('#billing_address1').val()
            if( !billing_address1 ) throw new Error("Address is required.")
            billing_address2 = $('#billing_address2').val()
            billing_city = $('#billing_city').val()
            billing_postcode = $('#billing_postcode').val()
            billing_country = $('#billing_country').val()
         }
         let terms_and_condition = $('#confirm').is(':checked')
         if( !terms_and_condition ) throw new Error("You have to agree with the terms and conditions of sale.")
         let $this = $(this)
         $this.html('<i class="fa fa-spinner fa-spin"></i> Continue')
         $.ajax({
            url: olc_checkout.ajax_url,
            type: "POST",
            dataType: "json",
            data: {
               action: "create_order_and_generate_session",
               // dataset: 10
               student_title,
               student_firstname,
               student_lastname,
               student_dob,
               student_email,
               required_additional_info,
               additional_info,
               student_phone,
               student_address1,
               student_address2,
               student_city,
               student_postcode,
               student_country,
               is_student_minor,
               billing_firstname,
               billing_lastname,
               billing_address1,
               billing_address2,
               billing_city,
               billing_postcode,
               billing_country,
               terms_and_condition,
               password
            },
            success:function(resp){
               console.log(resp)
               if( resp.success == true ) {
                  window.location.href = resp.data.session.url
               } else {
                  Swal.fire({
                     icon: "warning",
                     text: resp.data
                  })
               }
               // window.open(resp.data.session.url,'_blank')
               $this.html('Continue')
            },
            error:function(err){
               console.log(err)
               $this.html('Continue')
            }
         })
      } catch(error) {
         Swal.fire({
            icon: "warning",
            text: error.message
         })
         return
      }
   })
   // apply the coupon code
   $(document).on('click','#add-discount-code',function(){
      let $this = $(this)
      let coupon = $('#discount-code').val()
      if( !coupon ) {
         Swal.fire({
            icon: "warning",
            text: "Coupon code is required to be applied."
         })
         return
      }
      let $html = $this.html()
      $this.html('<i class="fa fa-spinner fa-spin"></i> Apply')
      $.ajax({
         url: olc_checkout.ajax_url,
         type: "POST",
         dataType: "html",
         data: {
            action: "apply_the_coupon",
            dataset: coupon
         },
         success:function(resp){
            try{
               let response_obj = JSON.parse( resp )
               if( response_obj.success == 'false' ) {
                  Swal.fire({
                     icon: "warning",
                     text: response_obj.data
                  })
               } else if ( response_obj.success == 'true' ) {
                  Swal.fire({
                     icon: "success",
                     text: "Coupon has been applied."
                  })
               }
            } catch(err) {
               $('.olc-checkout-cart-data').html(resp)
            }
            $this.html($html)
            // Swal.fire({
            //    icon: resp.success == true ? "success" : "error",
            //    text: resp.data
            // }).then( reload => window.location.reload() )
            // if( resp.success ) {
            //    $('.discount-code-applied').show()
            // }
         },
         error:function(error){
            console.log(error)
            Swal.fire({
               icon: "error",
               text: "Unknown error occured."
            })
            $this.html($html)
         }
      })
   })
   // enroll now button action
   $(document).on('click','button.enroll-now[data-product-id]',function(e){
      e.preventDefault()
      // if( olc_checkout.logged_in_user == '' ) {
      //    return
      // }
      let $this = $(this)
      let $this_html = $this.find('span').html()
      let study_option = $('input[name="tutor_option_study_pack"]:checked').val()
      let payment_option = $('input[name="tutor_option_study_payment"]:checked').val()
      let product_id = $this.data('product-id')
      $this.find('span').html(`<i class="fa fa-spinner fa-spin"></i> ${$this_html}`)
      $.ajax({
         url: olc_checkout.ajax_url,
         type: "POST",
         dataType: "JSON",
         data: {
            action: "enroll_now_action",
            dataset: [study_option, payment_option, product_id]
         },
         success:function(resp){
            console.log(resp)
            if( resp.success === true ) {
               window.location.href = olc_checkout.checkout_url
            } else {
               Swal.fire({
                  icon: "error",
                  text: resp.data
               })
            }
            $this.find('span').html( $this_html )
         },
         error:function(error){
            console.log(error)
            $this.find('span').html( $this_html )
         }
      })
   })
   $(document).on('click','input.additiona_cart_item[data-extra-id]',function(){
      let cart_id, type = 'add'
      if( $(this).data('cart-id') ) {
         cart_id = $(this).data('cart-id')
         type = 'remove'
      }
      let product_id = $(this).data('product-id')
      $.LoadingOverlay("show")
      $.ajax({
         url: olc_checkout.ajax_url,
         type: "POST",
         dataType: "html",
         data: {
            action: "process_additional_products",
            cart_id, type, product_id
         },
         success:function(resp){
            // console.log(resp)
            try{
               let response_obj = JSON.parse( resp )
               if( response_obj.success == 'false' ) {
                  Swal.fire({
                     icon: "warning",
                     text: response_obj.data
                  })
               }
            } catch(err) {
               $('.olc-checkout-cart-data').html(resp)
            }
            $.LoadingOverlay("hide")
            
         },
         error:function(error){
            console.log(error)
            $.LoadingOverlay("hide")
         }
      })
   })
})