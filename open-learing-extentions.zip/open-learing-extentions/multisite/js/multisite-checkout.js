(function($){
    "use strict";

    $('#olc_subscription').on('submit', function(e){
        e.preventDefault();
        const $useremail        = $('input[name="register_email"]').val();
        const $username         = $('input[name="register_user"]').val();
        const $password         = $('input[name="register_password"]').val();
        const $conf_password    = $('input[name="register_conpassword"]').val();

        if($useremail == '' || $username == '' || $password == '' || $conf_password == ''){
            $('.message').html('<p class="alert alert-danger">Please fill out all the fields!</p>').show(200);
        }else{
            if( $password != $conf_password ){
                $('.message').html('<p class="alert alert-danger">Your passwords not matched!</p>').show(200);
            }else{
                $('.message').html('').hide(200);
                $.ajax({
                    type:'POST',
                    url: multisite.ajax_url,
                    data:{
                        action: 'create_user_site',
                        subscribe_username: $username,
                        subscribe_useremail: $useremail,
                        subscribe_userpass: $conf_password
                    },
                    success:function( response ){
                        if( response.success ){
                            $('.message').html(`<p class="alert alert-success">${response.data}</p>`).show(200);
                        }else{
                            $('.message').html(`<p class="alert alert-danger">${response.data}</p>`).show(200);
                        }
                    }
                })
            }
        }
    })
})(jQuery)