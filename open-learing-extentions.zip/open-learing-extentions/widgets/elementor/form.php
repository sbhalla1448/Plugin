<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Form_Widget extends OLX_Wc_Base_Widget {
    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'form';
	}

	/**
	 * Get widget form.
	 *
	 * Retrieve button widget form.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget form.
	 */
	public function get_title() {
		return esc_html__( 'Form', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <div class="rbt-become-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">Instructor</span>
                            <h2 class="title">Apply As Instructor</h2>
                            <p class="description has-medium-font-size mt--20 mb--40">Lorem ipsum dolor sit amet, consectetur</p>
                        </div>
                    </div>
                </div>

                <div class="row row row--30">

                    <div class="col-lg-12 mt_md--40 mt_sm--40 order-2 order-lg-1">
                        <div class="advance-tab-button">
                            <ul class="nav nav-tabs tab-button-style-2" id="myTab-4" role="tablist">
                                <li role="presentation">
                                    <a href="#" class="tab-button" id="home-tab-4" data-bs-toggle="tab" data-bs-target="#home-4" role="tab" aria-controls="home-4" aria-selected="false">
                                        <span class="title">Become an Intructor.</span>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#" class="tab-button active" id="profile-tab-4" data-bs-toggle="tab" data-bs-target="#profile-4" role="tab" aria-controls="profile-4" aria-selected="true">
                                        <span class="title">Intructor Rules.</span>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#" class="tab-button" id="contact-tab-4" data-bs-toggle="tab" data-bs-target="#contact-4" role="tab" aria-controls="contact-4" aria-selected="false">
                                        <span class="title">Start with courses.</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                        <div class="tab-content advance-tab-content-style-2">
                            <div class="tab-pane fade" id="home-4" role="tabpanel" aria-labelledby="home-tab-4">
                                <div class="content">
                                    <p>Educational technology ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade active show" id="profile-4" role="tabpanel" aria-labelledby="profile-tab-4">
                                <div class="content">
                                    <p>Physical education ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact-4" role="tabpanel" aria-labelledby="contact-tab-4">
                                <div class="content">
                                    <p>Experiencing music ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="row pt--60 g-5">
                    <div class="col-lg-4">
                        <div class="thumbnail">
                            <img class="radius-10 w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/tab/tabs-10.jpg" alt="Corporate Template">
                        </div>
                    </div>

                    <div class="col-lg-8">
                        <div class="rbt-contact-form contact-form-style-1 max-width-auto">
                            <div class="section-title text-start">
                                <span class="subtitle bg-primary-opacity">For Become a Instructor</span>
                            </div>
                            <h3 class="title">Instructor Registration</h3>
                            <hr class="mb--30">

                            <form action="#" class="row row--15">
                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_name" type="text">
                                        <label>First Name</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_lastname" type="text">
                                        <label>Last Name</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_username" type="text">
                                        <label>User name</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_phone" type="text">
                                        <label>Phone Number</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <input name="con_email" type="email">
                                        <label>Email</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>


                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_password" type="password">
                                        <label>Password</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-6">
                                    <div class="form-group">
                                        <input name="con_passwordconfirm" type="password">
                                        <label>Password Confirmation</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-group">
                                        <textarea></textarea>
                                        <label>Bio</label>
                                        <span class="focus-border"></span>
                                    </div>
                                </div>

                                <div class="col-lg-12">
                                    <div class="form-submit-group">
                                        <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">Become a Instructor</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>

                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Form_Widget() );