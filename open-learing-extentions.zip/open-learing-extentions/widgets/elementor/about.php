<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_About_Widget extends OLX_Wc_Base_Widget {
    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'about';
	}

	/**
	 * Get widget about.
	 *
	 * Retrieve button widget about.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget about.
	 */
	public function get_title() {
		return esc_html__( 'About', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 5, '');

        $this->switch_control('_mirror', 'Mirror Layout', null, array(
            '_style' => 'style_3'
        ));

        $this->text_control('_section_subtitle', 'Section subtitle', 'About Histudy', array(
            '_style'    => 'style_3'
        ));

        $this->textarea_control('_section_title', 'Section title', 'What is Histudy For You?', array(
            '_style'    => 'style_3'
        ));

        $this->editor_control('_section_description', 'Section description', '<strong>Histudy educational platform</strong> ipsum dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis, necessitatibus fuga dolore tenetur, beatae suscipit fugit est ea perspiciatis quo provident nisi dolor similique architecto nihil.', array(
            '_style'    => 'style_3'
        ));

        $this->text_control('_section_btn_text', 'Section Button Text', 'About Us', array(
            '_style'    => 'style_3'
        ));

        $this->url_control('_section_btn_url', 'Section Button URL', '#', array(
            '_style'    => 'style_3'
        ));

        $this->image_control('_section_image', 'Section image', array(
            '_style'    => 'style_3'
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_section_subtitle_typo', 'Section subtitle typography', '.rbt-about-area .section-title .subtitle');
        $this->color_control('_section_subtitle_color', 'Section subtitle color', '.rbt-about-area .section-title .subtitle');
        $this->background_control('_section_subtitle_background', 'Section Subtitle Background', '.rbt-about-area .section-title .subtitle');

        $this->typography_control('_section_title_typo', 'Section title typography', '.rbt-about-area .section-title .title');
        $this->color_control('_section_title_color', 'Section title color', '.rbt-about-area .section-title .title');

        $this->typography_control('_section_description_typo', 'Section description typography', '.rbt-about-area .section-title .description');
        $this->color_control('_section_description_color', 'Section description color', '.rbt-about-area .section-title .description');

        $this->typography_control('_section_btn_typo', 'Section Button typography', '.rbt-about-area .read-more-btn .rbt-btn span');
        $this->color_control('_section_btn_color', 'Section Button color', '.rbt-about-area .read-more-btn .rbt-btn span');
        $this->background_control('_section_btn_background', 'Section Button Background', '.rbt-about-area .read-more-btn .rbt-btn');

        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
		<!-- Start About Area  -->
        <div class="rbt-about-area about-style-1 rbt-section-gapTop pb--30 pb_md--80 pb_sm--80 bg-color-white">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <div class="thumbnail-wrapper">
                            <div class="thumbnail image-1">
                                <img data-parallax='{"x": 0, "y": -20}' src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-01.png" alt="Education Images">
                            </div>
                            <div class="thumbnail image-2 d-none d-xl-block">
                                <img data-parallax='{"x": 0, "y": 60}' src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-02.png" alt="Education Images">
                            </div>
                            <div class="thumbnail image-3 d-none d-md-block">
                                <img data-parallax='{"x": 0, "y": 80}' src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-03.png" alt="Education Images">
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="inner pl--50 pl_sm--0 pl_md--0">
                            <div class="section-title text-start">
                                <span class="subtitle bg-coral-opacity">Know About Us</span>
                                <h2 class="title">Know About Histudy <br /> Learning Platform</h2>
                            </div>

                            <p class="description mt--30">Far far away, behind the word mountains, far from the countries Vokalia and Consonantia, there live the blind texts. Separated they live in Bookmarksgrove right at the coast of the Semantics, a large language ocean.</p>

                            <!-- Start Feature List  -->

                            <div class="rbt-feature-wrapper mt--20 ml_dec_20">
                                <div class="rbt-feature feature-style-2 rbt-radius">
                                    <div class="icon bg-pink-opacity">
                                        <i class="feather-heart"></i>
                                    </div>
                                    <div class="feature-content">
                                        <h6 class="feature-title">Flexible Classes</h6>
                                        <p class="feature-description">It is a long established fact that a reader will
                                            be distracted by this on readable content of when looking at its layout.</p>
                                    </div>
                                </div>

                                <div class="rbt-feature feature-style-2 rbt-radius">
                                    <div class="icon bg-primary-opacity">
                                        <i class="feather-book"></i>
                                    </div>
                                    <div class="feature-content">
                                        <h6 class="feature-title">Learn From Anywhere</h6>
                                        <p class="feature-description">Sed distinctio repudiandae eos recusandae laborum eaque non eius iure suscipit laborum eaque non eius iure suscipit.</p>
                                    </div>
                                </div>
                            </div>

                            <!-- End Feature List  -->
                            <div class="about-btn mt--40">
                                <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                    <span class="icon-reverse-wrapper">
                                <span class="btn-text">More About Us</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End About Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <div class="rbt-about-area about-style-1 bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 align-items-start">
                    <div class="col-lg-6">
                        <div class="content">
                            <h2 class="title mb--0">About the University we are creative preapre you for your career supportive.</h2>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <p class="mb--40 mb_sm--20">Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis, necessitatibus fuga dolore tenetur, beatae suscipit fugit est ea perspiciatis quo provident nisi dolor similique architecto nihil! Ipsa aspernatur aperiam recusandae pariatur odit repudiandae assumenda architecto.</p>
                        <div class="readmore-btn">
                            <a class="rbt-moderbt-btn" href="#">
                                <span class="moderbt-btn-text">University Overview</span>
                                <i class="feather-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <?php elseif( $settings['_style'] == 'style_3' ): 
            $style_3_class = '';
            if( $settings['_mirror'] == 'yes' ){
                $style_3_class = 'about-style-1';
            }
        ?>
        <div class="rbt-about-area <?php echo esc_attr($style_3_class); ?> " id="about">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 order-2 order-lg-1">
                        <div class="inner">
                            <div class="section-title text-start">
                                <span class="subtitle"><?php echo esc_html($settings['_section_subtitle']); ?></span>
                                <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                                <p class="description mt--20"><?php echo wp_kses_post($settings['_section_description']); ?></p>
                                <div class="read-more-btn mt--40">
                                    <a class="rbt-btn rbt-switch-btn rbt-switch-y" href="<?php echo esc_url($settings['_section_btn_url']['url']); ?>">
                                        <span data-text="<?php echo esc_html($settings['_section_btn_text']); ?>"><?php echo esc_html($settings['_section_btn_text']); ?></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2">
                        <div class="content">
                            <img src="<?php echo esc_url($settings['_section_image']['url']); ?>" alt="<?php echo \Elementor\Control_Media::get_image_alt($settings['_section_image']); ?>">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="about-style-2 rbt-section-gapBottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="row row--0 about-wrapper align-items-center theme-shape">
                            <div class="col-lg-6">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-12.jpg" alt="About Images">
                                </div>
                            </div>
                            <div class="col-lg-6 mt_md--30 mt_sm--30">
                                <div class="content">
                                    <div class="inner">
                                        <h4 class="title">I'm <span class="theme-gradient">John Lee</span> <br />The Founder Of Histudy Academy.</h4>
                                        <p>Web teacher and leacture for future development.</p>
                                        <ul class="contact-address">
                                            <li>
                                                <i class="feather-file"></i> Web designer &amp; developer
                                            </li>
                                            <li><i class="feather-phone"></i> +01910203040</li>
                                            <li>
                                                <i class="feather-map-pin"></i> Dhaka, Bangladesh
                                            </li>
                                        </ul>
                                        <div class="signature-image mt--20">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/signature.png" alt="Signature Images">
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="top-circle-shape position-bottom-right"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <div class="rbt-about-area about-style-1 bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <div class="content">
                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-06.png" alt="About Images">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="inner pl--50 pl_sm--5">
                            <div class="section-title text-start">
                                <span class="subtitle bg-primary-opacity">About Histudy</span>
                                <h2 class="title">What is Histudy For You?.</h2>
                                <p class="description mt--20"><strong>Histudy educational platform</strong> ipsum dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis, necessitatibus fuga dolore tenetur, beatae suscipit fugit est ea perspiciatis quo provident nisi dolor similique architecto nihil.</p>
                                <div class="read-more-btn mt--40">
                                    <a class="rbt-btn btn-gradient radius-round rbt-marquee-btn marquee-text-y" href="#">
                                        <span data-text="More About Us">
                                    More About Us
                                </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_About_Widget() );