<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Banner_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'banner';
	}

	/**
	 * Get widget banner.
	 *
	 * Retrieve button widget banner.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget banner.
	 */
	public function get_title() {
		return esc_html__( 'Banner', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 16, '', 'style_16');
        $this->text_control('_banner_subtitle', 'Subtitle', 'How We Work', array(
            '_style'    => 'style_16'
        ));

        $this->textarea_control('_banner_title', 'Title', 'Take Challenge for Build Your Life. <br>The World Most
        Lessons for Back to Your Life.', array(
            '_style'    => 'style_16'
        ));
        $this->text_control('_banner_btn_text', 'Button text', 'More About Us', array(
            '_style'    => 'style_16'
        ));
        $this->url_control('_banner_btn_link', 'Button link', '#', array(
            '_style'    => 'style_16'
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_banner_subtitle_typo', 'Subtitle Typography', '.slider-area .section-title .subtitle');
        $this->color_control('_banner_subtitle_color', 'Subtitle color', '.slider-area .section-title .subtitle');
        $this->background_control('_banner_subtitle_background', 'Subtitle Background', '.slider-area .section-title .subtitle');

        $this->typography_control('_banner_title_typo', 'Title Typography', '.slider-area .title');
        $this->color_control('_banner_title_color', 'Title color', '.slider-area .title');

        $this->typography_control('_banner_btn_typo', 'Button typography', '.slider-area .read-more-btn .rbt-btn .btn-text');
        $this->color_control('_banner_btn_color', 'Button text color', '.slider-area .read-more-btn .rbt-btn .btn-text');
        $this->background_control('_banner_btn_background', 'Button Background', '.slider-area .read-more-btn .rbt-btn');

        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
		<!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-1">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-12 pb--120 pt--70">
                        <div class="content">
                            <div class="inner">
                                <div class="rbt-new-badge rbt-new-badge-one">
                                    <span class="rbt-new-badge-icon">🏆</span> The Leader in Online Learning
                                </div>

                                <h1 class="title">
                                    Build The Skills <br> To Drive Your Career.
                                </h1>
                                <p class="description">
                                    Amet minim mollit non deserunt ullamco est sit aliqua dolor do amet sint.
                                    <strong>Velit
                                        officia consequat.</strong>
                                </p>
                                <div class="slider-btn">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">View Course</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="shape-wrapper" id="scene">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/banner-01.png" alt="Hero Image">
                                <div class="hero-bg-shape-1 layer" data-depth="0.4">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/shape-01.png" alt="Hero Image Background Shape">
                                </div>
                                <div class="hero-bg-shape-2 layer" data-depth="0.4">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/shape-02.png" alt="Hero Image Background Shape">
                                </div>
                            </div>

                            <div class="banner-card pb--60 mb--50 swiper rbt-dot-bottom-center banner-swiper-active">
                                <div class="swiper-wrapper">

                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-01.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-01.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-02.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                </div>
                                <div class="rbt-swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-5 height-650 bg_image bg_image--19">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="inner text-start">
                            <h2 class="title"><span class="text-decoration-underline">Histudy</span> Starter is a community for
                                creative people</h2>
                            <p class="description">We just don't give our student only lecture but real life
                                experience.</p>
                            <div class="slider-btn rbt-button-group justify-content-start">
                                <a class="rbt-btn btn-border icon-hover color-white radius-round" href="#">
                                    <span class="btn-text">Explore Courses</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </a>
                                <a class="rbt-btn-link color-white" href="#">Start learning<i
                                        class="feather-arrow-right"></i></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-4 bg_image bg_image--13 header-transperent-spacer">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-md-12">
                            <div class="content text-start">
                                <div class="inner">
                                    <div class="mb--20">
                                        <a href="#" class="rbt-badge-2">
                                            <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Education Images"></div> Learn with <strong>Fatima Asrafy</strong>
                                        </a>
                                    </div>
                                    <h1 class="title">Putting Your Child's Future <br /> in Great Motion.</h1>
                                    <p class="description">We just don't give our student only <br /> lecture but real life
                                        experience.</p>

                                    <ul class="rbt-list-style-2">
                                        <li><i class="feather-check"></i>No Cridit Card</li>
                                        <li><i class="feather-check"></i>14 Days Trial</li>
                                        <li><i class="feather-check"></i>Free For Teachers</li>
                                    </ul>

                                    <div class="slider-btn">
                                        <a class="rbt-btn radius rbt-marquee-btn marquee-text-y" href="#">
                                            <span data-text="Get Started Today">
                                                Get Started Today
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-slider-main-wrapper position-relative">
            <!-- Start Banner Area  -->
            <div class="swiper rbt-banner-activation rbt-slider-animation rbt-arrow-between">
                <div class="swiper-wrapper">
                    <!-- Start Single Banner  -->
                    <div class="swiper-slide">
                        <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--17" data-gradient-overlay="5">
                            <div class="wrapper w-100">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <div class="col-lg-12">
                                            <div class="inner text-center">
                                                <div class="section-title">
                                                    <span class="subtitle bg-white-opacity d-inline-block">BASED ON THE BEST
                                                        HISTUDY</span>
                                                </div>
                                                <h1 class="title w-700">Hey! Build Your Career <br /> <strong
                                                        class="color-white">With Follow Histudy</strong></h1>
                                                <div class="button-group mt--30">
                                                    <a class="rbt-btn btn-gradient rbt-marquee-btn" href="#">
                                                        <span data-text="More About University">More About University</span>
                                                    </a>
                                                </div>
                                                <div class="social-share-wrapper mt--40">
                                                    <ul class="social-icon social-default transparent-with-border">
                                                        <li><a href="https://www.facebook.com/">
                                                                <i class="feather-facebook"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.twitter.com">
                                                                <i class="feather-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.instagram.com/">
                                                                <i class="feather-instagram"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.linkdin.com/">
                                                                <i class="feather-linkedin"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <span class="follow-us-text">Follow By Facebook, Twitter, Instagram, and
                                                        Linkedin</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Banner  -->

                    <!-- Start Single Banner  -->
                    <div class="swiper-slide">
                        <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--21" data-black-overlay="5">
                            <div class="wrapper w-100">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <div class="col-lg-12">
                                            <div class="inner text-center">
                                                <div class="section-title">
                                                    <span class="subtitle bg-white-opacity d-inline-block">THE BEST TEMPLATE FOR
                                                        EDUCATION</span>
                                                </div>
                                                <h1 class="title w-700">Histudy Starter is a community <br /> <strong
                                                        class="color-white">for creative people.</strong></h1>
                                                <div class="button-group mt--30">
                                                    <a class="rbt-btn btn-gradient rbt-marquee-btn radius-round" href="#">
                                                        <span data-text="More About University">More About University</span>
                                                    </a>
                                                </div>
                                                <div class="social-share-wrapper mt--40">
                                                    <ul class="social-icon social-default transparent-with-border">
                                                        <li><a href="https://www.facebook.com/">
                                                                <i class="feather-facebook"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.twitter.com">
                                                                <i class="feather-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.instagram.com/">
                                                                <i class="feather-instagram"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.linkdin.com/">
                                                                <i class="feather-linkedin"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <span class="follow-us-text">Follow By Facebook, Twitter, Instagram, and
                                                        Linkedin</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Banner  -->

                    <!-- Start Single Banner  -->
                    <div class="swiper-slide">
                        <div class="rbt-banner-area rbt-banner-6 variation-03 bg_image bg_image--16" data-gradient-overlay="5">
                            <div class="wrapper w-100">
                                <div class="container">
                                    <div class="row align-items-center">
                                        <div class="col-lg-12">
                                            <div class="inner text-center">
                                                <div class="section-title">
                                                    <span class="subtitle bg-white-opacity d-inline-block">THE BEST TEMPLATE FOR
                                                        EDUCATION</span>
                                                </div>
                                                <h1 class="title w-700">Learning keeps you <br /> <strong
                                                        class="color-white">in the lead</strong></h1>
                                                <div class="button-group mt--30">
                                                    <a class="rbt-btn btn-gradient rbt-marquee-btn radius-round" href="#">
                                                        <span data-text="More About University">More About University</span>
                                                    </a>
                                                </div>
                                                <div class="social-share-wrapper mt--40">
                                                    <ul class="social-icon social-default transparent-with-border">
                                                        <li><a href="https://www.facebook.com/">
                                                                <i class="feather-facebook"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.twitter.com">
                                                                <i class="feather-twitter"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.instagram.com/">
                                                                <i class="feather-instagram"></i>
                                                            </a>
                                                        </li>
                                                        <li><a href="https://www.linkdin.com/">
                                                                <i class="feather-linkedin"></i>
                                                            </a>
                                                        </li>
                                                    </ul>
                                                    <span class="follow-us-text">Follow By Facebook, Twitter, Instagram, and
                                                        Linkedin</span>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Banner  -->

                </div>

                <div class="rbt-swiper-arrow rbt-arrow-left">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-left"></i>
                        <i class="rbt-icon-top feather-arrow-left"></i>
                    </div>
                </div>

                <div class="rbt-swiper-arrow rbt-arrow-right">
                    <div class="custom-overfolow">
                        <i class="rbt-icon feather-arrow-right"></i>
                        <i class="rbt-icon-top feather-arrow-right"></i>
                    </div>
                </div>

            </div>

            <div class="swiper rbt-swiper-thumb rbtmySwiperThumb">
                <div class="swiper-wrapper">
                    <div class="swiper-slide">
                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/banner-small-01.png" alt="Banner Images" />
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/banner-small-02.png" alt="Banner Images" />
                    </div>
                    <div class="swiper-slide">
                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/banner-small-03.png" alt="Banner Images" />
                    </div>
                </div>
            </div>
            <!-- End Banner Area  -->
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <!-- Start Our Banner Area  -->
        <div class="rbt-banner-area rbt-section-gapTop">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper viral-banner-activation rbt-arrow-between">
                            <div class="swiper-wrapper">
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/hi_2.png" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/hi_1.png" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/hi_3.png" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                            </div>
                            <div class="rbt-swiper-arrow rbt-arrow-left">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-left"></i>
                                    <i class="rbt-icon-top feather-arrow-left"></i>
                                </div>
                            </div>
                            <div class="rbt-swiper-arrow rbt-arrow-right">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-right"></i>
                                    <i class="rbt-icon-top feather-arrow-right"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Our Banner Area  -->
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-8 variation-02 with-shape">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="content">
                            <div class="inner text-center">
                                <div class="rbt-new-badge rbt-new-badge-one">
                                    <span class="rbt-new-badge-icon">🏆</span> The Leader in Online Learning
                                </div>
                                <h1 class="title">Popular Courses
                                    <span class="header-caption">
                                        <span class="cd-headline clip is-full-width">
                                            <span class="cd-words-wrapper">
                                                <b class="is-visible theme-gradient">English.</b>
                                                <b class="is-hidden theme-gradient">Finance.</b>
                                                <b class="is-hidden theme-gradient">Math.</b>
                                            </span>
                                    </span>
                                    </span>
                                </h1>
                                <p class="description has-medium-font-size mt--20">Dive in and learn React.js from scratch! Learn Reactjs, Hooks, Redux, React Routing, Animations, Next.js and way more!
                                </p>
                                <div class="slider-btn rbt-button-group justify-content-center">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Log in to Start</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                    <a class="rbt-btn hover-icon-reverse btn-white" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Buy The Course</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="shape-image">
                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/tree-shape.svg" alt="Shape">
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
        <!-- End Banner Area -->
        <div class="rbt-banner-6 variation-02 bg_image bg_image--7 header-transperent-spacer" data-black-overlay="2">
            <div class="wrapper w-100">
                <div class="container">
                    <div class="row row--15 align-items-center">
                        <div class="col-lg-12">
                            <div class="inner text-start">
                                <div class="section-title">
                                    <span class="subtitle bg-white-opacity d-inline-block">BestSeller</span>
                                </div>
                                <h2 class="title w-700">Hey! Build Your Body <br>
                                    <strong>
                                        <span class="header-caption">
                                            <span class="cd-headline zoom">
                                                <span class="cd-words-wrapper">
                                                    <b class="is-visible theme-gradient">With Follow Histudy.</b>
                                                    <b class="is-hidden theme-gradient">With GYM Instructor.</b>
                                                </span>
                                            </span>
                                        </span>
                                    </strong>
                                </h2>
                                <div class="button-group mt--30 mt_sm--10">
                                    <a class="rbt-btn btn-gradient rbt-switch-btn rbt-switch-y" href="#">
                                        <span data-text="Join Us Today">Join Us Today</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-3 header-transperent-spacer">
            <div class="wrapper">
                <div class="container">
                    <div class="row g-5">
                        <div class="col-lg-7 order-2 order-lg-1">
                            <div class="banner-content ">
                                <div class="inner">
                                    <div class="section-title text-start">
                                        <span class="subtitle bg-pink-opacity">THE BEST THEME FOR</span>
                                    </div>
                                    <h1 class="title">Online Learning <br /> Managemnt System</h1>
                                    <p class="description">We are experienced in educationl platform and skilled strategies
                                        for
                                        the success of our online learning.</p>
                                    <div class="rating mb--20">
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                        <a href="#"><i class="fa fa-star"></i></a>
                                    </div>
                                    <div class="rbt-like-total">
                                        <div class="profile-share">
                                            <a href="#" class="avatar" data-tooltip="Mark JOrdan" tabindex="0"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/testimonial/client-03.png" alt="education"></a>
                                            <a href="#" class="avatar" data-tooltip="Mark" tabindex="0"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/testimonial/client-04.png" alt="education"></a>
                                            <a href="#" class="avatar" data-tooltip="Jordan" tabindex="0"><img src="<?php echo get_template_directory_uri(); ?>/assets/images/testimonial/client-06.png" alt="education"></a>
                                            <div class="more-author-text">
                                                <h5 class="total-join-students">Join Over 3000+ Students</h5>
                                                <p class="subtitle">Have a new ideas every week.</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 order-1 order-lg-2">
                            <div class="rbt-contact-form contact-form-style-1">
                                <h3 class="title">Get a Free Histudy Online Course</h3>
                                <form id="contact-form">
                                    <div class="form-group">
                                        <input name="con_name" type="text" />
                                        <label>Name</label>
                                        <span class="focus-border"></span>
                                    </div>
                                    <div class="form-group">
                                        <input name="con_email" type="email">
                                        <label>Email</label>
                                        <span class="focus-border"></span>
                                    </div>
                                    <div class="form-group">
                                        <textarea></textarea>
                                        <label>Message</label>
                                        <span class="focus-border"></span>
                                    </div>
                                    <div class="form-submit-group">
                                        <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse radius-round w-100">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">GET IT NOW</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </button>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape-wrapper">
                <div class="left-shape">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner/right-shape.png" alt="Banner Images">
                </div>
                <div class="top-shape">
                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/banner/top-shape.png" alt="Banner Images">
                </div>
                <div class="marque-images edumarque"></div>
            </div>
        </div>
        <!-- End Banner Area -->

        <?php elseif( $settings['_style'] == 'style_9' ): ?>
        <div class="slider-area rbt-banner-5 height-750 bg_image bg_image--3" data-gradient-overlay="7">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner text-center">
                            <h1 class="title display-one">Start Your
                                <span>Career &amp; </span>
                                <span>Pursue</span> Your Passion.
                            </h1>
                            <p class="description">We help our clients succeed by creating brand identities, digital
                                experiences, and print materials.</p>
                            <div class="rbt-button-group">
                                <a class="rbt-btn btn-white hover-icon-reverse" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">View Our Program</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                                <a class="rbt-btn btn-border hover-icon-reverse color-white" href="contact.html">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Contact Us</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_10' ): ?>
            <script>
                jQuery(document).ready(function(){
                    var swiper = new Swiper('.team-slide-activation-4', {
                        slidesPerView: 1,
                        spaceBetween: 30,
                        loop: true,
                        pagination: {
                            el: '.rbt-swiper-pagination',
                            clickable: true,
                        },
                        navigation: {
                            nextEl: '.rbt-arrow-left',
                            prevEl: '.rbt-arrow-right',
                            clickable: true,
                        },
                        breakpoints: {
                            575: {
                            slidesPerView: 1,
                            },
                            768: {
                            slidesPerView: 2,
                            },
                            992: {
                            slidesPerView: 3,
                            },
                            
                            1200: {
                            slidesPerView: 4,
                            },
                        },
                    });
                })
            </script>
        <!-- Start Banner Area  -->
        <div class="rbt-banner-area rbt-banner-8 variation-03 section-bottom-overlay" id="home">
            <div class="wrapper bg-color-secondary-alt">
                <div class="container">
                    <div class="row g-5 align-items-center">
                        <div class="col-lg-10 offset-lg-1">
                            <div class="content">
                                <div class="inner text-center">
                                    <div class="section-title">
                                        <span class="subtitle bg-primary-opacity">Enjoy Learning!</span>
                                    </div>

                                    <h1 class="banner-title">Learn Product Design in <span class="theme-gradient">16
                                            weeks</span></h1>

                                    <p class="description has-medium-font-size mt--20">Dive in and learn React.js from
                                        scratch! Learn Reactjs, Hooks, Redux, React Routing, Animations, Next.js and way
                                        more!
                                    </p>

                                    <div class="slider-btn rbt-button-group justify-content-center">
                                        <a class="rbt-btn btn-gradient rbt-switch-btn rbt-switch-y" href="#">
                                            <span data-text="Learn More About Us">Learn More About Us</span>
                                        </a>
                                    </div>
                                    <div class="brand-area mt--60">
                                        <span class="follow-us-text">Making sensitive clients more valuable for companies
                                            like</span>
                                        <ul class="brand-list brand-style-3 justify-content-start justify-content-lg-between">
                                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/partner-5.webp" alt="Brand Image"></a></li>
                                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/partner-1.webp" alt="Brand Image"></a></li>
                                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/partner-5.webp" alt="Brand Image"></a></li>
                                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/partner-6.webp" alt="Brand Image"></a></li>
                                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/partner-3.webp" alt="Brand Image"></a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="banner-overlay-section">
                <div class="container">
                    <div class="row row--15">
                        <div class="col-lg-12">
                            <div class="swiper team-slide-activation-4 rbt-arrow-between rbt-dot-bottom-center">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-04.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">Aaron Griffe</a></h4>
                                                    <p class="designation">Depertment Head</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-05.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">Aaron Griffe</a></h4>
                                                    <p class="designation">Teacher</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-06.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">Joe Bidden</a></h4>
                                                    <p class="designation">Depertment Head</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-03.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">John Due</a></h4>
                                                    <p class="designation">Marketing SR</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-02.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">Joe Bidden</a></h4>
                                                    <p class="designation">Depertment Head</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="team team-style--bottom variation-2">
                                            <div class="thumbnail">
                                                <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-01.jpg" alt="Blog Images"></a>
                                            </div>
                                            <div class="content">
                                                <div class="inner">
                                                    <h4 class="title"><a href="#">Jannen</a></h4>
                                                    <p class="designation">App Developer</p>
                                                </div>
                                                <div class="icon-right">
                                                    <a href="#"><i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="rbt-swiper-arrow rbt-arrow-left">
                                    <div class="custom-overfolow">
                                        <i class="rbt-icon feather-arrow-left"></i>
                                        <i class="rbt-icon-top feather-arrow-left"></i>
                                    </div>
                                </div>

                                <div class="rbt-swiper-arrow rbt-arrow-right">
                                    <div class="custom-overfolow">
                                        <i class="rbt-icon feather-arrow-right"></i>
                                        <i class="rbt-icon-top feather-arrow-right"></i>
                                    </div>
                                </div>


                                <div class="rbt-swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area  -->
        <?php elseif( $settings['_style'] == 'style_11' ): ?>
        <!-- Start Slider Area  -->
        <div class="slider-area rbt-banner-6 variation-01 bg_image bg_image--14 header-transperent-spacer" data-black-overlay="7">
            <div class="wrapper w-100">
                <div class="container">
                    <div class="row align-items-center">
                        <div class="col-12">
                            <div class="inner text-center">
                                <div class="badge-top mb--30">
                                    <span class="rbt-badge">Histudy Badge</span>
                                </div>
                                <h1 class="title">Hey! Build Your <span class="theme-gradient">Life</span> <strong>With
                                        John Lee</strong></h1>
                                <div class="button-group mt--30">
                                    <a class="rbt-btn btn-gradient rbt-marquee-btn" href="#">
                                        <span data-text="Get Started Today">Get Started Today</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Slider Area  -->
        <?php elseif( $settings['_style'] == 'style_12' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-7 bg-gradient-1 theme-shape header-transperent-spacer">
            <div class="wrapper w-100">
                <div class="container">
                    <div class="row g-5 justify-content-between align-items-center">
                        <div class="col-lg-6 order-2 order-lg-1">
                            <div class="content">
                                <div class="inner">
                                    <div class="section-title text-start">
                                        <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                                    </div>
                                    <h1 class="title">Innovative <span class="theme-gradient">Language Academic</span> Platform
                                        for Your Career.</h1>
                                    <div class="rbt-like-total">
                                        <div class="profile-share">
                                            <a href="#" class="avatar" data-tooltip="Mark JOrdan" tabindex="0"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-04.png" alt="education"></a>
                                            <a href="#" class="avatar" data-tooltip="Mark" tabindex="0"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-05.png" alt="education"></a>
                                            <a href="#" class="avatar" data-tooltip="Jordan" tabindex="0"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-06.png" alt="education"></a>
                                            <div class="more-author-text">
                                                <h5 class="total-join-students">Join Over 3000+ Students</h5>
                                                <p class="subtitle">Have a new ideas every week.</p>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="rbt-button-group justify-content-start mt--30">
                                        <a class="rbt-btn btn-gradient rbt-switch-btn" href="#">
                                            <span data-text="Sign Up Now">Sign Up Now</span>
                                        </a>
                                        <a class="rbt-btn btn-border rbt-switch-btn" href="#">
                                            <span data-text="Find Courses">Find Courses</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-6 order-1 order-lg-2">
                            <div class="thumbnail-wrapper">
                                <div class="thumbnail text-end">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/language-club.png" alt="Education Images">
                                </div>
                                <div class="card-info bounce-slide">
                                    <div class="inner">
                                        <div class="name">Hillery. <span>/ USA</span></div>
                                        <div class="rating-wrapper d-block d-sm-flex">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span>(Google Review)</span>
                                        </div>
                                    </div>
                                    <div class="notify-icon">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-12.png" alt="Client Images">
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_13' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-8 variation-01 bg_image bg_image--9">
            <div class="wrapper w-100">
                <div class="container">
                    <div class="row g-5 align-items-center">
                        <div class="col-lg-6 order-2 order-lg-1">
                            <div class="content">
                                <div class="inner">
                                    <div class="rbt-badge-group justify-content-start">
                                        <span class="meta-text d-flex align-items-center"><span class="icon">🎬</span> Video Online Course</span>
                                        <a href="#" class="rbt-badge-2">
                                            <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/testimonial/client-02.png" alt="Education Images"></div> Learn with <strong>Fatima Asrafy</strong>
                                        </a>
                                    </div>
                                    <h1 class="title">Online Courses</h1>
                                    <p class="description has-medium-font-size mt--20">Dive in and learn React.js from scratch! Learn Reactjs, Hooks, Redux, React Routing, Animations, Next.js and way more!
                                    </p>
                                    <div class="slider-btn rbt-button-group justify-content-start">
                                        <a class="rbt-btn btn-gradient radius-round hover-icon-reverse" href="#">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">Log in to Start</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </a>
                                        <a class="rbt-btn radius-round hover-icon-reverse btn-white" href="#">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">Buy The Course</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-5 offset-xl-1 order-1 order-lg-2">
                            <div class="video-popup-wrapper">
                                <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-02.jpg" alt="Video Images">
                                <a class="rbt-btn rounded-player-2 popup-video position-to-top with-animation" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                    <span class="play-icon"></span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_14' ): ?>
            <script>
                jQuery(document).ready(function(){
                    var swiper = new Swiper('.banner-swiper-active', {
                        effect: 'cards',
                        grabCursor: true,
                        pagination: {
                            el: '.rbt-swiper-pagination',
                            clickable: true,
                        },
                    });
                })
            </script>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-1 variation-2 height-750">
            <div class="container">
                <div class="row justify-content-between align-items-center">
                    <div class="col-lg-8">
                        <div class="content">
                            <div class="inner">
                                <div class="rbt-new-badge rbt-new-badge-one">
                                    <span class="rbt-new-badge-icon">🏆</span> The Leader in Online Learning
                                </div>
                                <h1 class="title">The Largest <span class="color-primary">Online Learning</span> Platform
                                    for Drive Your Career.</h1>
                                <p class="description">This template includes all the necessary pages of the onlineLorem.
                                    And you can be build a <strong>education template easily</strong>.
                                </p>
                                <div class="slider-btn">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">View Course</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="content">
                            <div class="banner-card pb--60 swiper rbt-dot-bottom-center banner-swiper-active">
                                <div class="swiper-wrapper">
                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-01.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-01.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="swiper-slide">
                                        <div class="rbt-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-01.jpg" alt="Card image">
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span>-40%</span>
                                                        <span>Off</span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="course-details.html">React</a>
                                                </h4>
                                                <p class="rbt-card-text">It is a long established fact that a reader
                                                    will be distracted.</p>
                                                <div class="rbt-review">
                                                    <div class="rating">
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                        <i class="fas fa-star"></i>
                                                    </div>
                                                    <span class="rating-count"> (15 Reviews)</span>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$70</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn More<i
                                                            class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->
                                </div>
                                <div class="rbt-swiper-pagination"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_15' ): ?>
            <script>
                jQuery(document).ready(function(){
                    var swiper = new Swiper('.service-item-3-activation', {
                        slidesPerView: 1,
                        spaceBetween: 0,
                        loop: false,
                        navigation: {
                            nextEl: '.rbt-arrow-left',
                            prevEl: '.rbt-arrow-right',
                            clickable: true,
                        },
                        breakpoints: {
                            480: {
                            slidesPerView: 1,
                            },
                            481: {
                            slidesPerView: 2,
                            },
                            768: {
                            slidesPerView: 3,
                            },
                            992: {
                            slidesPerView: 3,
                            },
                        },
                    });
                })
            </script>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-2 header-transperent-spacer">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="banner-content text-center">
                                <div class="inner">
                                    <div class="rbt-new-badge rbt-new-badge-one mb--30">
                                        <span class="rbt-new-badge-icon">🏆</span> The Leader in Online Learning
                                    </div>
                                    <h1 class="title">We teaching, educate and <span class="theme-gradient">build the
                                            future</span> of online learning</h1>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="swiper service-item-3-activation  rbt-arrow-between gutter-swiper-30">

                        <div class="swiper-wrapper">
                            <!-- Start Single Card  -->
                            <div class="swiper-slide">
                                <div class="single-slide">
                                    <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-1">
                                        <div class="inner">
                                            <div class="content">
                                                <h4 class="title"><a href="#">React</a></h4>
                                                <p>React Js dolor sit, amet consectetur.</p>
                                                <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                            </div>
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-06.png" alt="Education Images">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <!-- Start Single Card  -->
                            <div class="swiper-slide">
                                <div class="single-slide">
                                    <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-2">
                                        <div class="inner">
                                            <div class="content">
                                                <h4 class="title"><a href="#">English</a></h4>
                                                <p>Spken english dolor sit, amet consectetur.</p>
                                                <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                            </div>
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-05.png" alt="Education Images">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                            <!-- Start Single Card  -->
                            <div class="swiper-slide">
                                <div class="single-slide">
                                    <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-3">
                                        <div class="inner">
                                            <div class="content">
                                                <h4 class="title"><a href="#">Education</a></h4>
                                                <p>Eearning edu dolor sit, amet consectetur.</p>
                                                <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                            </div>
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-03.png" alt="Education Images">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="swiper-slide">
                                <div class="single-slide">
                                    <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-4">
                                        <div class="inner">
                                            <div class="content">
                                                <h4 class="title"><a href="#">Education</a></h4>
                                                <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                                <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                            </div>
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-04.png" alt="Education Images">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                        </div>

                        <div class="rbt-swiper-arrow rbt-arrow-left">
                            <div class="custom-overfolow">
                                <i class="rbt-icon feather-arrow-left"></i>
                                <i class="rbt-icon-top feather-arrow-left"></i>
                            </div>
                        </div>

                        <div class="rbt-swiper-arrow rbt-arrow-right">
                            <div class="custom-overfolow">
                                <i class="rbt-icon feather-arrow-right"></i>
                                <i class="rbt-icon-top feather-arrow-right"></i>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
        <?php elseif( $settings['_style'] == 'style_16' ): ?>
        <!-- Start Banner Area  -->
        <div class="slider-area rbt-banner-10 height-750" data-black-overlay="5">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner text-center">
                            <div class="section-title mb--20">
                                <span class="subtitle"><?php echo esc_html($settings['_banner_subtitle']); ?></span>
                            </div>
                            <h1 class="title display-one"><?php echo wp_kses_post($settings['_banner_title']); ?></h1>
                            <div class="read-more-btn mt--40">
                                <a class="rbt-btn hover-icon-reverse" href="<?php echo esc_html($settings['_banner_btn_link']['url']); ?>">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text"><?php echo esc_html($settings['_banner_btn_text']); ?></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area  -->
        <?php elseif( $settings['_style'] == 'style_17' ): ?>
        <!-- Start Banner Area -->
        <div class="rbt-banner-area rbt-banner-8 variation-02">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="content">
                            <div class="inner text-center">
                                <div class="rbt-new-badge rbt-new-badge-one">
                                    <span class="rbt-new-badge-icon">🏆</span> The Leader in Online Learning
                                </div>

                                <h1 class="title">Read About Our
                                    <span class="header-caption">
                                        <span class="cd-headline clip is-full-width">
                                            <span class="cd-words-wrapper">
                                                <b class="is-visible theme-gradient">Mission.</b>
                                                <b class="is-hidden theme-gradient">Vission.</b>
                                                <b class="is-hidden theme-gradient">Planning.</b>
                                            </span>
                                    </span>
                                    </span>
                                </h1>
                                <p class="description has-medium-font-size mt--20">Dive in and learn React.js from scratch! Learn Reactjs, Hooks, Redux, React Routing, Animations, Next.js and way more!
                                </p>
                                <div class="slider-btn rbt-button-group justify-content-center">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Log in to Start</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                    <a class="rbt-btn hover-icon-reverse btn-white" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Contact US</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Banner Area -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Banner_Widget() );