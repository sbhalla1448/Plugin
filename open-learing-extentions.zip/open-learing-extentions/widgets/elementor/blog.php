<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Blog_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'blog';
	}

	/**
	 * Get widget blog.
	 *
	 * Retrieve button widget blog.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget blog.
	 */
	public function get_title() {
		return esc_html__( 'Blog', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 6, '');

        $this->style_controls('title_style', 'Title Style', 2,  array(
            '_style' => 'style_6'
        ));

        $this->bg_controls('_select_bg', array(
            '_style' => 'style_3'
        ));

        $this->switch_control('_show_more', 'Show View All', null, array(
            '_style' => 'style_3'
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area rbt-section-gap bg-color-extra2">
            <div class="container">
                <div class="row g-5 align-items-center mb--30">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title">
                            <span class="subtitle bg-pink-opacity">Blog Post</span>
                            <h2 class="title">Post Popular Post.</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn btn-gradient hover-icon-reverse" href="blog.html">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">See All Articles</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row row--15">
                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 height-330 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-01.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h3 class="rbt-card-title"><a href="blog-details.html">React</a></h3>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12 mt--30">

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-02.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Why Is Education So Famous?</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-03.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Difficult Things About Education.</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-04.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Education Is So Famous, But Why?</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                    </div>
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Blog Style -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area rbt-section-gapTop bg-gradient-8 rbt-round-bottom-shape">
            <div class="wrapper pb--50 rbt-index-upper">
                <div class="container">
                    <div class="row g-5 align-items-end mb--60">
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="section-title text-start">
                                <h2 class="title color-white">Latest News</h2>
                                <p class="description color-white-off mt--20">Learning communicate to global world and build a bright future and career development, increase your skill with our histudy.</p>
                            </div>
                        </div>
                        <div class="col-lg-6 col-md-12 col-12">
                            <div class="load-more-btn text-start text-lg-end">
                                <a class="rbt-btn btn-border icon-hover radius-round color-white-off" href="blog.html">
                                    <span class="btn-text">See All Articles</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- Start Card Area -->
                    <div class="row g-5">
                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                            <div class="rbt-card variation-02 rbt-hover card-minimal">
                                <div class="rbt-card-body">
                                    <ul class="meta-list justify-content-start mb--30">
                                        <li class="list-item">
                                            <i class="feather-clock"></i>
                                            <span>20 March 2022</span>
                                        </li>
                                    </ul>
                                    <h4 class="rbt-card-title"><a href="blog-details.html">Learn From These You Learn Education.</a></h4>
                                    <div class="rbt-card-bottom mt--40">
                                        <a class="transparent-button" href="blog-details.html">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                            <div class="rbt-card variation-02 rbt-hover card-minimal">
                                <div class="rbt-card-body">
                                    <ul class="meta-list justify-content-start mb--30">
                                        <li class="list-item">
                                            <i class="feather-clock"></i>
                                            <span>30 May 2022</span>
                                        </li>
                                    </ul>
                                    <h4 class="rbt-card-title"><a href="blog-details.html">Think You're An Expert In Education?</a></h4>
                                    <div class="rbt-card-bottom mt--40">
                                        <a class="transparent-button" href="blog-details.html">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                            <div class="rbt-card variation-02 rbt-hover card-minimal">
                                <div class="rbt-card-body">
                                    <ul class="meta-list justify-content-start mb--30">
                                        <li class="list-item">
                                            <i class="feather-clock"></i>
                                            <span>15 July 2022</span>
                                        </li>
                                    </ul>
                                    <h4 class="rbt-card-title"><a href="blog-details.html">Seven Easy Rules Of Education.</a></h4>
                                    <div class="rbt-card-bottom mt--40">
                                        <a class="transparent-button" href="blog-details.html">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                    </div>
                    <!-- End Card Area -->
                </div>
            </div>
        </div>
        <!-- End Blog Style -->
        <?php elseif( $settings['_style'] == 'style_3' ): 
            
        ?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area rbt-section-gap <?php echo esc_attr($settings['_select_bg']); ?>">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Histudy Post</span>
                            <h2 class="title">From Our Post.</h2>
                            <p class="description has-medium-font-size mt--20">There are many variations of passages of the
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                            </p>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5 mt--30">

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-01.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Is Kindergarten The Most Trending Thing Now?</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-02.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Learn How More Money With Kindergarten.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-03.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Understand The Background Of Kindergarten Now.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                </div>
                <!-- End Card Area -->
                <?php if( $settings['_show_more'] == 'yes' ): ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="load-more-btn mt--60 text-center">
                            <a class="rbt-btn rbt-marquee-btn" href="#">
                                <span data-text="View All Post">
                                    View All Post
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <!-- End Blog Style -->
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area rbt-section-gapTop bg-color-white" id="blog">
            <div class="container">
                <div class="row g-5 align-items-end mb--30">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="section-title text-start">
                            <h2 class="title">Our Research</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="load-more-btn text-start text-lg-end">
                            <a class="rbt-btn-link" href="#">Browse Histudy Post<i class="feather-arrow-right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row g-5 mt--30">
                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-01.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Is University The Most Trending
                                        Thing Now?</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-02.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Learn How More Money With
                                        University.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-03.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Understand The Background Of
                                        University Now.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Blog Style -->
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row mb--30 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-primary-opacity">Our Blog</span>
                            <h2 class="title">Histudy Blog</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn btn-gradient hover-icon-reverse radius-round" href="blog.html">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">VIEW ALL POST</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row row--15">
                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12 mt--30">
                        <div class="rbt-card variation-02 height-330 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-01.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h3 class="rbt-card-title"><a href="blog-details.html">React</a></h3>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                    <div class="col-lg-6 col-md-12 col-sm-12 col-12 mt--30">

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-02.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Why Is Education So Famous?</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-03.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Difficult Things About Education.</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="rbt-card card-list variation-02 rbt-hover mt--30">
                            <div class="rbt-card-img">
                                <a href="blog-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-card-04.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="blog-details.html">Education Is So Famous, But Why?</a></h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="blog-details.html">Read Article<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                    </div>
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Blog Style -->
        <?php elseif( $settings['_style'] == 'style_6' ):
            $subtitle_class = 'bg-secondary-opacity'; 
            if( $settings['_title_style'] == 'style_2' ){
                $subtitle_class = 'bg-pink-opacity'; 
            }
        ?>
        <!-- Start Blog Style -->
        <div class="rbt-rbt-blog-area rbt-section-gapTop bg-color-white">
            <div class="container">

                <div class="row mb--55 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle <?php echo esc_attr($subtitle_class); ?>">Latest News</span>
                            <?php if( $settings['_title_style'] == 'style_1' ): ?>
                            <h2 class="title">Have a look on our news</h2>
                            <?php else: ?>
                            <h2 class="title">Have a look on <span class="color-primary">our News</span></h2>
                            <?php endif; ?>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <?php if( $settings['_title_style'] == 'style_1' ): ?>
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-moderbt-btn" href="#">
                                <span class="moderbt-btn-text">View All News</span>
                                <i class="feather-arrow-right"></i>
                            </a>
                        </div>
                        <?php else: ?>
                        <div class="load-more-btn text-start text-md-end">
                            <a class="rbt-btn rbt-switch-btn bg-primary-opacity" href="blog.html">
                                <span data-text="View All News">View All News</span>
                            </a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-04.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Is lms The Most Trending
                                        Thing Now?</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-05.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Learn How More Money With
                                        lms.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-02 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/blog/blog-grid-06.jpg" alt="Card image"> </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Understand The Background Of
                                        lms.</a></h5>
                                <p class="rbt-card-text">It is a long established fact that a reader.</p>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html">Learn
                                        More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Blog Style -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Blog_Widget() );