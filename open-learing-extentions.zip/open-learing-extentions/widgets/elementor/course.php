<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Course_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'course';
	}

	/**
	 * Get widget course.
	 *
	 * Retrieve button widget course.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget course.
	 */
	public function get_title() {
		return esc_html__( 'Course', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 17, '', 'style_10');
        $this->switch_control('_show_btn', 'Show Button', null, array(
            '_style' => 'style_4'
        ));

        $this->text_control('_section_title', 'Section Title', 'OLC Courses', array(
            '_style'    => 'style_10'
        ));

        $this->textarea_control('_section_subtitle', 'Section Subtitle', 'OLC ALL Courses', array(
            '_style'    => 'style_10'
        ));

        $this->repeater_controls('style_10_tab_list', 'Tab List', array(
            array(
                'name'  => '_tab_title',
                'label' => esc_html__( 'Tab Title', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'name'      => '_tab_courses',
                'label'     => esc_html__( 'Tab Courses', 'open-learning-ex' ),
                'type'      => \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
                'options'   => $this->get_courses(),
            ),
        ));

        $this->end_controls_section();
    }

    protected function get_courses(){
        $_courses = get_posts(array(
            'post_type' => 'courses',
            'order'     => 'DESC'
        ));

        $courses_array = array();

        foreach($_courses as $course){
            $courses_array[$course->ID] = $course->post_title;
        }

        return $courses_array;
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_section_title_typo', 'Section Title Typography', '.rbt-course-area .section-title .subtitle');
        $this->background_control('_section_title_background', 'Section Title Background', '.rbt-course-area .section-title .subtitle');
        $this->color_control('_section_title_color', 'Section Title Color', '.rbt-course-area .section-title .subtitle');

        $this->typography_control('_section_subtitle_typo', 'Section subtitle typography', '.rbt-course-area .section-title .title');
        $this->color_control('_section_subtitle_color', 'Section subtitle Color', '.rbt-course-area .section-title .title');
        $this->background_control('_section_subtitle_background', 'Section subtitle Background', '.rbt-course-area .section-title .title');


        $this->end_controls_section();

        $this->start_controls_section(
			'course_style',
			[
				'label' => esc_html__( 'Course Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_tab_title', 'Tab Title Typography', '.rbt-course-area .filter-tab-button button');
        $this->color_control('_tab_title_color', 'Tab Title Color', '.rbt-course-area .filter-tab-button button span');

        $this->background_control('_tab_background', 'Tab Background', '.rbt-course-area .filter-tab-button button');
        $this->background_control('_tab_active_background', 'Tab Active Background', '.rbt-course-area .filter-tab-button button.active');
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => '_tab_box_shadow',
				'selector' => '{{WRAPPER}} .rbt-course-area .filter-tab-button button',
			]
		);


        $this->background_control('_card_background', 'Card Background', '.rbt-course-area .rbt-card');
        $this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => 'box_shadow',
				'selector' => '{{WRAPPER}} .rbt-course-area .rbt-card',
			]
		);

        $this->typography_control('_card_title', 'Card Title Typography', '.rbt-course-area .rbt-card .rbt-card-body .rbt-card-title');
        $this->color_control('_card_title_color', 'Card Title Color', '.rbt-course-area .rbt-card .rbt-card-body .rbt-card-title a');

        $this->color_control('_card_meta_color', 'Card Meta Color', '.rbt-course-area .rbt-meta li');

        $this->typography_control('_card_body_text', 'Card Body Text Typography', '.rbt-course-area .rbt-card .rbt-card-body .rbt-card-text');
        $this->color_control('_card_body_text_color', 'Card Body Text Color', '.rbt-course-area .rbt-card .rbt-card-body .rbt-card-text');
        $this->color_control('_card_author_info_color', 'Card Author Info Color', '.rbt-course-area .rbt-card .rbt-author-meta .rbt-author-info');
        $this->color_control('_card_author_info_link_color', 'Card Author Info Link Color', '.rbt-course-area .rbt-card .rbt-author-meta .rbt-author-info a');
        $this->color_control('_card_enroll_btn_color', 'Card Enroll Button Text Color', '.rbt-course-area .rbt-card .rbt-card-body .rbt-card-bottom .rbt-btn-link');


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
		<!-- Start Course Area -->
        <div class="rbt-course-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Top Popular Course</span>
                            <h2 class="title">Histudy Course student <br /> can join with us.</h2>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-01.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-50%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">

                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>20 Lessons</li>
                                    <li><i class="feather-users"></i>40 Students</li>
                                </ul>
                                <p class="rbt-card-text">React Js long fact that a reader will be distracted by
                                    the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                    </div>
                                </div>

                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-02.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner + Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <p class="rbt-card-text">It is a long established fact that a reader will be distracted
                                    by the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-03.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->
                </div>
                <!-- End Card Area -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="load-more-btn mt--60 text-center">
                            <a class="rbt-btn btn-gradient btn-lg hover-icon-reverse" href="#">
                                <span class="icon-reverse-wrapper">
                                    <span class="btn-text">Load More Course (40)</span>
                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Course Area -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Featured Course Area  -->
        <div class="rbt-featured-course bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 align-items-end mb--60">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="section-title text-start">
                            <h2 class="title">Featured Courses</h2>
                            <p class="description mt--20">Learning communicate to global world and build a bright future and career development, increase your skill with our histudy.</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="load-more-btn text-start text-lg-end">
                            <a class="rbt-btn btn-border icon-hover radius-round" href="#">
                                <span class="btn-text">Browse Histudy Courses</span>
                                <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-01.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>

                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-03.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-10%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-04.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To Back</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>20 Lessons</li>
                                    <li><i class="feather-users"></i>40 Students</li>
                                </ul>
                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted by
                                    the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                    </div>
                                </div>

                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-05.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-20%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted
                                    by the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-06.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">JS Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Featured Course Area  -->
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- Start Call To Action  -->
        <div class="rbt-callto-action-area mt_dec--half">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12 col-xl-5">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">New Collection</a>
                                        </div>
                                        <h4 class="title mb--15">Online Courses from Histudy</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-xl-7">
                                    <div class="video-popup-wrapper mt_lg--10 mt_md--20 mt_sm--20">
                                        <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-01.jpg" alt="Video Images">
                                        <a class="rbt-btn rounded-player-2 sm-size popup-video position-to-top with-animation" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                            <span class="play-icon"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">Top Teacher</a>
                                        </div>
                                        <h4 class="title mb--10">Free Online Courses from Histudy School To Education</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                        <div class="read-more-btn">
                                            <a class="rbt-btn rbt-switch-btn btn-gradient btn-sm" href="#">
                                                <span data-text="Join Now">Join Now</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Call To Action  -->
        <!-- Start Course Area -->
        <div class="rbt-course-area bg-color-light rbt-section-gap default-callto-action-overlap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Histudy Course</span>
                            <h2 class="title">Weekly Online Classes.</h2>
                            <p class="description has-medium-font-size mt--20">There are many variations of passages of the
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                            </p>
                        </div>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row g-5">

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/kindergarten-course-01.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover">
                                        <span class="btn-text">Join Now</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Ten Reliable Sources To Learn About Education.</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/kindergarten-course-03.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover">
                                        <span class="btn-text">Join Now</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Five Things You Should Do In Education.</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/kindergarten-course-02.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover">
                                        <span class="btn-text">Join Now</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Five Ways To Learn Education Effectively.</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                </div>
                <!-- End Card Area -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="load-more-btn mt--60 text-center">
                            <a class="rbt-btn rbt-marquee-btn" href="#">
                                <span data-text="Load More Course">
                                    Load More Course
                                </span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End Course Area -->
        <?php elseif( $settings['_style'] == 'style_4' ):
            $style_4_class = 'rbt-section-gapTop';
            if( $settings['_show_btn'] == 'yes' ){
                $style_4_class = 'rbt-section-gapBottom';
            }
        ?>
        <!-- Start Our Course Area  -->
        <div class="rbt-course-area bg-color-white <?php echo esc_attr($style_4_class); ?>" id="course">
            <div class="container">
                <?php if( $settings['_show_btn'] == 'yes' ): ?>
                <div class="row g-5 align-items-center mb--50">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title">
                            <h2 class="title">Course Outline</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="load-more-btn text-start text-md-end">
                            <a class="rbt-btn btn-gradient rbt-marquee-btn radius-round" href="#">
                                <span data-text="View All Courses">
                                    View All Courses
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
                <?php else: ?>
                <div class="row g-5 align-items-end mb--60">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="section-title text-start">
                            <h2 class="title">Our Online Courses</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="load-more-btn text-start text-lg-end">
                            <a class="rbt-btn-link" href="#">Browse Histudy Courses<i class="feather-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row g-5">
                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>

                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                    <?php if( $settings['_show_btn'] == 'yes' ): ?>
                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>

                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                    <!-- Start Single Card  -->
                    <div class="col-lg-6 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <!-- End Our Course Area  -->
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <!-- Start Video Area  -->
        <div class="rbt-courses-area rbt-section-gapBottom bg-color-white mt_dec--100 mt_md_dec--30 mt_sm_dec--30">
            <div class="container">
                <div class="row">
                    <div class="col-lg-10 offset-lg-1 mt_dec--50">

                        <!-- Start Single Card  -->
                        <div class="course-card mt--50">
                            <div class="rbt-card variation-01 rbt-hover elegant-course card-list-2">
                                <div class="rbt-card-img">
                                    <a href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-01.jpg" alt="Card image">
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <div class="rbt-card-top">
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-bookmark-btn">
                                            <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                        </div>
                                    </div>

                                    <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                    </h4>

                                    <ul class="rbt-meta mb--10">
                                        <li><i class="feather-book"></i>12 Lessons</li>
                                        <li><i class="feather-users"></i>50 Students</li>
                                    </ul>

                                    <p class="rbt-card-text">Histudy is elegant template.</p>

                                    <ul class="rbt-meta rbt-meta-badge mb--20">
                                        <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                    </ul>

                                    <div class="rbt-author-meta mb--10">
                                        <div class="rbt-avater">
                                            <a href="#">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                            </a>
                                        </div>
                                        <div class="rbt-author-info">
                                            By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                        </div>
                                    </div>
                                    <div class="rbt-card-bottom">
                                        <div class="rbt-price">
                                            <span class="current-price">$120</span>
                                            <span class="off-price">$200</span>
                                        </div>
                                        <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="course-card mt--50">
                            <div class="rbt-card variation-01 rbt-hover elegant-course card-list-2">
                                <div class="rbt-card-img">
                                    <a href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-02.jpg" alt="Card image">
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <div class="rbt-card-top">
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-bookmark-btn">
                                            <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                        </div>
                                    </div>

                                    <h4 class="rbt-card-title"><a href="course-details.html">English Popular Course</a>
                                    </h4>

                                    <ul class="rbt-meta mb--10">
                                        <li><i class="feather-book"></i>12 Lessons</li>
                                        <li><i class="feather-users"></i>50 Students</li>
                                    </ul>

                                    <p class="rbt-card-text">Histudy is elegant template.</p>

                                    <ul class="rbt-meta rbt-meta-badge mb--20">
                                        <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                    </ul>

                                    <div class="rbt-author-meta mb--10">
                                        <div class="rbt-avater">
                                            <a href="#">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                            </a>
                                        </div>
                                        <div class="rbt-author-info">
                                            By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                        </div>
                                    </div>
                                    <div class="rbt-card-bottom">
                                        <div class="rbt-price">
                                            <span class="current-price">$60</span>
                                            <span class="off-price">$150</span>
                                        </div>
                                        <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="course-card mt--50">
                            <div class="rbt-card variation-01 rbt-hover elegant-course card-list-2">
                                <div class="rbt-card-img">
                                    <a href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-03.jpg" alt="Card image">
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <div class="rbt-card-top">
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-bookmark-btn">
                                            <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                        </div>
                                    </div>

                                    <h4 class="rbt-card-title"><a href="course-details.html">App Development</a>
                                    </h4>

                                    <ul class="rbt-meta mb--10">
                                        <li><i class="feather-book"></i>12 Lessons</li>
                                        <li><i class="feather-users"></i>50 Students</li>
                                    </ul>

                                    <p class="rbt-card-text">Histudy is elegant template.</p>

                                    <ul class="rbt-meta rbt-meta-badge mb--20">
                                        <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                        <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                    </ul>

                                    <div class="rbt-author-meta mb--10">
                                        <div class="rbt-avater">
                                            <a href="#">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                            </a>
                                        </div>
                                        <div class="rbt-author-info">
                                            By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                        </div>
                                    </div>
                                    <div class="rbt-card-bottom">
                                        <div class="rbt-price">
                                            <span class="current-price">$30</span>
                                            <span class="off-price">$50</span>
                                        </div>
                                        <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                    </div>
                </div>
            </div>
        </div>
        <!-- End Video Area  -->
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <!-- Start Special Course  -->
        <div class="rbt-course-area bg-color-white">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center mb--60">
                            <h2 class="title">Special Crash Course.</h2>
                            <p class="description mt--30">Far far away, behind the word mountains, far from the
                                countries Vokalia and Consonantia, there live the blind texts.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="row g-5">

                            <div class="col-lg-6 col-xl-4 col-md-6 col-12">
                                <div class="rbt-card variation-01 rbt-hover elegant-course">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-05.jpg" alt="Card image">
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <div class="rbt-card-top">
                                            <div class="rbt-review">
                                                <div class="rating">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                </div>
                                                <span class="rating-count"> (15 Reviews)</span>
                                            </div>
                                            <div class="rbt-bookmark-btn">
                                                <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                            </div>
                                        </div>

                                        <h4 class="rbt-card-title"><a href="course-details.html">Graphic Design</a>
                                        </h4>

                                        <ul class="rbt-meta mb--10">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>

                                        <p class="rbt-card-text">Histudy is elegant template.</p>

                                        <ul class="rbt-meta rbt-meta-badge mb--20">
                                            <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                        </ul>

                                        <div class="rbt-author-meta mb--10">
                                            <div class="rbt-avater">
                                                <a href="#">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                </a>
                                            </div>
                                            <div class="rbt-author-info">
                                                By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                            </div>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price">$120</span>
                                                <span class="off-price">$200</span>
                                            </div>
                                            <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-xl-4 col-md-6 col-12">
                                <div class="rbt-card variation-01 rbt-hover elegant-course">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-04.jpg" alt="Card image">
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <div class="rbt-card-top">
                                            <div class="rbt-review">
                                                <div class="rating">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                </div>
                                                <span class="rating-count"> (15 Reviews)</span>
                                            </div>
                                            <div class="rbt-bookmark-btn">
                                                <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                            </div>
                                        </div>

                                        <h4 class="rbt-card-title"><a href="course-details.html">Web Development</a>
                                        </h4>

                                        <ul class="rbt-meta mb--10">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>

                                        <p class="rbt-card-text">Histudy is elegant template.</p>

                                        <ul class="rbt-meta rbt-meta-badge mb--20">
                                            <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                        </ul>

                                        <div class="rbt-author-meta mb--10">
                                            <div class="rbt-avater">
                                                <a href="#">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                </a>
                                            </div>
                                            <div class="rbt-author-info">
                                                By <a href="#">Nipa</a> In <a href="#">Development</a>
                                            </div>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price">$60</span>
                                                <span class="off-price">$150</span>
                                            </div>
                                            <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="col-lg-6 col-xl-4 col-md-6 col-12">
                                <div class="rbt-card variation-01 rbt-hover elegant-course">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-elegant-06.jpg" alt="Card image">
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <div class="rbt-card-top">
                                            <div class="rbt-review">
                                                <div class="rating">
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                    <i class="fas fa-star"></i>
                                                </div>
                                                <span class="rating-count"> (15 Reviews)</span>
                                            </div>
                                            <div class="rbt-bookmark-btn">
                                                <a class="rbt-round-btn" title="Bookmark" href="#"><i class="feather-bookmark"></i></a>
                                            </div>
                                        </div>

                                        <h4 class="rbt-card-title"><a href="course-details.html">Social Marketing</a>
                                        </h4>

                                        <ul class="rbt-meta mb--10">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>

                                        <p class="rbt-card-text">Histudy is elegant template.</p>

                                        <ul class="rbt-meta rbt-meta-badge mb--20">
                                            <li><a href="#"><span class="rbt-badge">HTML5</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Web3</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">React</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Hook</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">API</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">NFT</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Crypto</span></a></li>
                                            <li><a href="#"><span class="rbt-badge">Bitcoin</span></a></li>
                                        </ul>

                                        <div class="rbt-author-meta mb--10">
                                            <div class="rbt-avater">
                                                <a href="#">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-04.png" alt="Sophia Jaymes">
                                                </a>
                                            </div>
                                            <div class="rbt-author-info">
                                                By <a href="#">Fatima</a> In <a href="#">Development</a>
                                            </div>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price">$30</span>
                                                <span class="off-price">$50</span>
                                            </div>
                                            <a class="rbt-btn-link left-icon" href="course-details.html"><i class="feather-shopping-cart"></i> Add To Cart</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Special Course  -->
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
        <!-- Start Card Style -->
        <div class="rbt-course-card-area rbt-section-gap bg-color-white">
            <div class="container">
                <div class="row g-5 mb--60 align-items-center">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">Choose The <span class="theme-gradient">Program</span></h2>
                            <p class="description mt--20">Are You Want to <strong>Change Your Life?</strong></p>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-01.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Fitness Consultation</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/runner.png" alt="united-kingdom">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-02.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Powerful and Strong</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/power.png" alt="Education Images">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-03.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Personal Training</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/runner.png" alt="Education Images">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-04.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Fit And Sports</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/runner.png" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-05.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Keep Your Body</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/runner.png" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover program-image-large">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-program-06.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">Strongest Self</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/runner.png" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Card Style -->
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <div class="rbt-course-area rbt-section-gap bg-gradient-8 masonary-wrapper-activation">
            <div class="container">
                <div class="row row--15 align-items-center mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title color-white">Latest GYM <span class="color-white">Courses</span></h2>
                            <p class="description mt--20 color-white">Are You Want to <strong>Change Your Life?</strong></p>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="rbt-portfolio-filter filter-button-default messonry-button text-center mb--30">
                            <button data-filter="*" class="is-checked"><span class="filter-text">All Course</span></button>
                            <button data-filter=".cat--1" class=""><span class="filter-text">Featured</span></button>
                            <button data-filter=".cat--2"><span class="filter-text">Popular</span></button>
                            <button data-filter=".cat--3"><span class="filter-text">Trending</span></button>
                            <button data-filter=".cat--4"><span class="filter-text">Latest</span></button>
                        </div>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row row--15">
                    <div class="col-lg-12">
                        <div class="mesonry-list grid-metro3">
                            <div class="resizer"></div>
                            <!-- Start Single Card  -->
                            <div class="maso-item cat--1">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-01.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Seven Reasons You Fall In Love With Gym.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$60</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="maso-item cat--2">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-02.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Taboos About Gym You Should Share On Twitter.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$29</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="maso-item cat--3">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-03.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Ten Moments Basically Gym Experience.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$60</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="maso-item cat--4">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-04.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Common Miscon ceptions About Gym.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$60</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="maso-item cat--1 cat--3">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-05.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Eliminate Fears And Doubts About Gym.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$60</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="maso-item cat--2 cat--4">
                                <div class="rbt-card variation-01 rbt-hover">
                                    <div class="rbt-card-img">
                                        <a href="course-details.html">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/gym-06.jpg" alt="Card image">
                                            <div class="rbt-badge-3 bg-white">
                                                <span>-40%</span>
                                                <span>Off</span>
                                            </div>
                                        </a>
                                    </div>
                                    <div class="rbt-card-body">
                                        <ul class="rbt-meta">
                                            <li><i class="feather-book"></i>12 Lessons</li>
                                            <li><i class="feather-users"></i>50 Students</li>
                                        </ul>
                                        <h4 class="rbt-card-title"><a href="course-details.html">Benefits Gym Change Your Perspective.</a>
                                        </h4>
                                        <div class="rbt-review">
                                            <div class="rating">
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                                <i class="fas fa-star"></i>
                                            </div>
                                            <span class="rating-count"> (15 Reviews)</span>
                                        </div>
                                        <div class="rbt-card-bottom">
                                            <div class="rbt-price">
                                                <span class="current-price theme-gradient">$60</span>
                                            </div>
                                            <a class="rbt-btn-link" href="course-details.html">Learn
                                                More<i class="feather-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->
                        </div>
                        <!-- End Card Area -->
                    </div>
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="load-more-btn text-center mt--60">
                            <a class="rbt-btn radius-round btn-white rbt-switch-btn rbt-switch-y btn-lg" href="#">
                                <span data-text="View All Courses">View All Courses</span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_9' ): ?>
        <!-- Start Course Area  -->
        <div class="rbt-course-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row mb--60 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-primary-opacity">Live Course</span>
                            <h2 class="title">Special live course</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn btn-gradient hover-icon-reverse radius-round" href="#">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">VIEW ALL COURSES</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-04.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">

                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>20 Lessons</li>
                                    <li><i class="feather-users"></i>40 Students</li>
                                </ul>
                                <p class="rbt-card-text">React Js long fact that a reader will be distracted by
                                    the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                    </div>
                                </div>

                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-05.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner + Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <p class="rbt-card-text">It is a long established fact that a reader will be distracted
                                    by the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-06.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Course Area  -->
        <?php elseif( $settings['_style'] == 'style_10' ): ?>
        <!-- Start Course Area  -->
        <div class="rbt-course-area">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle"><?php echo esc_html($settings['_section_title']); ?></span>
                            <h2 class="title"><?php echo esc_html($settings['_section_subtitle']); ?></h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="rbt-portfolio-filter filter-tab-button text-center nav nav-tabs" id="rbt-myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true"><span class="filter-text">All
                            Courses</span></button>
                            </li>
                            <?php foreach( $settings['_style_10_tab_list'] as $tab_item ): ?>
                            <li class="nav-item <?php echo 'elementor-repeater-item-' . esc_attr( $tab_item['_id'] ); ?>" role="presentation">
                                <button id="<?php echo esc_attr(strtolower($tab_item['_tab_title'])); ?>-tab" data-bs-toggle="tab" data-bs-target="#<?php echo esc_attr(strtolower($tab_item['_tab_title'])); ?>" type="button" role="tab" aria-controls="<?php echo esc_attr(strtolower($tab_item['_tab_title'])); ?>" aria-selected="true"><span class="filter-text"><?php echo esc_attr($tab_item['_tab_title']); ?></span></button>
                            </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                </div>
                <!-- Start Card Area -->
                <?php
                    $_get_courses = olx_get_courses_by_filter();
                ?>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content mt--60" id="rbt-myTabContent">
                            <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">
                                <div class="row g-5">
                                    <?php if($_get_courses->have_posts()): ?>
                                    <?php while($_get_courses->have_posts()): $_get_courses->the_post(); ?>
                                    <!-- Start Single Course  -->
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                        <?php
                                            /**
                                             * Usage Idea, you may keep a loop within a wrap, such as bootstrap col
                                             *
                                             * @hook tutor_course/archive/before_loop_course
                                             * @type action
                                             */
                                            do_action( 'tutor_course/archive/before_loop_course' );

                                            tutor_load_template( 'loop.course' );

                                            /**
                                             * Usage Idea, If you start any div before course loop, you can end it here, such as </div>
                                             *
                                             * @hook tutor_course/archive/after_loop_course
                                             * @type action
                                             */
                                            do_action( 'tutor_course/archive/after_loop_course' );
                                        ?>
                                    </div>
                                    <!-- End Single Course  -->
                                    <?php endwhile; wp_reset_query(); ?>
                                    <?php else: ?>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                        <p>No course found!</p>
                                    </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <?php foreach( $settings['_style_10_tab_list'] as $tab_item ): ?>
                            <div class="tab-pane fade <?php echo 'elementor-repeater-item-' . esc_attr( $tab_item['_id'] ); ?>" id="<?php echo esc_attr(strtolower($tab_item['_tab_title'])); ?>" role="tabpanel" aria-labelledby="<?php echo esc_attr(strtolower($tab_item['_tab_title'])); ?>">
                                <div class="row g-5">
                                    <?php 
                                    $_get_tab_courses = olx_get_courses_by_filter('all', $tab_item['_tab_courses']);
                                    if($_get_tab_courses->have_posts()): 
                                    ?>
                                    <?php while($_get_tab_courses->have_posts()): $_get_tab_courses->the_post(); ?>
                                    <!-- Start Single Course  -->
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                        <?php
                                            do_action( 'tutor_course/archive/before_loop_course' );

                                            tutor_load_template( 'loop.course' );

                                            do_action( 'tutor_course/archive/after_loop_course' );
                                        ?>
                                    </div>
                                    <!-- End Single Course  -->
                                    <?php endwhile; wp_reset_query(); ?>
                                    <?php else: ?>
                                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                        <p>No course found!</p>
                                    </div>
                                    <?php endif;?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Course Area  -->
        <?php elseif( $settings['_style'] == 'style_11' ): ?>
        <div class="rbt-about-area about-style-1 bg-color-white rbt-section-gap">
            <div class="wrapper">
                <div class="container">
                    <div class="row g-5 align-items-start">
                        <div class="col-lg-4">
                            <div class="content">
                                <h2 class="title">Graduate Programs.</h2>
                            </div>
                        </div>
                        <div class="col-lg-4">
                            <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis, necessitatibus fuga dolore tenetur, beatae suscipit fugit est ea perspiciatis quo provident nisi dolor similique architecto nihil.</p>
                        </div>
                        <div class="col-lg-4">
                            <p>Graduate Programs dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis, necessitatibus fuga dolore tenetur, beatae suscipit fugit est ea perspiciatis quo provident nisi dolor similique architecto nihil.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="wrapper mt--60">
                <div class="container">
                    <div class="row g-5">

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-01.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">Biochemistry</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-02.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">Public Administration</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-03.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">Major In Marketing</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->


                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-02.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">Business Media</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-03.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">BSc in CSE</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                            <div class="rbt-card variation-03 rbt-hover">
                                <div class="rbt-card-img">
                                    <a class="thumbnail-link" href="course-details.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-online-06.jpg" alt="Card image">
                                        <span class="rbt-btn btn-white icon-hover">
                                            <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="rbt-card-body">
                                    <h5 class="rbt-card-title"><a href="course-details.html">Accounting</a>
                                    </h5>
                                    <div class="rbt-card-bottom">
                                        <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_12' ): ?>
        <!-- Start Course Banner Area  -->
        <div class="rbt-course-banner-area rbt-section-gap bg-color-white" id="guideline">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="inner">
                            <div class="section-title text-center mb--60">
                                <h2 class="title"><span class="theme-gradient">Complete guideline</span> from
                                    absolute <br /> beginners to getting hired.</h2>
                                <div class="rbt-button-group mt--30">
                                    <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Explore Course</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                    <a class="rbt-btn hover-icon-reverse btn-border" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Hired List</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>

                            <div class="row g-5">
                                <!-- Start Single Feature Box  -->
                                <div class="col-lg-12">
                                    <div class="modern-course-features-box h-100">
                                        <div class="inner">
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-feature-03.jpg" alt="Image">
                                            </div>
                                            <div class="content">
                                                <span class="rbt-badge-6 bg-secondary-opacity">Hello! Web Development Course</span>
                                                <h2 class="title mt--10">Complete app development course with HiStudy</h2>
                                                <p>The idea of establishing a private university to provide quality education at an affordable cost in Uk London.</p>
                                                <ul class="course-feature-list">
                                                    <li>
                                                        <div class="icon">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-1.png" alt="Image Icon">
                                                        </div>
                                                        <div class="feature-content">
                                                            <h4 class="featute-title">300K+ <span>Got Hired</span></h4>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-4.png" alt="Image Icon">
                                                        </div>
                                                        <div class="feature-content">
                                                            <h4 class="featute-title">10K+ <span>Enrolled</span></h4>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-2.png" alt="Image Icon">
                                                        </div>
                                                        <div class="feature-content">
                                                            <h4 class="featute-title">300K+ <span>Month Required</span></h4>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Feature Box  -->

                                <!-- Start Single Feature Box  -->
                                <div class="col-lg-6">
                                    <div class="modern-course-features-box one-colume-grid h-100">
                                        <div class="inner">
                                            <div class="thumbnail">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-feature-01.jpg" alt="Image">
                                            </div>
                                            <div class="content">
                                                <h2 class="title">Get a Certificate</h2>
                                                <p>Apply for Admission in Post Graduate Diploma. Application Deadline: 26th September year Undergraduate.</p>
                                                <ul class="course-feature-list">
                                                    <li>
                                                        <div class="icon">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-11.png" alt="Image Icon">
                                                        </div>
                                                        <div class="feature-content">
                                                            <h4 class="featute-title">5000+ <span>Get Award</span></h4>
                                                        </div>
                                                    </li>
                                                    <li>
                                                        <div class="icon">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-12.png" alt="Image Icon">
                                                        </div>
                                                        <div class="feature-content">
                                                            <h4 class="featute-title">10K+ <span>Zero to career </span></h4>
                                                        </div>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Feature Box  -->

                                <!-- Start Single Feature Box  -->
                                <div class="col-lg-6">
                                    <div class="modern-course-features-box grid-content-reverse h-100">
                                        <div class="inner">
                                            <div class="rbt-image-gallery-wrapper">
                                                <div class="swiper modern-course-carousel-activation rbt-arrow-between">
                                                    <div class="swiper-wrapper">
                                                        <div class="swiper-slide">
                                                            <div class="thumbnail mt--0">
                                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-feature-02.jpg" alt="Image">
                                                            </div>
                                                        </div>
                                                        <div class="swiper-slide">
                                                            <div class="thumbnail mt--0">
                                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-feature-01.jpg" alt="Image">
                                                            </div>
                                                        </div>
                                                    </div>

                                                    <div class="rbt-swiper-arrow rbt-arrow-left">
                                                        <div class="custom-overfolow">
                                                            <i class="rbt-icon feather-arrow-left"></i>
                                                            <i class="rbt-icon-top feather-arrow-left"></i>
                                                        </div>
                                                    </div>

                                                    <div class="rbt-swiper-arrow rbt-arrow-right">
                                                        <div class="custom-overfolow">
                                                            <i class="rbt-icon feather-arrow-right"></i>
                                                            <i class="rbt-icon-top feather-arrow-right"></i>
                                                        </div>
                                                    </div>

                                                </div>
                                            </div>
                                            <div class="content">
                                                <h2 class="title">Projects You Will Build</h2>
                                                <p>Apply for Admission in Post Graduate Diploma. Application Deadline: 26th September year Undergraduate.</p>
                                                <ul class="rbt-list-style-2 flex-wrap">
                                                    <li><i class="feather-check"></i>Ecommerce Website</li>
                                                    <li><i class="feather-check"></i>Travel Agency</li>
                                                    <li><i class="feather-check"></i>Shopping Cart</li>
                                                    <li><i class="feather-check"></i>News Portal</li>
                                                    <li><i class="feather-check"></i>Education Management</li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Feature Box  -->
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Course Banner Area  -->
        <?php elseif( $settings['_style'] == 'style_13' ): ?>
        <!-- Start Course Content  -->
        <div class="rbt-course-content rbt-section-gap bg-color-extra2" id="coursecontent">
            <div class="container">
                <div class="row align-items-end mb--60">
                    <div class="col-lg-6 col-md-6">
                        <div class="section-title text-start">
                            <h2 class="title">Course Content</h2>
                            <p class="description has-small-font-size mt--10">32 sections • 376 lectures • 27h 8m total
                                length</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6">
                        <div class="expend-button text-start text-md-end">
                            <a class="rbt-btn-link w-700" href="#">Expand all sections<i
                                    class="feather-arrow-right"></i></a>
                        </div>
                    </div>
                </div>

                <div class="row gy-5 row--30">
                    <div class="col-lg-6">
                        <div class="feature-course-thumbnail">
                            <div class="video-popup-wrapper rbt-shadow-box">
                                <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-content.jpg" alt="Card image">
                                <a class="rbt-btn rounded-player-2 popup-video position-to-top with-animation btn-white-color" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                    <span class="play-icon"></span>
                                </a>
                            </div>
                            <div class="enroll-btn mt--15">
                                <a class="rbt-btn btn-gradient hover-icon-reverse w-100 radius-round" href="#">
                                    <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Continue Course</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6 rbt-scroll-max-height rbt-scroll">
                        <div class="course-content">
                            <div class="rbt-accordion-style rbt-accordion-02 right-no-padding accordion">
                                <div class="accordion" id="accordionExampleb2">
                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo1">
                                            <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo1" aria-expanded="true" aria-controls="collapseTwo1">
                                                Intro to Course and Histudy
                                            </button>
                                        </h2>
                                        <div id="collapseTwo1" class="accordion-collapse collapse show" aria-labelledby="headingTwo1" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right">
                                                                <span class="rbt-badge bg-pink-opacity">30 min</span>
                                                                <span class="rbt-badge bg-primary-opacity">Preview</span>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Watch
                                                                    Before
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right">
                                                                <span class="rbt-badge bg-pink-opacity">0.5 min</span>
                                                                <span class="rbt-badge bg-primary-opacity">Preview</span>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right">
                                                                <span class="rbt-badge bg-pink-opacity">0.5 min</span>
                                                                <span class="rbt-badge bg-primary-opacity">Preview</span>
                                                            </div>
                                                        </a></li>

                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo2">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo2" aria-expanded="false" aria-controls="collapseTwo2">
                                                Course Fundamentals
                                            </button>
                                        </h2>
                                        <div id="collapseTwo2" class="accordion-collapse collapse" aria-labelledby="headingTwo2" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go To Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo3">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo3" aria-expanded="false" aria-controls="collapseTwo3">
                                                You can develop skill and setup
                                            </button>
                                        </h2>
                                        <div id="collapseTwo3" class="accordion-collapse collapse" aria-labelledby="headingTwo3" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo4">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo4" aria-expanded="false" aria-controls="collapseTwo4">
                                                15 Things To Know About Education?
                                            </button>
                                        </h2>
                                        <div id="collapseTwo4" class="accordion-collapse collapse" aria-labelledby="headingTwo4" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo5">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo5" aria-expanded="false" aria-controls="collapseTwo5">
                                                Course Description
                                            </button>
                                        </h2>
                                        <div id="collapseTwo5" class="accordion-collapse collapse" aria-labelledby="headingTwo5" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo6">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo6" aria-expanded="false" aria-controls="collapseTwo6">
                                                Route 53
                                            </button>
                                        </h2>
                                        <div id="collapseTwo6" class="accordion-collapse collapse" aria-labelledby="headingTwo6" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo7">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo7" aria-expanded="false" aria-controls="collapseTwo7">
                                                EC2 Instance Storage
                                            </button>
                                        </h2>
                                        <div id="collapseTwo7" class="accordion-collapse collapse" aria-labelledby="headingTwo7" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo8">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo8" aria-expanded="false" aria-controls="collapseTwo8">
                                                IAM & AWS CLI
                                            </button>
                                        </h2>
                                        <div id="collapseTwo8" class="accordion-collapse collapse" aria-labelledby="headingTwo8" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo9">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo9" aria-expanded="false" aria-controls="collapseTwo9">
                                                Getting started with AWS
                                            </button>
                                        </h2>
                                        <div id="collapseTwo9" class="accordion-collapse collapse" aria-labelledby="headingTwo9" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>

                                    <div class="accordion-item card">
                                        <h2 class="accordion-header card-header" id="headingTwo10">
                                            <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#collapseTwo10" aria-expanded="false" aria-controls="collapseTwo10">
                                                EC2 Fundamentals
                                            </button>
                                        </h2>
                                        <div id="collapseTwo10" class="accordion-collapse collapse" aria-labelledby="headingTwo10" data-bs-parent="#accordionExampleb2">
                                            <div class="accordion-body card-body">
                                                <ul class="rbt-course-main-content liststyle">
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span
                                                                    class="text">Course Intro</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Why
                                                                    You Should Not Go
                                                                    To
                                                                    Education.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>


                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-play-circle"></i> <span class="text">Ten
                                                                    Factors That
                                                                    Affect Education's
                                                                    Longevity.</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>

                                                    <li><a href="#">
                                                            <div class="course-content-left">
                                                                <i class="feather-file-text"></i> <span class="text">Read
                                                                    Before You
                                                                    Start</span>
                                                            </div>
                                                            <div class="course-content-right only-lock">
                                                                <i class="feather-lock"></i>
                                                            </div>
                                                        </a></li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End Course Content  -->
        <?php elseif( $settings['_style'] == 'style_14' ): ?>
        <!-- Start Course Area -->
        <div class="rbt-course-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title"><span class="theme-gradient">New</span> Online Courses</h2>
                            <p class="description has-medium-font-size mt--20">Learning new technology, data sience,
                                university, communicate to global world and build a bright future with our histudy.</p>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-01.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="course-details.html">React Js</a>
                                </h4>
                                <p class="rbt-card-text">It is a long established fact that a reader will be distracted by
                                    the readable content of a page when looking at its layout.</p>
                                <div class="rbt-review">
                                    <div class="rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <span class="rating-count"> (15 Reviews)</span>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-02.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="course-details.html">Javascript</a>
                                </h4>
                                <p class="rbt-card-text">It is a long established fact that a reader will be distracted by
                                    the readable content of a page when looking at its layout.</p>
                                <div class="rbt-review">
                                    <div class="rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <span class="rating-count"> (15 Reviews)</span>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-03.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Js</a>
                                </h4>
                                <p class="rbt-card-text">It is a long established fact that a reader will be distracted by
                                    the readable content of a page when looking at its layout.</p>
                                <div class="rbt-review">
                                    <div class="rating">
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                        <i class="fas fa-star"></i>
                                    </div>
                                    <span class="rating-count"> (15 Reviews)</span>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Course Area -->
        <?php elseif( $settings['_style'] == 'style_15' ): ?>
        <!-- Start Card Style -->
        <div class="rbt-course-card-area rbt-section-gap bg-color-white">
            <div class="container">
                <div class="row align-items-center mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">Our Language Courses</span>
                            <h2 class="title">Language Courses</h2>
                            <p class="description has-medium-font-size mt--20">Language Academy Courses?</p>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-01.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">English Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/united-kingdom.svg" alt="united-kingdom">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-02.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">French Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/france.svg" alt="Education Images">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-03.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">German Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/germany.svg" alt="Education Images">
                                </div>
                                <div class="card-count">21 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-04.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">italian Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/italy.svg" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-05.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">japan Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/japan.svg" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-4 col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card variation-03 rbt-hover">
                            <div class="rbt-card-img">
                                <a class="thumbnail-link" href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/language-academy-06.jpg" alt="Card image">
                                    <span class="rbt-btn btn-white icon-hover btn-md">
                                        <span class="btn-text">Read More</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <h5 class="rbt-card-title"><a href="course-details.html">korea Courses</a>
                                </h5>
                                <div class="rbt-card-bottom">
                                    <a class="transparent-button" href="course-details.html"><i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                </div>
                            </div>
                            <div class="card-information">
                                <div class="card-flag">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/south-korea.svg" alt="Education Images">
                                </div>
                                <div class="card-count">5 programs</div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Card Style -->
        <?php elseif( $settings['_style'] == 'style_16' ): ?>
        <!-- Start Course Area -->
        <div class="rbt-course-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--55 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-pink-opacity">Top Popular Course</span>
                            <h2 class="title">Most Popular <span class="color-primary">Courses</span></h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="load-more-btn text-start text-md-end">
                            <a class="rbt-btn rbt-switch-btn bg-primary-opacity" href="course.html">
                                <span data-text="View All Course">View All Course</span>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row g-5">
                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-01.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To Back</a>
                                </h4>

                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-02.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>

                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted.</p>
                                <div class="rbt-author-meta mb--10">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Course  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-03.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Course  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-04.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>

                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To Back</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>20 Lessons</li>
                                    <li><i class="feather-users"></i>40 Students</li>
                                </ul>
                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted by
                                    the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                    </div>
                                </div>

                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-05.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (15 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner Advanced</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>12 Lessons</li>
                                    <li><i class="feather-users"></i>50 Students</li>
                                </ul>
                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                    distracted
                                    by the readable.</p>
                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$60</span>
                                        <span class="off-price">$120</span>
                                    </div>
                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="rbt-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="course-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/classic-lms-06.jpg" alt="Card image">
                                    <div class="rbt-badge-3 bg-white">
                                        <span>-40%</span>
                                        <span>Off</span>
                                    </div>
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <div class="rbt-card-top">
                                    <div class="rbt-review">
                                        <div class="rating">
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                            <i class="fas fa-star"></i>
                                        </div>
                                        <span class="rating-count"> (5 Reviews)</span>
                                    </div>
                                    <div class="rbt-bookmark-btn">
                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                class="feather-bookmark"></i></a>
                                    </div>
                                </div>
                                <h4 class="rbt-card-title"><a href="course-details.html">JS Zero to Mastery</a>
                                </h4>
                                <ul class="rbt-meta">
                                    <li><i class="feather-book"></i>8 Lessons</li>
                                    <li><i class="feather-users"></i>30 Students</li>
                                </ul>
                                <p class="rbt-card-text">Angular Js long fact that a reader will be distracted by
                                    the readable.</p>

                                <div class="rbt-author-meta mb--20">
                                    <div class="rbt-avater">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                        </a>
                                    </div>
                                    <div class="rbt-author-info">
                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                    </div>
                                </div>
                                <div class="rbt-card-bottom">
                                    <div class="rbt-price">
                                        <span class="current-price">$80</span>
                                        <span class="off-price">$100</span>
                                    </div>
                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                        More<i class="feather-arrow-right"></i></a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Course Area -->
        <?php elseif( $settings['_style'] == 'style_17' ): ?>
        <div class="rbt-course-area bg-color-white rbt-section-gapTop masonary-wrapper-activation">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">Popular Course</span>
                            <h2 class="title">Online Coaching Lessons For <br> Remote Learning</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <ul class="rbt-portfolio-filter filter-tab-button text-center nav nav-tabs" id="rbt-myTab" role="tablist">
                            <li class="nav-item" role="presentation">
                                <button class="active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button" role="tab" aria-controls="all" aria-selected="true"><span class="filter-text">All
                                        Course</span> <span class="course-number">06</span></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button id="featured-tab" data-bs-toggle="tab" data-bs-target="#featured" type="button" role="tab" aria-controls="featured" aria-selected="false"><span
                                        class="filter-text">Featured</span> <span class="course-number">02</span></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button id="popular-tab" data-bs-toggle="tab" data-bs-target="#popular" type="button" role="tab" aria-controls="popular" aria-selected="false"><span
                                        class="filter-text">Popular</span> <span class="course-number">05</span></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button id="trending-tab" data-bs-toggle="tab" data-bs-target="#trending" type="button" role="tab" aria-controls="trending" aria-selected="false"><span
                                        class="filter-text">Trending</span> <span class="course-number">03</span></button>
                            </li>
                            <li class="nav-item" role="presentation">
                                <button id="latest-tab" data-bs-toggle="tab" data-bs-target="#latest" type="button" role="tab" aria-controls="latest" aria-selected="false"><span
                                        class="filter-text">Latest</span> <span class="course-number">04</span></button>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- Start Card Area -->

                <div class="row">
                    <div class="col-lg-12">
                        <div class="tab-content mt--60" id="rbt-myTabContent">
                            <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all-tab">
                                <div class="row g-5">

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-01.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To
                                                        Back</a>
                                                </h4>

                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-03.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-04.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To
                                                        Back</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>20 Lessons</li>
                                                    <li><i class="feather-users"></i>40 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted
                                                    by
                                                    the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>

                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-05.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted
                                                    by the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-06.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">JS Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                </div>
                            </div>

                            <div class="tab-pane fade" id="featured" role="tabpanel" aria-labelledby="featured-tab">
                                <div class="row g-5">
                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-03.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->
                                </div>
                            </div>

                            <div class="tab-pane fade" id="popular" role="tabpanel" aria-labelledby="popular-tab">
                                <div class="row g-5">
                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-01.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">React Front To
                                                        Back</a>
                                                </h4>

                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-03.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-04.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To
                                                        Back</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>20 Lessons</li>
                                                    <li><i class="feather-users"></i>40 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted
                                                    by
                                                    the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>

                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-05.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted
                                                    by the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->
                                </div>
                            </div>

                            <div class="tab-pane fade" id="trending" role="tabpanel" aria-labelledby="trending-tab">
                                <div class="row g-5">
                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-03.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-04.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To
                                                        Back</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>20 Lessons</li>
                                                    <li><i class="feather-users"></i>40 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted
                                                    by
                                                    the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>

                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-05.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted
                                                    by the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->
                                </div>
                            </div>

                            <div class="tab-pane fade" id="latest" role="tabpanel" aria-labelledby="latest-tab">
                                <div class="row g-5">
                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-02.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">PHP Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>

                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted.</p>
                                                <div class="rbt-author-meta mb--10">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-03.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (5 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">Angular Zero to
                                                        Mastery</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>8 Lessons</li>
                                                    <li><i class="feather-users"></i>30 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Angular Js long fact that a reader will be
                                                    distracted by
                                                    the readable.</p>

                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-03.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Slaughter</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$80</span>
                                                        <span class="off-price">$100</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-04.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>

                                                <h4 class="rbt-card-title"><a href="course-details.html">Web Front To
                                                        Back</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>20 Lessons</li>
                                                    <li><i class="feather-users"></i>40 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">Web Js long fact that a reader will be distracted
                                                    by
                                                    the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avater-01.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Patrick</a> In <a href="#">Languages</a>
                                                    </div>
                                                </div>

                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link" href="course-details.html">Learn
                                                        More<i class="feather-arrow-right"></i></a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->

                                    <!-- Start Single Card  -->
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                        <div class="rbt-card variation-01 rbt-hover card-list-2">
                                            <div class="rbt-card-img">
                                                <a href="course-details.html">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/course-list-05.jpg" alt="Card image">
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <div class="rbt-card-top">
                                                    <div class="rbt-review">
                                                        <div class="rating">
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                            <i class="fas fa-star"></i>
                                                        </div>
                                                        <span class="rating-count"> (15 Reviews)</span>
                                                    </div>
                                                    <div class="rbt-bookmark-btn">
                                                        <a class="rbt-round-btn" title="Bookmark" href="#"><i
                                                                class="feather-bookmark"></i></a>
                                                    </div>
                                                </div>
                                                <h4 class="rbt-card-title"><a href="course-details.html">SQL Beginner
                                                        Advanced</a>
                                                </h4>
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-book"></i>12 Lessons</li>
                                                    <li><i class="feather-users"></i>50 Students</li>
                                                </ul>
                                                <p class="rbt-card-text">It is a long established fact that a reader will be
                                                    distracted
                                                    by the readable.</p>
                                                <div class="rbt-author-meta mb--20">
                                                    <div class="rbt-avater">
                                                        <a href="#">
                                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/client/avatar-02.png" alt="Sophia Jaymes">
                                                        </a>
                                                    </div>
                                                    <div class="rbt-author-info">
                                                        By <a href="profile.html">Angela</a> In <a href="#">Development</a>
                                                    </div>
                                                </div>
                                                <div class="rbt-card-bottom">
                                                    <div class="rbt-price">
                                                        <span class="current-price">$60</span>
                                                        <span class="off-price">$120</span>
                                                    </div>
                                                    <a class="rbt-btn-link left-icon" href="course-details.html"><i
                                                            class="feather-shopping-cart"></i> Add To Cart</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                    <!-- End Single Card  -->
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Course_Widget() );