// This is your test publishable API key.
const stripe = Stripe("pk_test_51MqkQXDvXhXIFQMYnPHyj1Haxlvxc7SZUKrfWDdzXuC9OaKkYvsvqcnDteAd8IGYkPph9zLZVsRQ7838HrzQLnPb00q5Sq97E0");

// The items the customer wants to buy
const items = [{ id: "xl-tshirt" }];

let elements;
let client_secret;
let payment_intent;

initialize();
checkStatus();

document
  .querySelector("#payment-form")
  .addEventListener("submit", handleSubmit);

let emailAddress = 'adityaamin@gmail.com';
// Fetches a payment intent and captures the client secret
async function initialize() {
    const formData = new FormData();
    formData.append('items', JSON.stringify(items));
    formData.append('action', 'stripe_payment_actions');
    formData.append('security', '');
    formData.append('method', 'payment_intent');
    const client_secret = await fetch(stripe_payment.admin_ajax_url, {
        method: "POST",
        body: formData,
    }).then((r) => r.json());

    elements = stripe.elements(JSON.parse(client_secret));

    const linkAuthenticationElement = elements.create("linkAuthentication");
    linkAuthenticationElement.mount("#link-authentication-element");

    const paymentElementOptions = {
        layout: "tabs",
    };

    const paymentElement = elements.create("payment", paymentElementOptions);
    paymentElement.mount("#payment-element");
}

async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);

    const { error } = await stripe.confirmPayment({
        client_secret,
        elements,
        confirmParams: {
          // Make sure to change this to your payment completion page
          return_url: stripe_payment.return_url,
          receipt_email: emailAddress,
          payment_method_data:{
            billing_details:{
              address:{
                city:'Gaibandha',
                country:'Bangladesh',
                line1:'David Company Para',
                line2:'Gaibandha Sadar',
                postal_code:'5700',
                state:'Gaibandha'
              },
              email:emailAddress,
              name:'Md. Aditya Amin',
              phone:'+8801303265318'
            }
          }
        },
    });

    // This point will only be reached if there is an immediate error when
    // confirming the payment. Otherwise, your customer will be redirected to
    // your `return_url`. For some payment methods like iDEAL, your customer will
    // be redirected to an intermediate site first to authorize the payment, then
    // redirected to the `return_url`.
    if (error.type === "card_error" || error.type === "validation_error") {
        showMessage(error.message);
    } else {
        showMessage("An unexpected error occurred.");
    }

    setLoading(false);
}

// Fetches the payment intent status after payment submission
async function checkStatus() {
  const clientSecret = new URLSearchParams(window.location.search).get(
    "payment_intent_client_secret"
  );

  if (!clientSecret) {
    return;
  }

  const { paymentIntent } = await stripe.retrievePaymentIntent(clientSecret);

  switch (paymentIntent.status) {
    case "succeeded":
      showMessage("Payment succeeded!");
      break;
    case "processing":
      showMessage("Your payment is processing.");
      break;
    case "requires_payment_method":
      showMessage("Your payment was not successful, please try again.");
      break;
    default:
      showMessage("Something went wrong.");
      break;
  }
}

// ------- UI helpers -------

function showMessage(messageText) {
  const messageContainer = document.querySelector("#payment-message");

  messageContainer.classList.remove("hidden");
  messageContainer.textContent = messageText;

  setTimeout(function () {
    messageContainer.classList.add("hidden");
    messageText.textContent = "";
  }, 4000);
}

// Show a spinner on payment submission
function setLoading(isLoading) {
  if (isLoading) {
    // Disable the button and show a spinner
    document.querySelector("#submit").disabled = true;
    document.querySelector("#spinner").classList.remove("hidden");
    document.querySelector("#button-text").classList.add("hidden");
  } else {
    document.querySelector("#submit").disabled = false;
    document.querySelector("#spinner").classList.add("hidden");
    document.querySelector("#button-text").classList.remove("hidden");
  }
}