<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Accordion_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'accordion';
	}

	/**
	 * Get widget accordion.
	 *
	 * Retrieve button widget accordion.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget accordion.
	 */
	public function get_title() {
		return esc_html__( 'Accordion', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 3, '', 'style_3');
        $this->repeater_controls('accordion_list', 'Accordion List', array(
            array(
                'name'  => '_accordion_title',
                'label' => 'Accordion Title',
                'type'  => \Elementor\Controls_Manager::TEXT
            ),
            array(
                'name'  => '_accordion_description',
                'label' => 'Accordion Description',
                'type'  => \Elementor\Controls_Manager::TEXTAREA
            )
        ), array(
            array(
                '_accordion_title' => 'What is Histudy ? How does it work?',
                '_accordion_description' => 'You can run Histudy easily. Any School, University, College can be use this histudy education template for their educational purpose. A university can be run their online leaning management system by histudy education template.'
            )
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->background_control('_accordion_background', 'Accordion Backgrond', '.rbt-accordion-style .card .card-header');
        $this->typography_control('_accordion_title_typo', 'Accordion Title Typography', '.rbt-accordion-style .card .card-header button');
        $this->color_control('_accordion_title_color', 'Accordion Title Color', '.rbt-accordion-style .card .card-header button');
        $this->color_control('_accordion_title_active_color', 'Accordion Title Active Color', '.rbt-accordion-style .card .card-header button[aria-expanded=true]');

        $this->background_control('_accordion_background_body', 'Accordion Body Backgrond', '.rbt-accordion-style.rbt-accordion-04 .card .card-body');
        $this->typography_control('_accordion_body_typo', 'Accordion Body Typography', '.rbt-accordion-style.rbt-accordion-04 .card .card-body');
        $this->color_control('_accordion_body_color', 'Accordion Body Color', '.rbt-accordion-style.rbt-accordion-04 .card .card-body');


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
		<!-- Start Accordion Area  -->
        <div class="rbt-accordion-area accordion-style-1 bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">University Tuition & Fees</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5 align-items-start">
                    <div class="col-lg-7 order-2 order-lg-1">
                        <div class="rbt-accordion-style rbt-accordion-01 rbt-accordion-06 accordion">
                            <div class="accordion" id="tutionaccordionExamplea1">
                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseOne" aria-expanded="true" aria-controls="tutioncollapseOne">
                                            Master of Business Administration (MBA)
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseOne" class="accordion-collapse collapse show" aria-labelledby="tutionheadingOne" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$500</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$500</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseTwo" aria-expanded="false" aria-controls="tutioncollapseTwo">
                                            MSS in Economics
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseTwo" class="accordion-collapse collapse" aria-labelledby="tutionheadingTwo" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Admission Eligibility Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$4589</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$4589</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseThree" aria-expanded="false" aria-controls="tutioncollapseThree">
                                            MS in Applied Physics & Electronics
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseThree" class="accordion-collapse collapse" aria-labelledby="tutionheadingThree" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Admission Eligibility Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$1400</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$1400</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseFour" aria-expanded="false" aria-controls="tutioncollapseFour">
                                            Master of Laws (LL.M.)
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseFour" class="accordion-collapse collapse" aria-labelledby="tutionheadingFour" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$4589</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$4589</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingFive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseFive" aria-expanded="false" aria-controls="tutioncollapseFive">
                                            Master of Population, Reproductive Health
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseFive" class="accordion-collapse collapse" aria-labelledby="tutionheadingFive" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$5000</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$5000</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 order-1 order-lg-2">
                        <div class="thumbnail">
                            <img class="radius-6" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-07.png" alt="histudy image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Accordion Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Accordion Area  -->
        <div class="rbt-accordion-area accordion-style-1 bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">COURSE PRICING</span>
                            <h2 class="title">Tuition & Fees</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5 align-items-start">
                    <div class="col-lg-7 order-2 order-lg-1">
                        <div class="rbt-accordion-style rbt-accordion-01 rbt-accordion-06 accordion">
                            <div class="accordion" id="tutionaccordionExamplea1">
                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingOne">
                                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseOne" aria-expanded="true" aria-controls="tutioncollapseOne">
                                            Master of Business Administration (MBA)
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseOne" class="accordion-collapse collapse show" aria-labelledby="tutionheadingOne" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$500</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$500</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingTwo">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseTwo" aria-expanded="false" aria-controls="tutioncollapseTwo">
                                            MSS in Economics
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseTwo" class="accordion-collapse collapse" aria-labelledby="tutionheadingTwo" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Admission Eligibility Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$4589</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$4589</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingThree">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseThree" aria-expanded="false" aria-controls="tutioncollapseThree">
                                            MS in Applied Physics & Electronics
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseThree" class="accordion-collapse collapse" aria-labelledby="tutionheadingThree" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Admission Eligibility Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$1400</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$1400</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingFour">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseFour" aria-expanded="false" aria-controls="tutioncollapseFour">
                                            Master of Laws (LL.M.)
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseFour" class="accordion-collapse collapse" aria-labelledby="tutionheadingFour" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$4589</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$4589</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                <div class="accordion-item card">
                                    <h2 class="accordion-header card-header" id="tutionheadingFive">
                                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#tutioncollapseFive" aria-expanded="false" aria-controls="tutioncollapseFive">
                                            Master of Population, Reproductive Health
                                        </button>
                                    </h2>
                                    <div id="tutioncollapseFive" class="accordion-collapse collapse" aria-labelledby="tutionheadingFive" data-bs-parent="#tutionaccordionExamplea1">
                                        <div class="accordion-body card-body">
                                            <h6 class="title">Total Cost Breakdown 2022</h6>
                                            <div class="table-responsive mobile-table-750">
                                                <table class="rbt-table table table-borderless">
                                                    <thead>
                                                        <tr>
                                                            <th>Program Term</th>
                                                            <th>Tuition Cost</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr>
                                                            <th>Term 1-6</th>
                                                            <td>$5000</td>
                                                        </tr>
                                                    </tbody>
                                                    <tfoot>
                                                        <tr>
                                                            <th>Total</th>
                                                            <th>$5000</th>
                                                        </tr>
                                                    </tfoot>
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 order-1 order-lg-2">
                        <div class="thumbnail">
                            <img class="radius-6" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/about-07.png" alt="histudy image">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- End Accordion Area  -->
        <div class="rbt-accordion-style rbt-accordion-04 accordion">
            <div class="accordion" id="accordionExamplec3">
                <?php $count = 0; foreach($settings['_accordion_list'] as $item): $count++; ?>
                <div class="accordion-item card">
                    <h2 class="accordion-header card-header" id="heading-<?php echo $item['_id']?>">
                        <button class="accordion-button" type="button" data-bs-toggle="collapse" data-bs-target="#collapse-<?php echo $item['_id']?>" aria-expanded="true" aria-controls="collapse-<?php echo $item['_id']?>">
                            <?php echo esc_html($item['_accordion_title']); ?>
                        </button>
                    </h2>
                    <div id="collapse-<?php echo $item['_id']?>" class="accordion-collapse collapse <?php echo ($count == 1)? 'show' : ''; ?>" aria-labelledby="heading-<?php echo $item['_id']?>" data-bs-parent="#accordionExamplec3">
                        <div class="accordion-body card-body">
                            <?php echo esc_html($item['_accordion_description']); ?>
                        </div>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Accordion_Widget() );