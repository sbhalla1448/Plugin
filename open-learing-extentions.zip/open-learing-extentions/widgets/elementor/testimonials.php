<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Testimonials_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-testimonial';
	}

	/**
	 * Get widget testimonial.
	 *
	 * Retrieve button widget testimonial.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget testimonial.
	 */
	public function get_title() {
		return esc_html__( 'OLC Testimonial', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->text_control('_section_subtitle', 'Subtitle', 'EDUCATION FOR EVERYONE', array());
        $this->textarea_control('_section_title', 'Title', 'What <span>Our Students</span> Are Saying', array());
        $this->textarea_control('_section_text', 'Text', 'We love feedback, good or bad. We would love to hear from you on any aspect of our business', array());
        $this->number_control('_section_reviews', 'Number of Reviews', 1000, array());
        $this->number_control('_section_ratings', 'Average Ratings', 4.9, array());
        $this->number_control('_slide_number', 'Number of Slides', 3, array());

        $this->repeater_controls('author_list', 'Author List', array(
            array(
                'name'  => '_author_image',
                'label' => 'Author Image',
                'type'  => \Elementor\Controls_Manager::MEDIA
            ),
            array(
                'name'  => '_author_name',
                'label' => 'Author Name',
                'type'  => \Elementor\Controls_Manager::TEXT
            ),
            array(
                'name'  => '_author_designation',
                'label' => 'Author Designation',
                'type'  => \Elementor\Controls_Manager::TEXTAREA
            ),
            array(
                'name'  => '_author_text',
                'label' => 'Author Text',
                'type'  => \Elementor\Controls_Manager::TEXTAREA
            ),
        ), array(
            array(
                '_author_name' => 'Aditya Amin',
                '_author_designation' => 'Wordpress Plugin & Theme Developer',
                '_author_text' => 'The Tree of Life is a powerful symbol that represents the interconnectedness and growth of all living things. Just like the branches of the tree reaching towards the sky',
            )
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();

        $this->start_controls_section(
			'testimonial_style',
			[
				'label' => esc_html__( 'Testimonial Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        ?>
        <script>
            (function($){
                "use strict";
                $(document).ready(function(){
                    $('.testimonial-slide-1').slick({
                        slidesToShow: 1,
                        slidesToScroll: 1,
                        arrows: false,
                        fade: false,
                        asNavFor: '.testimonial-slide-2'
                    });
                    $('.testimonial-slide-2').slick({
                        slidesToShow: <?php echo esc_html($settings['_slide_number']); ?>,
                        slidesToScroll: 1,
                        asNavFor: '.testimonial-slide-1',
                        dots: false,
                        centerMode: true,
                        focusOnSelect: true
                    });
                })
            })(jQuery)
        </script>
        <div class="rbt-about-area rbt-about-area-2">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6 order-2 order-lg-1">
                        <div class="inner">
                            <div class="section-title text-start">
                                <span class="subtitle bg-primary-opacity"><?php echo wp_kses_post($settings['_section_subtitle']); ?></span>
                                <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                                <p class="description mt--20"><?php echo wp_kses_post($settings['_section_text']); ?></p>
                                <div class="read-more-btn mt--40">
                                    <div class="reviews">
                                        <strong><?php echo esc_html($settings['_section_reviews']); ?> Reviews</strong>
                                        <div class="rat-review">
                                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 20 20" fill="none">
                                            <path d="M17.6741 7.646L12.7151 6.9253L10.4983 2.43116C10.4377 2.30811 10.3381 2.2085 10.2151 2.14796C9.9065 1.99561 9.5315 2.12257 9.3772 2.43116L7.16041 6.9253L2.20142 7.646C2.0647 7.66553 1.9397 7.72999 1.844 7.82764C1.7283 7.94656 1.66454 8.10655 1.66674 8.27245C1.66894 8.43835 1.73691 8.5966 1.85572 8.71241L5.44361 12.2105L4.59595 17.1499C4.57608 17.2648 4.58879 17.383 4.63266 17.491C4.67652 17.5991 4.74978 17.6927 4.84413 17.7612C4.93848 17.8297 5.05015 17.8704 5.16646 17.8787C5.28277 17.887 5.39908 17.8626 5.5022 17.8081L9.93775 15.4761L14.3733 17.8081C14.4944 17.8726 14.635 17.894 14.7698 17.8706C15.1096 17.812 15.3381 17.4897 15.2795 17.1499L14.4319 12.2105L18.0198 8.71241C18.1174 8.6167 18.1819 8.4917 18.2014 8.35499C18.2542 8.01319 18.0159 7.69678 17.6741 7.646Z" fill="#FFDC5D"/>
                                            </svg>
                                            <span><?php echo esc_html($settings['_section_ratings']); ?>/5</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 order-1 order-lg-2">
                        <div class="testimonial-right-contents">
                            <?php
                                $testimonial_lists = $settings['_author_list'];
                                if(!empty($testimonial_lists)):
                            ?>
                            <div class="testimonial-slider-wrapper">
                                <div class="testimonial-slide-1">
                                    <?php foreach($testimonial_lists as $item): ?>
                                    <div class="testimonial-slide">
                                        <div class="testimonail-content">
                                            <div class="ratings">
                                                <span class="star">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M21.2089 9.17501L15.2581 8.31016L12.5979 2.9172C12.5253 2.76954 12.4057 2.65001 12.2581 2.57735C11.8878 2.39454 11.4378 2.54688 11.2526 2.9172L8.59246 8.31016L2.64168 9.17501C2.47762 9.19844 2.32762 9.27579 2.21278 9.39298C2.07394 9.53568 1.99743 9.72766 2.00007 9.92675C2.0027 10.1258 2.08427 10.3157 2.22684 10.4547L6.53231 14.6523L5.51512 20.5797C5.49127 20.7176 5.50652 20.8594 5.55916 20.989C5.6118 21.1187 5.69972 21.231 5.81294 21.3132C5.92616 21.3955 6.06015 21.4443 6.19973 21.4543C6.3393 21.4642 6.47888 21.4349 6.60262 21.3695L11.9253 18.5711L17.2479 21.3695C17.3932 21.4469 17.562 21.4727 17.7237 21.4445C18.1315 21.3742 18.4057 20.9875 18.3354 20.5797L17.3182 14.6523L21.6237 10.4547C21.7409 10.3399 21.8182 10.1899 21.8417 10.0258C21.905 9.61563 21.619 9.23594 21.2089 9.17501Z" fill="#FFDC5D"/>
                                                    </svg>
                                                </span>
                                                <span class="star">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M21.2089 9.17501L15.2581 8.31016L12.5979 2.9172C12.5253 2.76954 12.4057 2.65001 12.2581 2.57735C11.8878 2.39454 11.4378 2.54688 11.2526 2.9172L8.59246 8.31016L2.64168 9.17501C2.47762 9.19844 2.32762 9.27579 2.21278 9.39298C2.07394 9.53568 1.99743 9.72766 2.00007 9.92675C2.0027 10.1258 2.08427 10.3157 2.22684 10.4547L6.53231 14.6523L5.51512 20.5797C5.49127 20.7176 5.50652 20.8594 5.55916 20.989C5.6118 21.1187 5.69972 21.231 5.81294 21.3132C5.92616 21.3955 6.06015 21.4443 6.19973 21.4543C6.3393 21.4642 6.47888 21.4349 6.60262 21.3695L11.9253 18.5711L17.2479 21.3695C17.3932 21.4469 17.562 21.4727 17.7237 21.4445C18.1315 21.3742 18.4057 20.9875 18.3354 20.5797L17.3182 14.6523L21.6237 10.4547C21.7409 10.3399 21.8182 10.1899 21.8417 10.0258C21.905 9.61563 21.619 9.23594 21.2089 9.17501Z" fill="#FFDC5D"/>
                                                    </svg>
                                                </span>
                                                <span class="star">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M21.2089 9.17501L15.2581 8.31016L12.5979 2.9172C12.5253 2.76954 12.4057 2.65001 12.2581 2.57735C11.8878 2.39454 11.4378 2.54688 11.2526 2.9172L8.59246 8.31016L2.64168 9.17501C2.47762 9.19844 2.32762 9.27579 2.21278 9.39298C2.07394 9.53568 1.99743 9.72766 2.00007 9.92675C2.0027 10.1258 2.08427 10.3157 2.22684 10.4547L6.53231 14.6523L5.51512 20.5797C5.49127 20.7176 5.50652 20.8594 5.55916 20.989C5.6118 21.1187 5.69972 21.231 5.81294 21.3132C5.92616 21.3955 6.06015 21.4443 6.19973 21.4543C6.3393 21.4642 6.47888 21.4349 6.60262 21.3695L11.9253 18.5711L17.2479 21.3695C17.3932 21.4469 17.562 21.4727 17.7237 21.4445C18.1315 21.3742 18.4057 20.9875 18.3354 20.5797L17.3182 14.6523L21.6237 10.4547C21.7409 10.3399 21.8182 10.1899 21.8417 10.0258C21.905 9.61563 21.619 9.23594 21.2089 9.17501Z" fill="#FFDC5D"/>
                                                    </svg>
                                                </span>
                                                <span class="star">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M21.2089 9.17501L15.2581 8.31016L12.5979 2.9172C12.5253 2.76954 12.4057 2.65001 12.2581 2.57735C11.8878 2.39454 11.4378 2.54688 11.2526 2.9172L8.59246 8.31016L2.64168 9.17501C2.47762 9.19844 2.32762 9.27579 2.21278 9.39298C2.07394 9.53568 1.99743 9.72766 2.00007 9.92675C2.0027 10.1258 2.08427 10.3157 2.22684 10.4547L6.53231 14.6523L5.51512 20.5797C5.49127 20.7176 5.50652 20.8594 5.55916 20.989C5.6118 21.1187 5.69972 21.231 5.81294 21.3132C5.92616 21.3955 6.06015 21.4443 6.19973 21.4543C6.3393 21.4642 6.47888 21.4349 6.60262 21.3695L11.9253 18.5711L17.2479 21.3695C17.3932 21.4469 17.562 21.4727 17.7237 21.4445C18.1315 21.3742 18.4057 20.9875 18.3354 20.5797L17.3182 14.6523L21.6237 10.4547C21.7409 10.3399 21.8182 10.1899 21.8417 10.0258C21.905 9.61563 21.619 9.23594 21.2089 9.17501Z" fill="#FFDC5D"/>
                                                    </svg>
                                                </span>
                                                <span class="star">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none">
                                                    <path d="M21.2089 9.17501L15.2581 8.31016L12.5979 2.9172C12.5253 2.76954 12.4057 2.65001 12.2581 2.57735C11.8878 2.39454 11.4378 2.54688 11.2526 2.9172L8.59246 8.31016L2.64168 9.17501C2.47762 9.19844 2.32762 9.27579 2.21278 9.39298C2.07394 9.53568 1.99743 9.72766 2.00007 9.92675C2.0027 10.1258 2.08427 10.3157 2.22684 10.4547L6.53231 14.6523L5.51512 20.5797C5.49127 20.7176 5.50652 20.8594 5.55916 20.989C5.6118 21.1187 5.69972 21.231 5.81294 21.3132C5.92616 21.3955 6.06015 21.4443 6.19973 21.4543C6.3393 21.4642 6.47888 21.4349 6.60262 21.3695L11.9253 18.5711L17.2479 21.3695C17.3932 21.4469 17.562 21.4727 17.7237 21.4445C18.1315 21.3742 18.4057 20.9875 18.3354 20.5797L17.3182 14.6523L21.6237 10.4547C21.7409 10.3399 21.8182 10.1899 21.8417 10.0258C21.905 9.61563 21.619 9.23594 21.2089 9.17501Z" fill="#FFDC5D"/>
                                                    </svg>
                                                </span>
                                            </div>
                                            <p><?php echo wp_kses_post($item['_author_text']); ?></p>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <div class="testimonial-slider-wrapper">
                                <div class="testimonial-slide-2">
                                    <?php foreach($testimonial_lists as $item): ?>
                                    <div class="testimonial-slide">
                                        <div class="testimonial-content-author">
                                            <div class="testimonial-author-avatar">
                                                <img src="<?php echo esc_url($item['_author_image']['url']); ?>" alt="">
                                            </div>
                                            <div class="testimonial-author">
                                                <p class="name"><?php echo wp_kses_post($item['_author_name']); ?></p>
                                                <p class="job"><?php echo wp_kses_post($item['_author_designation']); ?></p>
                                            </div>
                                        </div>
                                    </div>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php
	}
}

$widgets_manager->register( new OLX_Testimonials_Widget() );