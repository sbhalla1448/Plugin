<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Teams_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-team';
	}

	/**
	 * Get widget team.
	 *
	 * Retrieve button widget team.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget event.
	 */
	public function get_title() {
		return esc_html__( 'OLC Team', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->text_control('_section_title', 'Section Title', 'Popular <span>Teachers</span> & Instructors', array());
        $this->textarea_control('_section_sub_title', 'Section Sub Title', 'OUR EXPERTS', array());
        $this->url_control('_button_link', 'All Instructors Page Link', '#', array());
        $this->repeater_controls('instructors_list', 'Instructor List', array(
            array(
                'name'      => '_instructor',
                'label'     => esc_html__( 'Select instructor', 'open-learning-ex' ),
                'type'      => \Elementor\Controls_Manager::SELECT2,
                'options'   => $this->get_all_instructors(),
            ),
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

    protected function get_all_instructors(){
        $ins = tutor_utils()->get_instructors(0, 10, '', '', '', '', 'approved', array(), '', false);
        $ins_array = array();

        foreach($ins as $in){
            $ins_array[$in->ID] = $in->display_name;
        }

        return $ins_array;
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        // $ins = tutor_utils()->get_instructors(0, 10, '', '', '', '', 'approved', array(), '', false);
        // var_dump($ins);
        ?>
        <div class="rbt-custom-team-area rbt-section-gap rbt-dark-bg" style="background-image: url(<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/instructors_bg.jpg);">
            <div class="container">
                <div class="row g-5 align-items-center mb--30">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title">
                            <span class="subtitle bg-pink-opacity"><?php echo esc_html($settings['_section_sub_title']); ?></span>
                            <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn" href="<?php echo esc_url($settings['_button_link']['url']); ?>">
                                View All
                            </a>
                        </div>
                    </div>
                </div>
                <?php
                    $instructors_list = $settings['_instructors_list'];
                    if(!empty($instructors_list)):
                    
                ?>
                <div class="row g-5 align-items-center">
                    <?php foreach($instructors_list as $instructor): 
                        $user_meta = get_user_meta($instructor['_instructor']);
                        $get_user_profile = isset($user_meta['_tutor_profile_photo'])? wp_get_attachment_image_url($user_meta['_tutor_profile_photo'][0], 'large') : '';
                        $get_user_name = ($user_meta['first_name'][0] != '')? $user_meta['first_name'][0].' '.$user_meta['last_name'][0] : ucwords($user_meta['nickname'][0]);
                        $get_user_job = isset($user_meta['_tutor_profile_job_title'])? $user_meta['_tutor_profile_job_title'][0] : ''; 
                        $get_user_rating = tutor_utils()->get_instructor_ratings( $instructor['_instructor'] );
                        $get_user_profile_id = isset($user_meta['_tutor_profile_photo'])? $user_meta['_tutor_profile_photo'][0] : rand(99999, 1000000);
                    ?>
                    <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                        <div class="instructor-single-box">
                            <svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="270" height="270" viewBox="0 0 270 270" fill="none">
                                <path d="M269.741 173.933C269.741 250.281 191.171 270 135.376 270C79.5802 270 0 249.27 0 173.933C3.53593 92.5281 78.57 0 134.365 0C190.161 0 275.298 100.112 269.741 173.933Z" fill="url(#pattern<?php echo esc_attr($get_user_profile_id); ?>)"/>
                                <path d="M269.741 173.933C269.741 250.281 191.171 270 135.376 270C79.5802 270 0 249.27 0 173.933C3.53593 92.5281 78.57 0 134.365 0C190.161 0 275.298 100.112 269.741 173.933Z" fill="url(#paint<?php echo esc_attr($get_user_profile_id); ?>)"/>
                                <defs>
                                    <pattern id="pattern<?php echo esc_attr($get_user_profile_id); ?>" patternContentUnits="objectBoundingBox" width="1" height="1">
                                        <use xlink:href="#user-<?php echo esc_attr($get_user_profile_id); ?>" transform="scale(0.00333333)"/>
                                    </pattern>
                                    <linearGradient id="paint<?php echo esc_attr($get_user_profile_id); ?>" x1="135" y1="143" x2="135" y2="270" gradientUnits="userSpaceOnUse">
                                    <stop stop-opacity="0"/>
                                    <stop offset="1"/>
                                    </linearGradient>
                                    <image id="user-<?php echo esc_attr($get_user_profile_id); ?>" width="300" height="300" xlink:href="<?php echo esc_url($get_user_profile); ?>"/>
                                </defs>
                            </svg>
                            <div class="meta-contents">
                                <h4 class="name"><?php echo wp_trim_words(esc_html($get_user_name), 2, ''); ?></h4>
                                <span class="designation"><?php echo wp_trim_words(esc_html($get_user_job), 3, ''); ?></span>
                                <div class="ratings d-flex align-items-center justify-content-center">
                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 16 16" fill="none">
                                        <path d="M14.1392 6.11669L10.172 5.54013L8.3986 1.94482C8.35016 1.84638 8.27048 1.76669 8.17204 1.71826C7.92516 1.59638 7.62516 1.69794 7.50173 1.94482L5.72829 5.54013L1.7611 6.11669C1.65173 6.13232 1.55173 6.18388 1.47516 6.262C1.3826 6.35714 1.3316 6.48513 1.33336 6.61785C1.33511 6.75057 1.38949 6.87717 1.48454 6.96982L4.35485 9.76825L3.67673 13.7198C3.66082 13.8117 3.671 13.9063 3.70609 13.9927C3.74118 14.0791 3.79979 14.154 3.87527 14.2088C3.95075 14.2637 4.04008 14.2962 4.13313 14.3029C4.22618 14.3095 4.31923 14.2899 4.40173 14.2464L7.95016 12.3808L11.4986 14.2464C11.5955 14.2979 11.708 14.3151 11.8158 14.2964C12.0877 14.2495 12.2705 13.9917 12.2236 13.7198L11.5455 9.76825L14.4158 6.96982C14.4939 6.89325 14.5455 6.79325 14.5611 6.68388C14.6033 6.41044 14.4127 6.15732 14.1392 6.11669Z" fill="#FFDC5D"/>
                                    </svg>
                                    <span class="rating-text">4.9/5</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>
            </div>
        </div>
        <?php
	}
}

$widgets_manager->register( new OLX_Teams_Widget() );