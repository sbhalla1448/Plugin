<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Events_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-events';
	}

	/**
	 * Get widget events.
	 *
	 * Retrieve button widget events.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget events.
	 */
	public function get_title() {
		return esc_html__( 'OLC Events', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );
        $this->text_control('_section_title', 'Section Title', 'Connect With Your <span>Community</span>', array());
        $this->textarea_control('_section_sub_title', 'Section Sub Title', 'Latest Events, Workshops & Master Classes', array());
        $this->number_control('_total_events', 'Total Events', 12, array());

        $this->repeater_controls('events_tab_list', 'Tab List', array(
            array(
                'name'  => '_tab_title',
                'label' => esc_html__( 'Tab Title', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'name'  => '_tab_count',
                'label' => esc_html__( 'Tab Title', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'default' => 0
            ),
            array(
                'name'      => '_tab_events',
                'label'     => esc_html__( 'Tab Events', 'open-learning-ex' ),
                'type'      => \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
                'options'   => $this->get_events(),
            ),
        ));

        $this->end_controls_section();
    }

    protected function get_events(){
        $_events = get_posts(array(
            'post_type' => 'olc_events',
            'order'     => 'DESC'
        ));

        $events_array = array();

        foreach($_events as $event){
            $events_array[$event->ID] = $event->post_title;
        }

        return $events_array;
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
		?>
<div class="rbt-course-area rbt-section-gap">
    <div class="container">
        <div class="row mb--60">
            <div class="col-lg-12">
                <div class="section-title text-center">
                    <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                    <p class="sub-text"><?php echo wp_kses_post($settings['_section_sub_title']); ?></p>
                </div>
            </div>
        </div>
        <?php 
            $_tab_list = $settings['_events_tab_list'];
        ?>
        <div class="row">
            <div class="col-lg-12">
                <ul class="rbt-portfolio-filter filter-tab-button text-center nav nav-tabs" id="rbt-myTab"
                    role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="active" id="all-tab-events" data-bs-toggle="tab" data-bs-target="#all-events" type="button"
                            role="tab" aria-controls="all-events" aria-selected="true"><span class="filter-text">All</span> <span class="course-number"><?php echo $settings['_total_events'] > 9? esc_html($settings['_total_events']) : '0'.$settings['_total_events']; ?></span></button>
                    </li>
                    <?php foreach($_tab_list as $item): ?>
                    <li class="nav-item" role="presentation">
                        <button id="tab-<?php echo esc_attr($item['_id']); ?>-tab" data-bs-toggle="tab" data-bs-target="#tab-<?php echo esc_attr($item['_id']); ?>" type="button"
                            role="tab" aria-controls="tab-<?php echo esc_attr($item['_id']); ?>" aria-selected="true">
                            <span class="filter-text"><?php echo esc_html($item['_tab_title']); ?></span> 
                            <span class="course-number"><?php echo $item['_tab_count'] > 9? esc_html($item['_tab_count']) : '0'.$item['_tab_count']; ?></span>
                        </button>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <!-- Start Card Area -->
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content mt--60" id="rbt-myTabContent">
                    <div class="tab-pane fade show active" id="all-events" role="tabpanel" aria-labelledby="all-events">
                        <div class="row g-5">
                            <?php
                                $_get_events = olx_get_events_by_filter('all', array(), esc_html($settings['_total_events']));
                            ?>
                            <?php if($_get_events->have_posts()): ?>
                            <?php while($_get_events->have_posts()): $_get_events->the_post(); 
                                $event_cats = get_the_terms(get_the_ID(), 'olc_event_category');
                            ?>
                            <!-- Start Single Course  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="rbt-card variation-01 rbt-hover rbt-event">
                                    <div class="rbt-card-img" style="background-image:url(<?php the_post_thumbnail_url(); ?>);">
                                        <div class="flex-postion-items d-flex align-items-center justify-content-between">
                                            <a href="<?php echo get_term_link($event_cats[0]->term_id); ?>" class="category-name"><?php echo esc_html($event_cats[0]->name); ?></a>
                                        </div>
                                    </div>

                                    <div class="rbt-card-body">
                                        <h4 class="rbt-card-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h4>
                                        <p><?php echo wp_trim_words(get_the_content(), 12);
                                        ?></p>
                                        <div class="rbt-card-bottom">
                                            <a href="<?php the_permalink(); ?>" class="rbt-btn-custom">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Course  -->
                            <?php endwhile; wp_reset_query(); ?>
                            <?php else: ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <p>No event found!</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php foreach($_tab_list as $item): 
                        $_tab_events = $item['_tab_events'];
                    ?>
                    <div class="tab-pane fade" id="tab-<?php echo esc_attr($item['_id']); ?>" role="tabpanel" aria-labelledby="tab-<?php echo esc_attr($item['_id']); ?>">
                        <div class="row g-5">
                            <?php 
                            if(!empty($_tab_events)):
                            $_get_tab_events = olx_get_events_by_filter('all', $_tab_events, esc_html($settings['_total_events']));
                            if($_get_tab_events->have_posts()): 
                            ?>
                            <?php while($_get_tab_events->have_posts()): $_get_tab_events->the_post(); ?>
                                <!-- Start Single Course  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <div class="rbt-card variation-01 rbt-hover rbt-event">
                                    <div class="rbt-card-img" style="background-image:url(<?php the_post_thumbnail_url(); ?>);">
                                        <div class="flex-postion-items d-flex align-items-center justify-content-between">
                                            <a href="<?php echo get_term_link($event_cats[0]->term_id); ?>" class="category-name"><?php echo esc_html($event_cats[0]->name); ?></a>
                                        </div>
                                    </div>

                                    <div class="rbt-card-body">
                                        <h4 class="rbt-card-title">
                                            <a href="<?php the_permalink(); ?>"><?php the_title(); ?></a>
                                        </h4>
                                        <p><?php echo wp_trim_words(get_the_content(), 12);
                                        ?></p>
                                        <div class="rbt-card-bottom">
                                            <a href="<?php the_permalink(); ?>" class="rbt-btn-custom">Learn More</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Course  -->
                            
                            <?php endwhile; wp_reset_query(); ?>
                            <?php else: ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <p>No event found!</p>
                            </div>
                            <?php endif;?>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	}
}

$widgets_manager->register( new OLX_Events_Widget() );
