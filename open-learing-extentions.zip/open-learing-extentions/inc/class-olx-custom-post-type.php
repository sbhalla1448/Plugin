<?php 
class OLX_Custom_Post_Type 
{

	private $type;
    private $slug;
    private $name;
    private $plural_name;
    private $args = array();

	public function __construct( $args = array(), $type = 'custom_post' ) {
        $defaults = array(
            'name'=> __( 'Custom Post', 'open-learning-ex' ),
            'plural_name'=> __( 'Custom Post', 'open-learning-ex' ),
            'singular_name'=> __( 'Custom Post', 'open-learning-ex' ),
            'slug'=> 'custom_post',
            'supports' => ['title', 'editor', 'thumbnail', 'page-attributes']
        );

        $this->type = $type;
        $this->args = wp_parse_args($args, $defaults);
		$this->name = $this->args['name'];
        $this->slug = $this->args['slug'];
        $this->plural_name = $this->args['plural_name'];

		add_action( 'init', array( $this, 'register_custom_post_type' ) );
		//add_action( 'init', array( $this, 'create_cat' ) );
		add_filter( 'single_template', array( $this, 'get_custom_single_template' ) );
		
	}
	
	
	public function register_custom_post_type() {
		// $medidove_mem_slug = get_theme_mod('medidove_mem_slug','member'); 
		$labels = array(
			'name' => $this->name,
            'singular_name' => $this->name,
            'add_new' => sprintf( __('Add New %s', 'tpcore'), $this->name ),
            'add_new_item' => sprintf( __('Add New %s', 'tpcore'), $this->name ),
            'edit_item' => sprintf( __('Edit %s', 'tpcore'), $this->name ),
            'new_item' => sprintf( __('New %s', 'tpcore'), $this->name ),
            'all_items' => sprintf( __('All %s', 'tpcore'), $this->plural_name ),
            'view_item' => sprintf( __('View %s', 'tpcore'), $this->name ),
            'search_items' => sprintf( __('Search %s', 'tpcore'), $this->name ),
            'not_found' => sprintf( __('No %s found' , 'tpcore'), strtolower($this->name) ),
            'not_found_in_trash' => sprintf( __('No %s found in Trash', 'tpcore'), strtolower($this->name) ),
            'parent_item_colon' => '',
            'menu_name' => $this->name,
		);

		$args   = array(
			'labels' => $labels,
            'public' => true,
            'exclude_from_search' => true,
            'show_ui'           => true,
            'show_in_menu'      => true,
            'show_in_nav_menus' => true,
            'rewrite'           => [ 'slug' => $this->slug ],
            'capability_type'   => isset($this->args['capability_type'])? $this->args['capability_type'] : 'page',
            'menu_position'     => 10,
            'supports'          => $this->args['supports'],
            'menu_icon'         => 'dashicons-admin-page',
            'public'            => isset($this->args['public'])? $this->args['public'] : false,
            'has_archive'       => isset($this->args['has_archive'])? $this->args['has_archive'] : false,
            'paged'             => isset($this->args['paged'])? $this->args['paged'] : false,
		);

		register_post_type( $this->type, $args );
        $this->enable_custom_post_with_elementor();
	}

    public function enable_custom_post_with_elementor(){
        $elementor_enable = get_option('elementor_cpt_support');
        if( !empty($elementor_enable) ){
            $elementor_enable_update = wp_parse_args(array($this->type), $elementor_enable);
            update_option('elementor_cpt_support', $elementor_enable_update);
        }
        if(!$elementor_enable){
            $elementor_enable_update = wp_parse_args(array($this->type, 'post', 'page'), $elementor_enable);
            update_option('elementor_cpt_support', $elementor_enable_update);
        }
    }

	public function wrapper_header_open()
    {
        global $post;

        if ($post->post_type == $this->type) {
                echo "<div class='rbt-megamenu'>";
                    echo "<div class='container-wrapper'>";
        }
    }

    public function wrapper_header_close()
    {
        global $post;

        if ($post->post_type == $this->type) {
                    echo '</div>';
                echo '</div>';
        }
    }


	public function get_custom_single_template($single_template)
    {
        global $post;

        if ($post->post_type == $this->type) {

            if (defined('ELEMENTOR_PATH')) {
                $elementor_template = ELEMENTOR_PATH . '/modules/page-templates/templates/canvas.php';

                if ( file_exists( $elementor_template ) ) {
                    add_action( 'elementor/page_templates/canvas/before_content', [$this, 'wrapper_header_open']);
                    add_action( 'elementor/page_templates/canvas/after_content', [$this, 'wrapper_header_close']);
                    return $elementor_template;
                }
            }

            if (file_exists(get_template_directory().'/single-'.$this->type.'.php')) return $single_template;

            $single_template = OLX_PATH . 'templates/single-'.$this->type.'.php';
        }
        return $single_template;
    }
}