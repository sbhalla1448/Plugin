<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Slider_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'slider';
	}

	/**
	 * Get widget slider.
	 *
	 * Retrieve button widget slider.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget slider.
	 */
	public function get_title() {
		return esc_html__( 'Slider', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <div class="thumb-wrapper bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper rbt-gif-banner-area rbt-arrow-between">
                            <div class="swiper-wrapper">
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/gallery-banner-01.jpg" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/gallery-banner-02.jpg" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                                <!-- Start Single Banner  -->
                                <div class="swiper-slide">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img class="rbt-radius w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/banner/gallery-banner-03.jpg" alt="Banner Images">
                                        </a>
                                    </div>
                                </div>
                                <!-- End Single Banner  -->
                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-left">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-left"></i>
                                    <i class="rbt-icon-top feather-arrow-left"></i>
                                </div>
                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-right">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-right"></i>
                                    <i class="rbt-icon-top feather-arrow-right"></i>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Slider_Widget() );