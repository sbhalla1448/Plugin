<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Service_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'service';
	}

	/**
	 * Get widget service.
	 *
	 * Retrieve button widget service.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget service.
	 */
	public function get_title() {
		return esc_html__( 'Service', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 8, '', 'style_7');

        $this->textarea_control('_style_7_section_title', 'Section title', 'What will you learn after the course?', array(
            '_style' => 'style_7'
        ));

        $this->textarea_control('_style_7_section_description', 'Section description', 'There are many variations of passages of the Ipsum available.', array(
            '_style' => 'style_7'
        ));
        $this->text_control('_style_7_section_btn_text', 'Section Button Text', 'About More Us', array(
            '_style' => 'style_7'
        ));

        $this->url_control('_style_7_btn_url', 'Section Button URL', '#', array(
            '_style'    => 'style_7'
        ));

        $this->end_controls_section();

        $this->start_controls_section(
            'section_repeater_content',
            [
                'label' => esc_html__('Repeater Content Controls', 'open-learning-ex'),
            ]
        );

        $this->repeater_controls('style_7_flipbox_list', 'Feature list', array(
            array(
                'group'     => \Elementor\Group_Control_Background::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box Front Background', 'open-learning-ex' ),
                    'name'      => 'flipbox_background',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap',
                )
            ),
            array(
                'group'     => \Elementor\Group_Control_Box_Shadow::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box shadow', 'open-learning-ex' ),
                    'name'      => 'flipbox_shadow',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox',
                )
            ),
            array(
                'name'      => 'flipbox_icon',
                'label'     => esc_html__( 'Box Icon', 'open-learning-ex' ),
                'type'      => \Elementor\Controls_Manager::MEDIA,
                'default'   => array(
                    'url'   => \Elementor\Utils::get_placeholder_image_src()
                )
            ),
            array(
                'name' => 'flipbox_title',
                'label' => esc_html__( 'Box Title', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'group'     => \Elementor\Group_Control_Typography::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box Title Typography', 'open-learning-ex' ),
                    'name'      => 'title_typo',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-front .content .title',
                )
            ),
            array(
                'name' => 'box_title_color',
                'label' => esc_html__( 'Box Title Color', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-front .content .title' => 'color: {{VALUE}}',
                ],
            ),
            array(
                'name' => 'flipbox_description',
                'label' => esc_html__( 'Box description', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::TEXTAREA,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'group'     => \Elementor\Group_Control_Typography::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box Description Typography', 'open-learning-ex' ),
                    'name'      => 'flipbox_description_typo',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-front .content p',
                )
            ),
            array(
                'name' => 'flipbox_description_color',
                'label' => esc_html__( 'Box description color', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-front .content p' => 'color: {{VALUE}}',
                ],
            ),
            array(
                'name' => 'flipbox_back_description',
                'label' => esc_html__( 'Box Back description', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::WYSIWYG,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'group'     => \Elementor\Group_Control_Typography::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box Back Description Typography', 'open-learning-ex' ),
                    'name'      => 'flipbox_back_description_typo',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-back p',
                )
            ),
            array(
                'name' => 'flipbox_back_description_color',
                'label' => esc_html__( 'Box back description color', 'open-learning-ex' ),
                'type' => \Elementor\Controls_Manager::COLOR,
                'selectors' => [
                    '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-back p' => 'color: {{VALUE}}',
                ],
            ),
            array(
                'group'     => \Elementor\Group_Control_Background::get_type(),
                'args'      => array(
                    'label'     => esc_html__( 'Box Back Background', 'open-learning-ex' ),
                    'name'      => 'flipbox_back_background',
                    'selector'  => '{{WRAPPER}} {{CURRENT_ITEM}} .rbt-flipbox .rbt-flipbox-wrap .rbt-flipbox-back',
                )
            ),
        ), array(
            array(
                'flipbox_icon'          => array(
                    'url'               => get_parent_theme_file_uri() . "/assets/images/shape/service-01.png"
                ),
                'flipbox_title'         => esc_html('Best Coaching'),
                'flipbox_description'   => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.'),
                'flipbox_back_description'  => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.')
            ),
            array(
                'flipbox_icon'          => array(
                    'url'               => get_parent_theme_file_uri() . "/assets/images/shape/service-02.png"
                ),
                'flipbox_title'         => esc_html('Best Coaching'),
                'flipbox_description'   => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.'),
                'flipbox_back_description'  => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.')
            ),
            array(
                'flipbox_icon'          => array(
                    'url'               => get_parent_theme_file_uri() . "/assets/images/shape/service-03.png"
                ),
                'flipbox_title'         => esc_html('Best Coaching'),
                'flipbox_description'   => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.'),
                'flipbox_back_description'  => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.')
            ),
            array(
                'flipbox_icon'          => array(
                    'url'               => get_parent_theme_file_uri() . "/assets/images/shape/service-04.png"
                ),
                'flipbox_title'         => esc_html('Best Coaching'),
                'flipbox_description'   => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.'),
                'flipbox_back_description'  => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.')
            ),
            array(
                'flipbox_icon'          => array(
                    'url'               => get_parent_theme_file_uri() . "/assets/images/shape/service-05.png"
                ),
                'flipbox_title'         => esc_html('Best Coaching'),
                'flipbox_description'   => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.'),
                'flipbox_back_description'  => esc_html('Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.')
            ),
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
                'label'     => esc_html__( 'Section Background', 'open-learning-ex' ),
				'name'      => 'section_background',
				'selector'  => '{{WRAPPER}} .rbt-service-area',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Section Title Typography', 'open-learning-ex' ),
				'name'      => 'section_title_typo',
				'selector'  => '{{WRAPPER}} .rbt-service-area .section-title .title',
			]
		);

        $this->color_control('section_title_color', 'Section title color', '.rbt-service-area .section-title .title');

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Section Description Typography', 'open-learning-ex' ),
				'name'      => 'section_description_typo',
				'selector'  => '{{WRAPPER}} .rbt-service-area .section-title .description',
			]
		);

        $this->color_control('section_description_color', 'Section description color', '.rbt-service-area .section-title .description');

        $this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
                'label'     => esc_html__( 'Section Button Typography', 'open-learning-ex' ),
				'name'      => 'section_btn_typo',
				'selector'  => '{{WRAPPER}} .rbt-service-area .section-title .read-more-btn .rbt-btn span',
			]
		);

        $this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
                'label'     => esc_html__( 'Section Button Background', 'open-learning-ex' ),
				'name'      => 'section_btn_background',
				'selector'  => '{{WRAPPER}} .rbt-service-area .section-title .read-more-btn .rbt-btn',
			]
		);

        $this->color_control('section_btn_color', 'Section Button color', '.rbt-service-area .section-title ..read-more-btn .rbt-btn span');


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
		<!-- Start Service Area  -->
        <div class="service-wrapper rbt-section-gap bg-color-white">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Our Curriculum</span>
                            <h2 class="title">Our Curriculum</h2>
                            <p class="description has-medium-font-size mt--20">There are many variations of passages of the
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row row--15 mt_dec--30">
                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox variation-2">

                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-1">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="front-thumb w-100">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-01-front.jpg" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Infant</a></h5>
                                                <ul class="rbt-list-style-3">
                                                    <li><i class="feather-heart"></i> Health and Wellness</li>
                                                    <li><i class="feather-flag"></i> Literacy and Language</li>
                                                    <li><i class="feather-eye"></i> Social-Emotional Learning</li>
                                                    <li><i class="feather-edit-2"></i> Visual and Creative Arts
                                                    </li>
                                                    <li><i class="feather-battery-charging"></i> Thinking and Learning</li>
                                                </ul>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <div class="flip-back-top">
                                                <div class="back-thumb w-100">
                                                    <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-01-back.jpg" alt="card-icon">
                                                </div>
                                                <p>Babies enjoy classrooms made for exploring with teachers who support today’s big milestones.</p>
                                            </div>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox variation-2">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-2">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="front-thumb w-100">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-02-front.jpg" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Toddler / Twos</a></h5>
                                                <ul class="rbt-list-style-3">
                                                    <li><i class="feather-heart"></i> Health and Wellness</li>
                                                    <li><i class="feather-flag"></i> Literacy and Language</li>
                                                    <li><i class="feather-eye"></i> Social-Emotional Learning</li>
                                                    <li><i class="feather-edit-2"></i> Visual and Creative Arts
                                                    </li>
                                                    <li><i class="feather-battery-charging"></i> Thinking and Learning</li>
                                                </ul>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <div class="flip-back-top">
                                                <div class="back-thumb w-100">
                                                    <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-02-back.jpg" alt="card-icon">
                                                </div>
                                                <p>Babies enjoy classrooms made for exploring with teachers who support today’s big milestones.</p>
                                            </div>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox variation-2">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-3">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="front-thumb w-100">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-03-front.jpg" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Preschool</a></h5>
                                                <ul class="rbt-list-style-3">
                                                    <li><i class="feather-heart"></i> Health and Wellness</li>
                                                    <li><i class="feather-flag"></i> Literacy and Language</li>
                                                    <li><i class="feather-eye"></i> Social-Emotional Learning</li>
                                                    <li><i class="feather-edit-2"></i> Visual and Creative Arts
                                                    </li>
                                                    <li><i class="feather-battery-charging"></i> Thinking and Learning</li>
                                                </ul>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <div class="flip-back-top">
                                                <div class="back-thumb w-100">
                                                    <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-03-back.jpg" alt="card-icon">
                                                </div>
                                                <p>Babies enjoy classrooms made for exploring with teachers who support today’s big milestones.</p>
                                            </div>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox variation-2">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-4">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="front-thumb w-100">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-04-front.jpg" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Kindergarten Prep</a></h5>
                                                <ul class="rbt-list-style-3">
                                                    <li><i class="feather-heart"></i> Health and Wellness</li>
                                                    <li><i class="feather-flag"></i> Literacy and Language</li>
                                                    <li><i class="feather-eye"></i> Social-Emotional Learning</li>
                                                    <li><i class="feather-edit-2"></i> Visual and Creative Arts
                                                    </li>
                                                    <li><i class="feather-battery-charging"></i> Thinking and Learning</li>
                                                </ul>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <div class="flip-back-top">
                                                <div class="back-thumb w-100">
                                                    <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/flip/kindergarten-04-back.jpg" alt="card-icon">
                                                </div>
                                                <p>Babies enjoy classrooms made for exploring with teachers who support today’s big milestones.</p>
                                            </div>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Service Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <div class="service-wrapper bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">Histudy Feature</span>
                            <h2 class="title">Check out Histudy's features <br> to win any exam</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="row row--15 mt_dec--30">
                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-1">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="icon">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-1.png" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Best Coaching</a></h5>
                                                <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>
                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <ul class="rbt-list-style-3 color-white">
                                                <li><i class="feather-youtube"></i> 570 Free Video</li>
                                                <li><i class="feather-book"></i> 35 Subjects</li>
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-2">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="icon">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-2.png" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Convenient practice</a></h5>
                                                <p>Convenient practice dolor sit adipisicing elit. Minima error reiciendis.</p>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <ul class="rbt-list-style-3 color-white">
                                                <li><i class="feather-youtube"></i> 370 Free Video</li>
                                                <li><i class="feather-book"></i> 120 Subjects</li>
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-3">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="icon">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-3.png" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Video Lecture</a></h5>
                                                <p>Video Lecture sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <ul class="rbt-list-style-3 color-white">
                                                <li><i class="feather-youtube"></i> 125 Free Video</li>
                                                <li><i class="feather-book"></i> 12 Subjects</li>
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                            <!-- Start Single Card  -->
                            <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                                <div class="rbt-flipbox">
                                    <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-4">
                                        <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                            <div class="icon">
                                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-4.png" alt="card-icon">
                                            </div>
                                            <div class="content">
                                                <h5 class="title"><a href="#">Live Class</a></h5>
                                                <p>Live Class dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                                <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                            </div>
                                        </div>

                                        <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                            <ul class="rbt-list-style-3 color-white">
                                                <li><i class="feather-youtube"></i> 124 Free Video</li>
                                                <li><i class="feather-book"></i> 56 Subjects</li>
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                            <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                                <span data-text="Learn More">Learn More</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Card  -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="rbt-service-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Exam Preparation</span>
                            <h2 class="title">Annual Exam Preparation</h2>
                        </div>
                    </div>
                </div>
                <div class="row row--15 mt_dec--30">

                    <!-- Start Single Card  -->
                    <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                            <div class="inner">
                                <div class="content">
                                    <h4 class="title"><a href="#">BCS Exam</a></h4>
                                    <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-youtube"></i> 125 Free Video</li>
                                                <li><i class="feather-book"></i> 12 Subjects</li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="rbt-btn btn-gradient hover-icon-reverse btn-sm mt--30" href="#">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-01.png" alt="Education Images">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                            <div class="inner">
                                <div class="content">
                                    <h4 class="title"><a href="#">Medical Exam</a></h4>
                                    <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-youtube"></i> 785 Free Video</li>
                                                <li><i class="feather-book"></i> 95 Subjects</li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="rbt-btn btn-gradient hover-icon-reverse btn-sm mt--30" href="#">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-02.png" alt="Education Images">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                            <div class="inner">
                                <div class="content">
                                    <h4 class="title"><a href="#">University Admit Exam</a></h4>
                                    <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-youtube"></i> 123 Free Video</li>
                                                <li><i class="feather-book"></i> 85 Subjects</li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="rbt-btn btn-gradient hover-icon-reverse btn-sm mt--30" href="#">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-03.png" alt="Education Images">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-6 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-service rbt-service-2 variation-2 rbt-hover-02">
                            <div class="inner">
                                <div class="content">
                                    <h4 class="title"><a href="#">IELTS Exam</a></h4>
                                    <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                    <div class="row">
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-youtube"></i> 150 Free Video</li>
                                                <li><i class="feather-book"></i> 26 Subjects</li>
                                            </ul>
                                        </div>
                                        <div class="col-lg-6">
                                            <ul class="rbt-list-style-3">
                                                <li><i class="feather-video"></i> Live Class</li>
                                                <li><i class="feather-info"></i> MCQ and CQ Bank</li>
                                            </ul>
                                        </div>
                                    </div>
                                    <a class="rbt-btn btn-gradient hover-icon-reverse btn-sm mt--30" href="#">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Read More</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-03.png" alt="Education Images">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
            <script>
                jQuery(document).ready(function(){
                    var swiper = new Swiper('.service-item-3-activation', {
                        slidesPerView: 1,
                        spaceBetween: 0,
                        loop: false,
                        navigation: {
                            nextEl: '.rbt-arrow-left',
                            prevEl: '.rbt-arrow-right',
                            clickable: true,
                        },
                        breakpoints: {
                            480: {
                            slidesPerView: 1,
                            },
                            481: {
                            slidesPerView: 2,
                            },
                            768: {
                            slidesPerView: 3,
                            },
                            992: {
                            slidesPerView: 3,
                            },
                        },
                    });
                })
            </script>
        <!-- Start Service Area -->
        <div class="rbt-service-area bg-gradient-2 rbt-section-gapTop">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">ONLINE COURSE</span>
                            <h2 class="title">Our Online Course</h2>
                        </div>
                    </div>
                </div>
                <div class="swiper service-item-3-activation  rbt-arrow-between gutter-swiper-30">

                    <div class="swiper-wrapper">
                        <!-- Start Single Card  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-1">
                                    <div class="inner">
                                        <div class="content">
                                            <h4 class="title"><a href="#">React</a></h4>
                                            <p>React Js dolor sit, amet consectetur.</p>
                                            <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                        </div>
                                        <div class="thumbnail">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-06.png" alt="Education Images">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                        <!-- Start Single Card  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-2">
                                    <div class="inner">
                                        <div class="content">
                                            <h4 class="title"><a href="#">English</a></h4>
                                            <p>Spken english dolor sit, amet consectetur.</p>
                                            <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                        </div>
                                        <div class="thumbnail">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-05.png" alt="Education Images">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                        <!-- Start Single Card  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-3">
                                    <div class="inner">
                                        <div class="content">
                                            <h4 class="title"><a href="#">Education</a></h4>
                                            <p>Eearning edu dolor sit, amet consectetur.</p>
                                            <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                        </div>
                                        <div class="thumbnail">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-03.png" alt="Education Images">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->

                        <!-- Start Single Card  -->
                        <div class="swiper-slide">
                            <div class="single-slide">
                                <div class="rbt-service rbt-service-2 rbt-hover-02 bg-no-shadow card-bg-4">
                                    <div class="inner">
                                        <div class="content">
                                            <h4 class="title"><a href="#">Education</a></h4>
                                            <p>Lorem ipsum dolor sit, amet consectetur.</p>
                                            <a class="transparent-button" href="#">Learn More<i><svg width="17" height="12" xmlns="http://www.w3.org/2000/svg"><g stroke="#27374D" fill="none" fill-rule="evenodd"><path d="M10.614 0l5.629 5.629-5.63 5.629"/><path stroke-linecap="square" d="M.663 5.572h14.594"/></g></svg></i></a>
                                        </div>
                                        <div class="thumbnail">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/service/service-04.png" alt="Education Images">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- End Single Card  -->
                    </div>

                    <div class="rbt-swiper-arrow rbt-arrow-left">
                        <div class="custom-overfolow">
                            <i class="rbt-icon feather-arrow-left"></i>
                            <i class="rbt-icon-top feather-arrow-left"></i>
                        </div>
                    </div>

                    <div class="rbt-swiper-arrow rbt-arrow-right">
                        <div class="custom-overfolow">
                            <i class="rbt-icon feather-arrow-right"></i>
                            <i class="rbt-icon-top feather-arrow-right"></i>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Service Area -->
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <!-- Start Service Area -->
        <div class="rbt-service-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <h4 class="title">How to Apply</h4>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-moderbt-btn" href="#">
                                <span class="moderbt-btn-text">View All Requirements</span>
                                <i class="feather-arrow-right"></i>
                            </a>
                        </div>
                    </div>
                </div>

                <!-- Start Card Area -->
                <div class="row row--15 mt_dec--30">

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/001-bulb.png" alt="icons Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Your Apply</a></h6>
                                    <p class="description">English Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">1</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/002-hat.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">We Connect</a></h6>
                                    <p class="description">Javascript Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">2</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/003-id-card.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">You Get Ready</a></h6>
                                    <p class="description">Angular Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">3</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/004-pass.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Completed</a></h6>
                                    <p class="description">Php Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">4</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Service Area -->
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <!-- Start Service Area -->
        <div class="rbt-service-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                            <h2 class="title">Why Choose Us?</h2>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row row--15 mt_dec--30">
                    <!-- Start Single Card  -->
                    <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-flipbox">
                            <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-1">
                                <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                    <div class="icon">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-1.png" alt="card-icon">
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><a href="#">Best Coaching</a></h5>
                                        <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                        <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>

                                <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                    <p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                    <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                        <span data-text="Learn More">Learn More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-flipbox">
                            <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-2">
                                <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                    <div class="icon">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-2.png" alt="card-icon">
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><a href="#">Convenient practice</a></h5>
                                        <p>Convenient practice dolor sit adipisicing elit. Minima error reiciendis.</p>
                                        <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>

                                <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                    <p>Convenient practice dolor sit adipisicing elit. Minima error reiciendis.</p>
                                    <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                        <span data-text="Learn More">Learn More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-flipbox">
                            <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-3">
                                <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                    <div class="icon">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-3.png" alt="card-icon">
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><a href="#">Video Lecture</a></h5>
                                        <p>Video Lecture sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                        <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>

                                <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                    <p>Video Lecture sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                    <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                        <span data-text="Learn More">Learn More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                    <!-- Start Single Card  -->
                    <div class="col-xl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="rbt-flipbox">
                            <div class="rbt-flipbox-wrap rbt-service rbt-service-1 card-bg-4">
                                <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                    <div class="icon">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/card-icon-4.png" alt="card-icon">
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><a href="#">Live Class</a></h5>
                                        <p>Live Class dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                        <a class="rbt-btn-link stretched-link" href="#">Learn More<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>

                                <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                    <p>Live Class dolor sit, amet consectetur adipisicing elit. Minima error reiciendis.</p>
                                    <a class="rbt-btn rbt-switch-btn btn-white btn-sm" href="#">
                                        <span data-text="Learn More">Learn More</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Card  -->

                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Service Area -->
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
        <div class="rbt-service-area">
            <div class="container">
                <div class="row row--15 mt_dec--30">
                    <div class="col-lg-4 col-xl-4 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="section-title text-start">
                            <h2 class="title"><?php echo esc_html($settings['_style_7_section_title']); ?></h2>
                            <p class="description mt--20"><?php echo wp_kses_post($settings['_style_7_section_description']); ?></p>
                            <div class="read-more-btn">
                                <a class="rbt-btn btn-gradient radius rbt-marquee-btn marquee-text-y" href="<?php echo esc_url($settings['_style_7_btn_url']['url']); ?>">
                                    <span data-text="<?php echo esc_html($settings['_style_7_section_btn_text']); ?>"><?php echo esc_html($settings['_style_7_section_btn_text']); ?></span>
                                </a>
                            </div>
                        </div>
                    </div>
                    <?php foreach($settings['_style_7_flipbox_list'] as $item): ?>
                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-4 col-md-6 col-sm-6 col-12 mt--30 <?php echo 'elementor-repeater-item-' . esc_attr( $item['_id'] ); ?>">
                        <div class="rbt-flipbox">
                            <div class="rbt-flipbox-wrap rbt-service rbt-service-1">
                                <div class="rbt-flipbox-front rbt-flipbox-face inner">
                                    <div class="icon">
                                        <img src="<?php echo esc_url($item['flipbox_icon']['url']); ?>" alt="<?php echo \Elementor\Control_Media::get_image_alt($item['flipbox_icon']); ?>">
                                    </div>
                                    <div class="content">
                                        <h5 class="title"><a href="#"><?php echo esc_html($item['flipbox_title']); ?></a></h5>
                                        <p><?php echo wp_kses_post($item['flipbox_description']); ?></p>
                                    </div>
                                </div>

                                <div class="rbt-flipbox-back rbt-flipbox-face inner">
                                    <p><?php echo wp_kses_post($item['flipbox_back_description']); ?></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <!-- Start Service Area -->
        <div class="rbt-service-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">Why learn with our courses?</h2>
                            <p class="description mt--30"><strong>Histudy educational platform</strong> ipsum dolor sit amet consectetur adipisicing elit.</p>
                        </div>
                    </div>
                </div>
                <!-- Start Card Area -->
                <div class="row row--15 mt_dec--30">

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/001-bulb.png" alt="icons Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Your Apply</a></h6>
                                    <p class="description">English Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">1</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/002-hat.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">We Connect</a></h6>
                                    <p class="description">Javascript Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">2</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/003-id-card.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">You Get Ready</a></h6>
                                    <p class="description">Angular Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">3</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-4 col-xl-3 col-xxl-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="service-card service-card-6">
                            <div class="inner">
                                <div class="icon">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/004-pass.png" alt="Shape Images">
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Completed</a></h6>
                                    <p class="description">Php Learning looking for random paragraphs, you've come to the right place.</p>
                                </div>
                                <span class="number-text">4</span>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                </div>
                <!-- End Card Area -->
            </div>
        </div>
        <!-- End Service Area -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Service_Widget() );