<?php
wp_enqueue_style('olc_checkout_jquery-ui_css');
wp_enqueue_style('olc_checkout_font');
wp_enqueue_style('olc_checkout_style');
get_header();
$user_id = get_current_user_id();
$payment_option = WC()->session->get('olc_payment_option');
?>
<main class="cart-body">
    <div class="container-fluid">
        <div class="row">
            <div class="col-12 col-md-6 left-col">
                <a name="formstart"></a>
                <h1 class="heading current-title"></h1>
                <form action="https://openlearningcollege.ac/process" method="POST" id="checkout-form-submit">
                    <h3 class="heading current-title">
                        <span><span class="m-hidden">Student</span> details</span>
                    </h3>
                    <section step-name="step-student-details" class="olc-checkout-validation">

                        <div class="wrap">
                            <span id='phone-email-validation' style="color: #bf3260; font-size: 14px; margin-top: 10px; display: none;">Checking
                                your personal details...</span>
                            <div class="row">
                                <div class="col-lg-3 col-12">
                                    <label for="student_title">Title<span class="required"> *</span></label>
                                    <select name="student_title" id="student_title" style="height:50px!important;">
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Mr', true); ?> value="Mr">Mr</option>
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Mrs', true); ?> value="Mrs">Mrs</option>
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Miss', true); ?> value="Miss">Miss</option>
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Ms', true); ?> value="Ms">Ms</option>
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Mx', true); ?> value="Mx">Mx</option>
                                        <option <?php selected(get_user_meta($user_id, 'student_title', true), 'Dr', true); ?> value="Dr">Dr</option>
                                    </select>
                                </div>
                                <div class="topfield col-lg-4 col-12">
                                    <label for="student_firstname">First name <span class="required">
                                            *</span></label>
                                    <div class="form__controls">
                                        <input placeholder="Your first name" type="text" class="field form__field" name="student_firstname" id="student_firstname" value="<?php echo get_user_meta($user_id, 'student_firstname', true); ?>" maxlength="20" required />
                                    </div>
                                </div>
                                <div class="col-lg-5 col-12 topfield">
                                    <label for="student_lastname">Last name<span class="required">
                                            *</span></label>
                                    <div class="form__controls">
                                        <input placeholder="Your last name" type="text" class="field form__field" name="student_lastname" id="student_lastname" value="<?php echo get_user_meta($user_id, 'student_lastname', true); ?>" maxlength="20" required />
                                    </div>
                                </div>
                                <div class="col-12 dobpadding">
                                    <label>Date of birth<span class="required"> *</span>
                                        <span class="description">Required by awarding body</span>
                                    </label>
                                    <input type="date" name="student_dob" id="student_dob" placeholder="DD/MM/YYYY" class="required" minlength="10" maxlength="10" value="<?php echo get_user_meta($user_id, 'student_dob', true); ?>">

                                </div>
                                <div class="col-12">
                                    <label for="f_email">Email address<span class="required"> *</span></label>
                                    <div class="form__controls">
                                        <input placeholder="Your email address" type="text" class="field form__field student_email required email" name="student_email" id="student_email" value="<?php echo get_user_meta($user_id, 'student_email', true); ?>" />
                                    </div>
                                    <span id='loqate-email-error' style="color: #bf3260; font-size: 14px; margin-left: 1.5em; display: none;">Your
                                        email address could not be verified as valid.</span>
                                </div>
                                <?php if (!is_user_logged_in()) { ?>
                                    <div class="col-12">
                                        <label for="olc_checkout_password">Password<span class="required"> *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Password" type="password" class="field form__field student_email required email" name="student_email" id="olc_checkout_password" />
                                        </div>
                                        <span id='olc-checkout-password-error' style="color: #bf3260; font-size: 14px; display:none;">Your
                                            email address could not be verified as valid.</span>
                                    </div>
                                    <div class="col-12">
                                        <label for="olc_checkout_confirm_password">Confirm Password<span class="required"> *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Confirm password" type="password" class="field form__field student_email required email" name="student_email" id="olc_checkout_confirm_password" />
                                        </div>
                                        <span id='loqate-email-error' style="color: #bf3260; font-size: 14px; margin-left: 1.5em; display: none;">Your
                                            email address could not be verified as valid.</span>
                                    </div>
                                <?php } ?>
                                <div class="col-12">
                                    <label for="f_additional_requirements_switch">Do you require additional
                                        support?</label>
                                    <label class="additional_requirement_switch">
                                        <input class="additional_requirement_switch-input" id="additional_requirement_switch-input" type="checkbox" />
                                        <span class="additional_requirement_switch-label" data-on="Yes" data-off="No"></span>
                                        <span class="additional_requirement_switch-handle"></span>
                                    </label>
                                    <!-- should be hidden in default -->
                                    <label class="additional_requirements_area" for="f_additional_requirements">Please provide details about the support you
                                        require.</label>
                                    <div class="additional_requirements_area form__controls">
                                        <textarea placeholder="e.g. Additional learning needs" type="text" class="field form__field" name="additional_requirements" id="additional_requirements" value="" rows="5"><?php echo get_user_meta($user_id, 'additional_requirements', true); ?></textarea>
                                    </div>
                                </div>


                                <div class="col-12">
                                    <label for="f_phone">Telephone number<span class="required"> *</span></label>
                                    <div class="form__controls">
                                        <input placeholder="Your phone number" type="text" class="field form__field student_phone required phoneChar" name="student_phone" id="student_phone" value="<?php echo get_user_meta($user_id, 'student_phone', true); ?>" />
                                    </div>
                                    <span id='loqate-phone-error' style="color: #bf3260; font-size: 14px; margin-left: 1.5em; display: none;">Your
                                        phone number could not be verified as valid.</span>
                                </div>


                                <h3 class="heading" style="margin-top:32px;"><span><span class="m-hidden">Student</span> address</span></h3>
                                <div class="col-12">
                                    <p>Search for your address below. If your address is not listed please click 'Enter address manually'.</p>
                                </div>
                                <div id="olc_checkout_address_lookup" class="col-12">
                                    <input placeholder="Type your address" type="text" id="olc_checkout_autocomplete_field">
                                    <ul id="olc_checkout_suggestion_list">
                                    </ul>
                                    <div class="cart__banner olc-checkout-show-student-address">
                                        <a href="#">Enter address manually</a>
                                    </div>
                                </div>


                                <div class="address_block_hidden olc_checkout_student_address" style="display:none;padding:0!important;">
                                    <div class="col-12">
                                        <label for="student_address1">House/ Flat No.<span class="required">
                                                *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Flat, suite, unit, building, floor, etc." type="text" class="field form__field required" name="student_address1" id="student_address1" value="<?php echo get_user_meta($user_id, 'student_address1', true); ?>" required />
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label for="student_address2">Street Address<span class="required">
                                                *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Street and number, P.O. box, c/o." type="text" class="field form__field required" name="student_address2" id="student_address2" value="<?php echo get_user_meta($user_id, 'student_address2', true); ?>" required />
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label for="student_city">Town/City<span class="required">
                                                *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Your city" type="text" class="field fo<?php echo get_user_meta($user_id, 'student_address2', true); ?>rm__field required" name="student_city" id="student_city" value="<?php echo get_user_meta($user_id, 'student_city', true); ?>" />
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <label for="student_postcode">Postcode<span class="required">
                                                *</span></label>
                                        <div class="form__controls">
                                            <input placeholder="Your postcode" type="text" class="field form__field required" name="student_postcode" id="student_postcode" value="<?php echo get_user_meta($user_id, 'student_postcode', true); ?>" required />
                                        </div>
                                    </div>
                                    <div class="col-12">
                                        <style>
                                            #student_country_field span.woocommerce-input-wrapper {
                                                width: 100% !important;
                                            }
                                        </style>
                                        <label for="student_country">Country<span class="required">
                                                *</span></label>
                                        <div class="form__controls">
                                            <div class="select">
                                                <?php
                                                $student_country = get_user_meta($user_id, 'student_country', true);
                                                $countries_obj   = new WC_Countries();
                                                $countries   = $countries_obj->__get('countries');
                                                woocommerce_form_field('student_country', array(
                                                    'type'       => 'select',
                                                    'default'    => $student_country,
                                                    'class'      => array('chzn-drop'),
                                                    'placeholder'    => __('Enter something'),
                                                    'options'    => $countries
                                                ), 'GB');
                                                ?>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                </br>
                                <div class="col-12" style="display: flex;flex-direction: row;">
                                    <div class="checkbox  checkbox--tick is-active col-6">
                                        <input name="student-billing" type="radio" id="student-billing" class="checkbox__input" checked value="minor" />
                                        <label for="student-billing" class="checkbox__label  student-billing">I
                                            am the student and over 18</label>
                                    </div>
                                    <div class="checkbox  checkbox--tick col-6">
                                        <input name="student-billing" type="radio" id="billing" class="checkbox__input" value="parent" />
                                        <label for="billing" class="checkbox__label  billing">I am the
                                            parent/guardian of student under 18</label>
                                    </div>
                                </div>
                                <div class="col-12">
                                    <p>
                                        </br>Please note: if you are under the age of 18, we request that
                                        parent/guardian completes this enrolment on your
                                        behalf. If you are enrolling on behalf of someone else who is over the
                                        age of 18, please also choose this option.

                                    </p>
                                </div>
                                <div class="col-12">
                                    <div id="billing_details_container" style="display: none;">
                                        <h5 class="form__title">Billing address</h5>
                                        <div class="form__row form__row--primary">
                                            <div class="form__col">
                                                <label for="billing_firstname">First name<span class="required"> *</span></label>

                                                <div class="form__controls">
                                                    <input type="text" class="field form__field" name="billing_firstname" value="<?php echo get_user_meta($user_id, 'billing_firstname', true); ?>" id="billing_firstname" />
                                                </div><!-- /.form__controls -->
                                            </div><!-- /.form__col -->
                                            <div class="form__col">
                                                <label for="billing_lastname">Last name<span class="required"> *</span></label>

                                                <div class="form__controls">
                                                    <input type="text" class="field form__field" name="billing_surname" value="<?php echo get_user_meta($user_id, 'billing_lastname', true); ?>" id="billing_lastname" />
                                                </div><!-- /.form__controls -->
                                            </div><!-- /.form__col -->
                                        </div>
                                        <style>
                                            #billing_country_field span.woocommerce-input-wrapper {
                                                width: 100% !important;
                                            }
                                        </style>
                                        <div id="billing-address" class="form__row fr" style="display: none;">
                                            <label for="f_address1">Select your address</label>
                                            <div class="autocomplete-suggestions list-addresses addressresults" id="addressresults_billing">
                                            </div>
                                        </div>
                                        <div id="olc_checkout_parent_address_lookup">
                                            <div class="form__row">
                                                <label for="f_email">Your address<span class="required">
                                                        *</span></label>
                                                <div class="form__controls">
                                                    <input type="text" placeholder="Start typing your address" id="olc_checkout_autocomplete_parent_field" class="field form__field" name="billing_address1" />
                                                </div>
                                            </div>
                                            <div class="cart__banner olc-checkout-show-parent-address">
                                                <a href="#">Enter address manually</a>
                                            </div>

                                        </div>
                                        <div class="address_billing_block_hidden" id="olc_checkout_parent_billing_address" style="display:none;">
                                            <div class="form__row">
                                                <label for="f_email">Address 1<span class="required">
                                                        *</span></label>
                                                <div class="form__controls">
                                                    <input type="text" class="field form__field" name="billing_address1" value="<?php echo get_user_meta($user_id, 'billing_address1', true); ?>" id="billing_address1" />
                                                </div>
                                                <div class="form__row">
                                                    <label for="f_email">Address 2</label>

                                                    <div class="form__controls">
                                                        <input type="text" class="field form__field" name="billing_address2" value="<?php echo get_user_meta($user_id, 'billing_address2', true); ?>" id="billing_address2" />
                                                    </div><!-- /.form__controls -->
                                                </div><!-- /.form__col -->
                                                <div class="form__row">
                                                    <label for="f_email">City</label>

                                                    <div class="form__controls">
                                                        <input type="text" class="field form__field" name="billing_towncity" value="<?php echo get_user_meta($user_id, 'billing_city', true); ?>" id="billing_city" />
                                                    </div><!-- /.form__controls -->
                                                </div><!-- /.form__col -->
                                                <div class="form__row">
                                                    <label for="f_email">Postcode</label>

                                                    <div class="form__controls">
                                                        <input type="text" class="field form__field" name="billing_postcode" value="<?php echo get_user_meta($user_id, 'billing_postcode', true); ?>" id="billing_postcode" />
                                                    </div><!-- /.form__controls -->
                                                </div><!-- /.form__col -->
                                                <div class="form__row">
                                                    <label for="billing_country">Country</label>
                                                    <div class="form__controls">
                                                        <div class="select">
                                                            <?php
                                                            $billing_country = get_user_meta($user_id, 'billing_country', true);
                                                            $countries_obj   = new WC_Countries();
                                                            $countries   = $countries_obj->__get('countries');
                                                            woocommerce_form_field('billing_country', array(
                                                                'type'       => 'select',
                                                                'default'    => $billing_country,
                                                                'class'      => array('chzn-drop'),
                                                                'placeholder'    => __('Enter something'),
                                                                'options'    => $countries
                                                            ), 'GB');
                                                            ?>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                            </br>
                                        </div>
                                    </div>
                                    <!-- <div class="col-12"> -->
                                    <div class="checkbox olc-checkout">
                                        <input type="checkbox" name="confirm" id="confirm" class="required" />
                                        <label for="confirm">I confirm that I have read and agree with Open Learning College's <a href="https://openlearningcollege.ac/t-cs/" data-modal-class="mfp-white" target="_blank" class="js-popup-inline" style="color: black;">terms & conditions
                                                of sale</a></label>
                                    </div>
                                    <!-- <hr> -->
                                    <!-- </div> -->
                                    <!-- <div class="col-12"> -->
                                    <button type="button" id="olc_checkout_continue">Continue</button>
                                    <!-- </div> -->
                                </div>
                            </div>
                    </section>

                    <input type="hidden" name="input-discount-code" id="input-discount-code" />
                    <input type="hidden" name="input-affiliate-id" id="input-affiliate-id" value="" />
                    <input type="hidden" name="input-gclid" id="input-gclid" value="" />
                </form>

            </div>

            <div class="col-12 col-md-5 offset-md-1 right-col">

                <div class="cart olc-checkout-cart-data">
                    <?php
                    $study_pack_qty = 0;
                    $cart_items = WC()->cart->get_cart();
                    $upsell_products_added = [];
                    foreach ($cart_items as $cart_item_id => $item) {
                        $product_id = $item['product_id'];
                        $product = wc_get_product($product_id);
                        if (isset($item['upsell_product'])) {
                            $upsell_products_added[$cart_item_id] = $product_id;
                        }
                        if (isset($item['upsell_product'])) continue;
                        if (!isset($item['study_option'])) continue;
                        $study_type = $item['study_option'] == "study_online" ? "Online" : "Study Pack";
                        if ($study_type == "Study Pack") {
                            $study_pack_qty += 1;
                        }
                    ?>
                        <div class="cart-item row">
                            <div class="col-8 cart-item__header">
                                <div class="cart-item__title-container">
                                    <h3 class="cart-item__title"><?php echo $product->get_name(); ?></h3>
                                </div>
                                <p class="cart-item__study-method">Study method: <?php echo $study_type; ?></p>
                                <input type="hidden" name="item_price" value="<?php echo $product->get_price(); ?>" />
                                <button type="button" class="remove-btn" data-cart-item-key="<?php echo $cart_item_id; ?>">Remove</button>
                            </div>
                            <div class="col-4 cart-item__price">
                                <span>
                                    <?php
                                    if ($payment_option == 'pay_monthly') {
                                        echo wc_price($product->get_regular_price());
                                    } else {
                                        echo wc_price($product->get_price());
                                    }
                                    ?>
                                </span>
                            </div>
                        </div>
                    <?php } ?>
                    <?php
                    $extra_products = get_option('olc_checkout_upsell_products_list');
                    if ($extra_products != "") { ?>
                        <div class="cart-options">
                            <h4 class="payment-options__heading">Additional options</h4>

                            <?php
                            $extra_products = explode(',', $extra_products);
                            foreach ($extra_products as $key => $extra_product_id) {
                                $extra_product = wc_get_product($extra_product_id);
                                if (!$extra_product->get_price()) continue;
                            ?>
                                <div class="cart-options__item">
                                    <label class="cart-options__label">
                                        <input <?php echo in_array($extra_product_id, $upsell_products_added) ? 'checked' : ''; ?> type="checkbox" name="addon[]" value="<?php echo $extra_product->get_price(); ?>" cost="<?php echo $extra_product->get_price(); ?>" class="addonrow cart-options__input additiona_cart_item" addon-text="career kickstart package" data-extra-id="<?php echo $key; ?>" data-product-id="<?php echo $extra_product_id; ?>" data-cart-id="<?php echo array_search($extra_product_id, $upsell_products_added); ?>" />
                                        <div class="cart-options__title">
                                            <strong><?php echo $extra_product->get_name(); ?></strong>
                                            <span class="u-regular"><?php echo wc_price($extra_product->get_price()); ?></span>
                                        </div>
                                        <div class="cart-options__desc"><?php echo $extra_product->get_short_description(); ?></div>
                                    </label>
                                </div>
                            <?php } ?>
                        </div>
                    <?php } ?>
                    <div class="col-12 col-lg-12 discount-code__row" style="padding:0;">
                        <button class="discount-code__open-btn" id="discount-code-btn">Have a discount
                            code?</button>

                        <p class="discount-code__note-text">Please note: We only publish discount codes online via
                            official Open Learning College channels.</p>

                        <div class="cart-detail cart-studymethod discount-code" style="display: block;">
                            <div class="form__controls discount-code__form" style="margin-top:16px;">
                                <label for="discount-code" class="sr-only">Discount code</label>
                                <input type="text" name="discount-code" class="discount-code__input" id="discount-code" placeholder="Enter your discount code" oninput="let p=this.selectionStart;this.value=this.value.toUpperCase();this.setSelectionRange(p, p);">
                                <button class="discount-code__apply-btn" id="add-discount-code" value="Apply">Apply</button>
                            </div>
                            <p class="discount-code__confirmation discount-code-applied" style="display: none">
                                Discount code applied</p>
                        </div>
                    </div>
                    <div class="cart-details cart-addons"></div>
                    <?php
                    $additional_fee = 0;
                    foreach (WC()->cart->get_cart() as $item_id => $item) {
                        $product_id = $item['product_id'];
                        $product = wc_get_product($product_id);
                        if (!isset($item['upsell_product'])) continue;
                        $additional_fee += floatval($product->get_sale_price());
                    }
                    ?>
                    <div class="cart-detail cart-price cart-delivery mt-3 row">
                        <div class="col-6 cart__total">Subtotal</div>
                        <div class="col-6 u-right-align">
                            <span>
                                <strong class="sub-total ml-2">
                                    <?php
                                    $sub_total = floatval(WC()->cart->subtotal) - $additional_fee;
                                    echo wc_price($sub_total);
                                    ?>
                                </strong>
                            </span>
                        </div>
                    </div>
                    <?php
                    $unit_delivery_fee = get_option('olc_checkout_study_pack_delivery_fee') ?: '49.99';
                    $delivery_fee = $study_pack_qty * floatval($unit_delivery_fee);
                    if ($study_pack_qty > 0) {
                    ?>
                        <div class="cart-detai
                        l cart-studymethod cart-delivery row">
                            <div class="col-6"><?php echo get_option('olc_checkout_study_pack_stripe_product_name') ?: 'Study pack delivery fee'; ?></div>
                            <div class="col-6 u-right-align">
                                <span><strong id="delivery_price"><?php echo $delivery_fee == 0 ? 'Free' : wc_price($delivery_fee); ?></strong></span>
                            </div>
                        </div>
                    <?php } ?>
                    <?php
                    foreach (WC()->cart->get_cart() as $item_id => $item) {
                        $product_id = $item['product_id'];
                        $product = wc_get_product($product_id);
                        if (!isset($item['upsell_product'])) continue;
                    ?>
                        <div class="cart-detail cart-studymethod cart-delivery row">
                            <div class="col-6"><?php echo $product->get_name(); ?></div>
                            <div class="col-6 u-right-align">
                                <span><strong id="delivery_price"><?php echo wc_price($product->get_sale_price()); ?></strong></span>
                            </div>
                        </div>
                    <?php
                    }
                    ?>
                    <?php if (WC()->cart->get_discount_total()) { ?>
                        <div class="cart-detail cart-price cart-delivery mt-3 row">
                            <div class="col-6">Discount</div>
                            <div class="col-6 u-right-align">
                                <span>
                                    <strong class="sub-total ml-2">
                                        <?php
                                        echo '-' . wc_price(WC()->cart->get_discount_total());
                                        ?>
                                    </strong>
                                </span>
                            </div>
                        </div>
                    <?php } ?>
                    <div class="cart-detail cart-studymethod cart-addons row"></div>
                    <div class="cart-detail cart-price row <?php echo $payment_option == 'pay_monthly' ? 'cart-delivery' : ''; ?>">
                        <div class="col-6 cart__total">Total</div>
                        <div class="col-6 u-right-align">
                            <span>
                                <strong class="current_total">
                                    <?php
                                    $the_grand_total = floatval(WC()->cart->total) + $delivery_fee;
                                    echo wc_price($the_grand_total);
                                    ?>
                                </strong>
                            </span>
                        </div>
                    </div>
                    <?php

                    if ($payment_option == 'pay_monthly') {
                        $payment_slot = floatval(get_option('olc_checkout_instalment_qty') ?: 5);
                        $sub_fee = floatval(get_option('olc_checkout_additional_fee') ?: 0);
                    ?>
                        <div class="cart-detail cart-delivery cart-price row">
                            <div class="col-6">Monthly Instalment x4</div>
                            <div class="col-6 u-right-align">
                                <span>
                                    <strong class="current_total">
                                        <?php
                                        $the_grand_total = floatval(WC()->cart->total);
                                        $instalment_of_grand_total = ($the_grand_total / $payment_slot);
                                        echo wc_price($instalment_of_grand_total);
                                        ?>
                                    </strong>
                                </span>
                            </div>
                        </div>
                        <div class="cart-detail cart-price row">
                            <div class="col-6 cart__total">Initial Deposit</div>
                            <div class="col-6 u-right-align">
                                <span>
                                    <strong class="current_total">
                                        <?php
                                        $intial_deposit = $the_grand_total / $payment_slot + $delivery_fee;
                                        echo wc_price($intial_deposit);
                                        ?>
                                    </strong>
                                </span>
                            </div>
                        </div>
                    <?php } ?>
                </div>
                <div class="cart__banner">
                    <a href="<?php echo get_option('olc_checkout_add_more_course') ?: home_url('/'); ?>"><img src="<?php echo plugin_dir_url(__FILE__); ?>/images/icons/plus-circle.svg">Add more
                        courses</a>
                </div>

                <div class="row">
                    <div class="col-12">
                        <div class="payment-options u-mt2">
                            <h4 class="payment-options__heading">Payment options</h4>
                            <div class="payment-options__container">
                                <img src="<?php echo plugin_dir_url(__FILE__); ?>images/icons/payment/visa.svg" class="payment-options__logo payment-options__logo--visa">
                                <img src="<?php echo plugin_dir_url(__FILE__); ?>images/icons/payment/mastercard.svg" class="payment-options__logo payment-options__logo--mastercard">
                                <img src="<?php echo plugin_dir_url(__FILE__); ?>images/icons/payment/maestro.svg" class="payment-options__logo payment-options__logo--maestro">
                                <img src="<?php echo plugin_dir_url(__FILE__); ?>images/icons/payment/american-express.svg" class="payment-options__logo payment-options__logo--amex">
                                <img src="<?php echo plugin_dir_url(__FILE__); ?>images/icons/payment/diners-club.svg" class="payment-options__logo payment-options__logo--diners">
                            </div>
                        </div>
                    </div>
                </div>



            </div>
            <script>
                var submitbtn_text = '';
            </script>

            <div id="finance-popup" class="container popup-css modal">
                <div class="row">
                    <div class="col-sm-12 text-center page-title">
                        <h1>Finance options </h1>
                    </div>
                    <div class="col-12 col-md-6 finance-left-col">
                        <div class="block">
                            <div class="row">
                                <div class="col-12">
                                    <h5 class="widget__title">Length Of Your Repayment</h5>
                                    <div class="select select-hover">
                                        <select id="finance-term-select">
                                            0
                                            16.9
                                            <option value="IBC-12-169" selected=&quot;selected&quot;>12 months at
                                                16.9%</option>
                                            16.9
                                            <option value="IBC-24-169">24 months at 16.9%</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-12">
                                    <h5 class="widget__title">Your Deposit</h5>
                                    <div class="select select-hover">
                                        <select name="field-deposit" id="finance-deposit-select" required="">
                                            <option value="0" selected=&quot;selected&quot;>0%</option>
                                            <option value="5">5%</option>
                                            <option value="10">10%</option>
                                            <option value="15">15%</option>
                                            <option value="20">20%</option>
                                            <option value="25">25%</option>
                                            <option value="30">30%</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="col-6 finance-price-block">
                                    <h5>Monthly payment</h5>
                                    <div class="loading">
                                        <img class="spinner" src="<?php echo plugin_dir_url(__FILE__); ?>/images/icons/loading.svg" />
                                    </div>
                                    <span class="finance-monthly ajax-field"></span>
                                </div>
                                <div class="col-6 finance-price-block">
                                    <h5>Deposit you pay</h5>
                                    <div class="loading">
                                        <img class="spinner" src="<?php echo plugin_dir_url(__FILE__); ?>/images/icons/loading.svg" />
                                    </div>
                                    <span class="finance-deposit ajax-field"></span>
                                </div>
                                <form action="https://openlearningcollege.ac/courses/add" method="POST" id="add-to-basket-form" target="_parent">
                                    <input type="hidden" name="_token" value="jqyVx0pzajSBBp8xjAFDGYS79RrSM2VoaZpWlQMw">
                                    <input type="hidden" name="finance-product" value="IBC-12-169" />
                                    <input type="hidden" name="finance-deposit" value="30" />
                                    <input type="hidden" name="payplan" value="finance">
                                    <input type="hidden" name="studymethod" value="">
                                    <input type="hidden" name="gclid" value="">
                                </form>
                                <div class="widget__actions hidden-mobile add-to-basket">
                                    <a class="btn btn--size3 btn-close-popup btn-finance-hover-atb" style="color: white;margin-top: 10px;padding-left: 30px;padding-right: 30px;" rel="modal:close">Update Basket</a>
                                </div>
                                <div class="col-12">
                                    <ul class="finance-breakdown">
                                        <li style="display: none">
                                            <span>Cash Price:</span>
                                            <strong class="finance-cashprice"></strong>
                                        </li>
                                        <li>
                                            Loan Amount:
                                            <span><strong class="finance-loanamount"></strong></span>
                                        </li>
                                        <li>
                                            Loan Repayments:
                                            <span><strong class="finance-loanrepayment"></strong></span>
                                        </li>
                                        <li>
                                            Cost of Loan:
                                            <span><strong class="finance-costofloan"></strong></span>
                                        </li>
                                        <li>
                                            Number of Monthly Payments:
                                            <span><strong class="finance-numberofpayments"></strong></span>
                                        </li>
                                        <li>
                                            Total Amount Payable:
                                            <span><strong class="finance-amountpayable"></strong></span>
                                        </li>
                                    </ul>
                                </div>
                                <p style="font-size: 16px;"><br>The total course fee includes a loan arrangement
                                    fee. Your initial deposit payment will be used towards this fee, any remaining
                                    fee balance will be added the loan amount.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 col-md-6 finance-right-col">
                        <div class="widget__col">
                            <div class="widget__content">
                                <h5 class="providedby">Provided by <span class="logo-afforditnow logo-afforditnow--small"></span></h5>
                                <p>
                                    Our finance option is provided in partnership with etika. <br>
                                    For your finance application to be considered you must meet the following
                                    criteria:
                                </p>

                                <ul style="margin-left: 5%;">
                                    <li>Be over 18 years old</li>

                                    <li>Be employed for at least 16 hours a week or retired and in receipt of a
                                        private or company pension. Certain state benefit schemes may also be
                                        considered.</li>

                                    <li>Be a permanent UK resident with a 3 year address history</li>

                                    <li>Have a good credit history with no late payments, debt relief orders or
                                        bankruptcies</li>

                                    <li>Have a valid email address and can access it</li>

                                </ul><!-- /.list-checks -->

                                <p>
                                    Please note that meeting the above criteria does not guarantee finance
                                    acceptance.
                                </p>
                                <p>
                                    <STRONG style="color: #000000;font-size: 16px;">If you’re looking to enrol on a
                                        course and you have some questions about your etika application or would
                                        like to discuss other payment options, please give us a call on 03304 331
                                        774.</STRONG>
                                </p>
                                <p>
                                    Open Learning College, 1760 Solihull Parkway, Birmingham Business Park, Birmingham
                                    B37 7YD is a licensed credit broker, authorised and regulated by The Financial
                                    Conduct Authority (licence number 724179 with FCA).
                                </p>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</main>

<?php get_footer(); ?>