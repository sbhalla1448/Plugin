<?php
use Stripe\StripeClient;
use Stripe\Stripe;
include ABSPATH . 'wp-includes/pluggable.php';
add_action('wp_ajax_create_order_and_generate_session','olc_checkout_create_order_and_generate_session_callback');
add_action('wp_ajax_nopriv_create_order_and_generate_session','olc_checkout_create_order_and_generate_session_callback');
function olc_checkout_create_order_and_generate_session_callback(){
   if(isset($_POST['action']) && $_POST['action'] == "create_order_and_generate_session" ) {
      $password = sanitize_text_field( $_POST['password'] );
      $student_email = sanitize_text_field( $_POST['student_email'] );
      $user_id = get_current_user_id();
      if( !is_user_logged_in() ) {
         try{
            $user_id = mfht_create_custom_user( $student_email, $password );
         } catch( Exception $e ) {
            wp_send_json_error($e->getMessage());
         }
         olc_checkout_programmatic_login( $student_email );
      }
      $student_title = sanitize_text_field( $_POST['student_title'] );
      update_user_meta($user_id, 'student_title',$student_title);
      $student_firstname = sanitize_text_field( $_POST['student_firstname'] );
      update_user_meta($user_id, 'student_firstname',$student_firstname);
      $student_lastname = sanitize_text_field( $_POST['student_lastname'] );
      update_user_meta($user_id, 'student_lastname',$student_lastname);
      $student_dob = sanitize_text_field( $_POST['student_dob'] );
      update_user_meta($user_id, 'student_dob',$student_dob);
      update_user_meta($user_id, 'student_email',$student_email);
      $required_additional_info = sanitize_text_field( $_POST['required_additional_info'] );
      update_user_meta($user_id, 'required_additional_info',$required_additional_info);
      $additional_info = sanitize_text_field( $_POST['additional_info'] );
      update_user_meta($user_id, 'additional_info',$additional_info);
      $student_phone = sanitize_text_field( $_POST['student_phone'] );
      update_user_meta($user_id, 'student_phone',$student_phone);
      $student_address1 = sanitize_text_field( $_POST['student_address1'] );
      update_user_meta($user_id, 'student_address1',$student_address1);
      $student_address2 = sanitize_text_field( $_POST['student_address2'] );
      update_user_meta($user_id, 'student_address2',$student_address2);
      $student_city = sanitize_text_field( $_POST['student_city'] );
      update_user_meta($user_id, 'student_city',$student_city);
      $student_postcode = sanitize_text_field( $_POST['student_postcode'] );
      update_user_meta($user_id, 'student_postcode',$student_postcode);
      $student_country = sanitize_text_field( $_POST['student_country'] );
      update_user_meta($user_id, 'student_country',$student_country);
      $is_student_minor = sanitize_text_field( $_POST['is_student_minor'] );
      update_user_meta($user_id, 'is_student_minor',$is_student_minor);
      $billing_firstname = sanitize_text_field( $_POST['billing_firstname'] );
      update_user_meta($user_id, 'billing_firstname',$billing_firstname);
      $billing_lastname = sanitize_text_field( $_POST['billing_lastname'] );
      update_user_meta($user_id, 'billing_lastname',$billing_lastname);
      $billing_address1 = sanitize_text_field( $_POST['billing_address1'] );
      update_user_meta($user_id, 'billing_address1',$billing_address1);
      $billing_address2 = sanitize_text_field( $_POST['billing_address2'] );
      update_user_meta($user_id, 'billing_address2',$billing_address2);
      $billing_city = sanitize_text_field( $_POST['billing_city'] );
      update_user_meta($user_id, 'billing_city',$billing_city);
      $billing_postcode = sanitize_text_field( $_POST['billing_postcode'] );
      update_user_meta($user_id, 'billing_postcode',$billing_postcode);
      $billing_country = sanitize_text_field( $_POST['billing_country'] );
      update_user_meta($user_id, 'billing_country',$billing_country);
      // $terms_and_condition = sanitize_text_field( $_POST['terms_and_condition'] );
      // cart products
      $course_ids = [];
      $course_names = [];
      $courses = WC()->cart->get_cart();
      $study_pack_qty = 0;
      foreach( $courses as $course_key => $course ) {
         // if( !isset($course['study_option']) || !isset($course['payment_option']) ) continue;
         $course_ids[] = $course['product_id'];
         $product = wc_get_product( $course['product_id'] );
         $course_names[] = $product->get_name();
         if( isset($course['study_option']) && $course['study_option'] == "study_pack" ) {
            $study_pack_qty += 1;
         }
      }
      $total = WC()->cart->total;
      // create order
      // get the product
      $product = wc_get_product( $product_id );
      $user_billing_address = array(
         'first_name' => $is_student_minor == "parent" ? $billing_firstname : $first_name,
         'last_name' => $is_student_minor == "parent" ? $billing_lastname : $last_name,
         'company' => '',
         'email' => $student_email,
         'phone' => $student_phone,
         'address_1' =>  $is_student_minor == "parent" ? $billing_address1 : $student_address1,
         'address_2' => $student_address2,
         'city' => $student_city,
         // 'state' => $state,
         'postcode' => $student_postcode,
         'country' => $student_country
      );
      $order = wc_create_order();
      foreach( $course_ids as $course_id ) {
         $a_course_product = wc_get_product( $course_id );
         $order->add_product( $a_course_product, 1 );
      }
      $order->set_customer_id( $user_id );
      $order->set_address( $user_billing_address, 'billing' );
      $order->set_address( $user_billing_address, 'shipping' );
      $order->calculate_totals();
      // $order->update_status('completed');
      $order_id = $order->get_id();
      // for tutor lms course identification
      $gmt_offset = get_option( 'gmt_offset' );
      update_post_meta($order_id,'_is_tutor_order_for_course',time() + ( $gmt_offset * HOUR_IN_SECONDS ));
      $order->save();
      // stripe private key
      $private_key = get_option('olc_checkout_stripe_private_key');
      $stripe = new \Stripe\StripeClient($private_key);
      $stripe_payload = [
         'line_items' => [
            [
               'quantity' => 1,
               'price_data' => [
                  'currency' => $order->get_currency(),
                  'unit_amount' => $total * 100,
                  // 'recurring' => [
                  //    'interval' => 'month',
                  // ],
                  'product_data' => [
                     'name' => implode(', ', $course_names)
                  ],
               ],
            ],
         ],
         'success_url' => get_option('olc_checkout_checkout_success_url') ?: 'https://openlearningcollege.ac/dashboard',
         'cancel_url' => get_option('olc_checkout_failed_url') ?: 'https://openlearningcollege.ac/course-finder',
         'customer_email' => $student_email,
         // 'payment_intent_data' => [
         //    'description' => $description,
         // ],
         'payment_intent_data' => [
            'metadata' => [
               'order_id'  => $order_id,
               'user_id'   => $user_id,
               'mode'      => 'payment',
               'order'     => $order->get_currency()
            ]
         ],
         'mode' => 'payment',
         // 'subscription_data' => [
         //    'trial_period_days' => 7,
         //    'metadata' => [
         //       'order_id'  => 'order_id',
         //       'user_id'   => 'user_id'
         //    ]
         // ],
         'metadata' => [
            'order_id' => $order_id
         ],
         // 'currency' => 'USD',
         // 'customer_creation' => 'always'
      ];
      // modify if subscription
      // set recurring
      if( WC()->session->get('olc_payment_option') == 'pay_monthly' ) {
         $payment_slot = floatval(get_option('olc_checkout_instalment_qty') ?: 5);
         update_post_meta( $order_id, 'olc_checkout_payment_slot', $payment_slot );
         $sub_fee = floatval(get_option('olc_checkout_additional_fee') ?: 0);
         $total = floatval(WC()->cart->total);
         $subscription_fee = ($total * $sub_fee / 100) * 0;
         $intial_deposit = ( $subscription_fee + $total ) / $payment_slot;
         $stripe_payload['line_items'][0]['price_data'] = [
            'currency' => $order->get_currency(),
            'unit_amount' => $intial_deposit * 100,
            'recurring' => [
               'interval' => 'month',
            ],
            'product_data' => [
               'name' => implode(', ', $course_names)
            ],
         ];
         unset($stripe_payload['payment_intent_data']);
         // change mode
         $stripe_payload['mode'] = 'subscription';
         $stripe_payload['subscription_data'] = [
            'metadata' => [
               'order_id'  => $order_id,
               'user_id'   => $user_id,
               'mode'      => 'subscription'
            ]
         ];
      }
      if( $study_pack_qty > 0 ) {
         $study_pack_product_name = get_option('olc_checkout_study_pack_stripe_product_name') ?: 'Study pack delivery fee';
         $unit_delivery_fee = get_option('olc_checkout_study_pack_delivery_fee') ?: '49.99';
         $stripe_payload['line_items'][1]['price_data'] = [
            'currency' => $order->get_currency(),
            'product_data' => [
               'name' => $study_pack_product_name
            ],
            'unit_amount' => floatval($unit_delivery_fee) * 100 * $study_pack_qty
         ];
         $stripe_payload['line_items'][1]['quantity'] = 1;
      }
      WC()->cart->empty_cart();
      try{
         $session = $stripe->checkout->sessions->create($stripe_payload);
      } catch( Exception $e) {
         wp_send_json_erro( $e->getMessage() );
      }
      wp_send_json_success(array(
         // 'student_title' => $student_title,
         // 'student_firstname' => $student_firstname,
         // 'student_lastname' => $student_lastname,
         // 'student_dob' => $student_dob,
         // 'student_email' => $student_email,
         // 'required_additional_info' => $required_additional_info,
         // 'additional_info' => $additional_info,
         // 'student_phone' => $student_phone,
         // 'student_address1' => $student_address1,
         // 'student_address2' => $student_address2,
         // 'student_city' => $student_city,
         // 'student_postcode' => $student_postcode,
         // 'student_country' => $student_country,
         // 'is_student_minor' => $is_student_minor,
         // 'billing_firstname' => $billing_firstname,
         // 'billing_lastname' => $billing_lastname,
         // 'billing_address1' => $billing_address1,
         // 'billing_address2' => $billing_address2,
         // 'billing_city' => $billing_city,
         // 'billing_postcode' => $billing_postcode,
         // 'billing_country' => $billing_country,
         // 'terms_and_condition' => $terms_and_condition,
         'session' =>  $session,
         // 'password' => $password
      ));
   }
   wp_die();
}
add_action('wp_ajax_remove_cart_item','olc_checkout_remove_cart_item');
add_action('wp_ajax_nopriv_remove_cart_item','olc_checkout_remove_cart_item');
function olc_checkout_remove_cart_item(){
   if( isset($_POST['dataset']) ) {
      $item_key = sanitize_text_field( $_POST['dataset'] );
      $removed = WC()->cart->remove_cart_item( $item_key );
      $course_count = 0;
      foreach( WC()->cart->get_cart() as $cart_item_key => $cart_item ) {
         if( isset($cart_item['payment_option']) && isset($cart_item['study_option']) ) {
            $course_count++;
            break;
         }
      }
      if( $course_count == 0 ) {
         WC()->cart->empty_cart();
         wp_send_json_error('redirect');
         // $redirect_url = get_option('olc_checkout_failed_url') ?: 'https://openlearningcollege.ac/course-finder';
         // wp_direct( $redirect_url, 301 );
         // die();
      }
      include( OLC_CHECKOUT_PATH . '/cart-template.php' );
      // wp_send_json_success( $removed );
   }
   wp_die();
}
add_action('wp_ajax_apply_the_coupon','apply_the_coupon_callback');
add_action('wp_ajax_nopriv_apply_the_coupon','apply_the_coupon_callback');
function apply_the_coupon_callback(){
   if( isset($_POST['dataset']) ) {
      $coupon_code = sanitize_text_field( $_POST['dataset'] );
      $the_coupon = new WC_Coupon( $coupon_code );
      $is_valid = $the_coupon->is_valid();
      if( $is_valid ) {
         WC()->cart->remove_coupons();
      } else {
         wp_send_json_error('Coupon is not valid');
      }
      if ( ! WC()->cart->has_discount( $coupon_code ) ) {
         $applied = WC()->cart->apply_coupon( $coupon_code );
         if( !$applied ) {
            wp_send_json_error('Coupon does not exist or cannot be applied.');
         }
      }
      WC()->cart->calculate_totals();
      // wp_send_json_success('Discount has been applied.');
      include( OLC_CHECKOUT_PATH . '/cart-template.php' );
   }
   wp_die();
}
add_action('wp_ajax_enroll_now_action','enroll_now_action_callback');
add_action('wp_ajax_nopriv_enroll_now_action','enroll_now_action_callback');
function enroll_now_action_callback(){
   if( isset($_POST['dataset']) ) {
      $study_option = $_POST['dataset'][0];
      $payment_option = $_POST['dataset'][1];
      $product_id = $_POST['dataset'][2];
      // $cart_items = WC()->cart->get_cart();
      // foreach( $cart_items as $item_key => $item ) {
      //    if( $product_id == $item['product_id'] ) wp_send_json_error(__('This course already added to be enrolled.','olc_checkout'));
      // }
      $current_item_option = WC()->session->get('olc_payment_option');
      if( $current_item_option != $payment_option ) {
         WC()->cart->empty_cart();
         WC()->session->set('olc_payment_option', $payment_option);
      }
      $cart_item_key = WC()->cart->add_to_cart( $product_id, 1, 0, array() , array( 
         'study_option' => $study_option,
         'payment_option' => $payment_option
      ));
      wp_send_json_success(array(
         'item_key' => $cart_item_key,
         'product_id' => $product_id,
         'payment_option' => $payment_option,
         'study_option' => $study_option
      ));
   }
   wp_die();
}
add_action('wp_ajax_process_additional_products','process_additional_products_callback');
add_action('wp_ajax_nopriv_process_additional_products','process_additional_products_callback');
function process_additional_products_callback(){
   if(isset($_POST['action']) && isset($_POST['product_id']) ) {
      $cart_id = $_POST['cart_id'];
      $product_id = $_POST['product_id'];
      $type = $_POST['type'];
      if( $type == "remove" && $cart_id != "" ) {
         WC()->cart->remove_cart_item( $cart_id );
      } else {
         WC()->cart->add_to_cart( $product_id, 1, 0, array(), array(
            'upsell_product' => true
         ));
      }
      // wp_send_json_success(array(
      //    'cart_id' => $cart_id,
      //    'product_id' => $product_id,
      //    'type' => $type
      // ));
      include( OLC_CHECKOUT_PATH . '/cart-template.php' );
   }
   wp_die();
}