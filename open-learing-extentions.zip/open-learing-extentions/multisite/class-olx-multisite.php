<?php
/**
 * Multisite Hanlde Class
 */

class Multisite{

    private static $instance = false;

    public function __construct(){
        // add_action('admin_init', array($this, 'admin_ban_wpse_105863') );
        add_action('init', array($this, 'olc_new_user_role'));
        add_action('wp_enqueue_scripts', array( $this, 'enqueue_scripts'));
        add_action('wp_ajax_create_user_site', array($this, 'create_site'));
        add_action('wp_ajax_nopriv_create_user_site', array($this, 'create_site'));
        add_filter('woocommerce_install_skip_install_data', array($this, 'skip_woocommerce_installation'), 10, 4); 
    }

    public function enqueue_scripts(){
        wp_enqueue_script('multisite-checkout', OLX_URL . 'multisite/js/multisite-checkout.js', array('jquery'), '1.0.0', true);
        wp_localize_script('multisite-checkout', 'multisite', array(
            'ajax_url' => admin_url('admin-ajax.php')
        ));
    }

    public function olc_new_user_role() {
        add_role(
            'site_subscriber',
            'Site Subscriber',
            array(
                "switch_themes" => false,
                "edit_themes"   => false,
                "activate_plugins"  => false,
                "edit_plugins"  => false,
                "edit_users"    => true,
                "edit_files"    => true,
                "manage_options"    => true,
                "moderate_comments" => true,
                "manage_categories" => true,
                "manage_links"  => true,
                "upload_files"  => true,
                "import"    => false,
                "unfiltered_html"   => true,
                "edit_posts"    => true,
                "edit_others_posts" => true,
                "edit_published_posts"  => true,
                "publish_posts" => true,
                "edit_pages"    => true,
                "read"  => true,
                "level_10"  => false,
                "level_9"   => false,
                "level_8"   => false,
                "level_7"   => false,
                "level_6"   => false,
                "level_5"   => true,
                "level_4"   => true,
                "level_3"   => true,
                "level_2"   => true,
                "level_1"   => true,
                "level_0"   => true,
                "edit_others_pages" => true,
                "edit_published_pages"  => true,
                "publish_pages" => false,
                "delete_pages"  => false,
                "delete_others_pages"   => false,
                "delete_published_pages"    => false,
                "delete_posts"  => true,
                "delete_others_posts"   => true,
                "delete_published_posts"    => true,
                "delete_private_posts"  => false,
                "edit_private_posts"    => false,
                "read_private_posts"    => false,
                "delete_private_pages"  => false,
                "edit_private_pages"    => false,
                "read_private_pages"    => false,
                "delete_users"  => true,
                "create_users"  => true,
                "unfiltered_upload" => true,
                "edit_dashboard"    => false,
                "update_plugins"    => false,
                "delete_plugins"    => false,
                "install_plugins"   => false,
                "update_themes" => false,
                "install_themes"    => false,
                "update_core"   => false,
                "list_users"    => true,
                "remove_users"  => true,
                "promote_users" => true,
                "edit_theme_options"    => true,
                "delete_themes" => false,
                "export"    => false,

                // tutor
                "manage_tutor"  => true,
                "manage_tutor_instructor"   => true,
                "edit_tutor_course" => true,
                "read_tutor_course" => true,
                "delete_tutor_course"   => true,
                "delete_tutor_courses"  => true,
                "edit_tutor_courses"    => true,
                "edit_others_tutor_courses" => true,
                "read_private_tutor_courses"    => true,
                "edit_tutor_lesson" => true,
                "read_tutor_lesson" => true,
                "delete_tutor_lesson"   => true,
                "delete_tutor_lessons"  => true,
                "edit_tutor_lessons"    => true,
                "edit_others_tutor_lessons" => true,
                "read_private_tutor_lessons"    => true,
                "publish_tutor_lessons" => true,
                "edit_tutor_quiz"   => true,
                "read_tutor_quiz"   => true,
                "delete_tutor_quiz" => true,
                "delete_tutor_quizzes"  => true,
                "edit_tutor_quizzes"    => true,
                "edit_others_tutor_quizzes" => true,
                "read_private_tutor_quizzes"    => true,
                "publish_tutor_quizzes" => true,
                "edit_tutor_question"   => true,
                "read_tutor_question"   => true,
                "delete_tutor_question" => true,
                "delete_tutor_questions"    => true,
                "edit_tutor_questions"  => true,
                "edit_others_tutor_questions"   => true,
                "publish_tutor_questions"   => true,
                "read_private_tutor_questions"  => true,
                "publish_tutor_courses" => true,

                // woocommerce
                "manage_woocommerce"    => false,
                "view_woocommerce_reports"  => false,
                "edit_product"  => false,
                "read_product"  => false,
                "delete_product"    => false,
                "edit_products" => false,
                "edit_others_products"  => false,
                "publish_products"  => false,
                "read_private_products" => false,
                "delete_products"   => false,
                "delete_private_products"   => false,
                "delete_published_products" => false,
                "delete_others_products"    => false,
                "edit_private_products" => false,
                "edit_published_products"   => false,
                "manage_product_terms"  => false,
                "edit_product_terms"    => false,
                "delete_product_terms"  => false,
                "assign_product_terms"  => false,
                "edit_shop_order"   => false,
                "read_shop_order"   => false,
                "delete_shop_order" => false,
                "edit_shop_orders"  => false,
                "edit_others_shop_orders"   => false,
                "publish_shop_orders"   => false,
                "read_private_shop_orders"  => false,
                "delete_shop_orders"    => false,
                "delete_private_shop_orders"    => false,
                "delete_published_shop_orders"  => false,
                "delete_others_shop_orders" => false,
                "edit_private_shop_orders"  => false,
                "edit_published_shop_orders"    => false,
                "manage_shop_order_terms"   => false,
                "edit_shop_order_terms" => false,
                "delete_shop_order_terms"   => false,
                "assign_shop_order_terms"   => false,
                "edit_shop_coupon"  => false,
                "read_shop_coupon"  => false,
                "delete_shop_coupon"    => false,
                "edit_shop_coupons" => false,
                "edit_others_shop_coupons"  => false,
                "publish_shop_coupons"  => false,
                "read_private_shop_coupons" => false,
                "delete_shop_coupons"   => false,
                "delete_private_shop_coupons"   => false,
                "delete_published_shop_coupons" => false,
                "delete_others_shop_coupons"    => false,
                "edit_private_shop_coupons" => false,
                "edit_published_shop_coupons"   => false,
                "manage_shop_coupon_terms"  => false,
                "edit_shop_coupon_terms"    => false,
                "delete_shop_coupon_terms"  => false,
                "assign_shop_coupon_terms"  => false,
            ),
        );
    }

    public function skip_woocommerce_installation($skip_installation, $new_site, $network_id, $site_id) {
        return true;
    }

    public static function multisite_form(){
        ?>
        <form class="max-width-auto" id="olc_subscription" method="post">
            <p class="message" style="display:none;"></p>
            <div class="form-group">
                <input name="register_email" type="text"/>
                <label>Email address *</label>
                <span class="focus-border"></span>
            </div>
            <p class="comment-note mb--20">Your username will be the domain for your site.</p>
            <div class="form-group">
                <input name="register_user" type="text">
                <label>Username *</label>
                <span class="focus-border"></span>
            </div>

            <div class="form-group">
                <input name="register_password" type="password" id="password">
                <label>Password *</label>
                <span class="focus-border"></span>
            </div>

            <div class="form-group">
                <input name="register_conpassword" type="password">
                <label>Confirm Password *</label>
                <span class="focus-border"></span>
            </div>

            <div class="form-submit-group">
                <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                    <span class="icon-reverse-wrapper">
                        <span class="btn-text">Register</span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                    </span>
                </button>
            </div>
        </form>
        <?php
    }

    public function admin_ban_wpse_105863(){
        if( !current_user_can( 'activate_plugins' ) ){
            wp_redirect( site_url() );
            exit;
        }
    }


    public function create_site(){
        $username   = $_REQUEST['subscribe_username'];
        $useremail  = $_REQUEST['subscribe_useremail'];
        $userpass   = $_REQUEST['subscribe_userpass'];
        if(is_multisite()){
            // $user_id = wpmu_create_user(
            //     $username,
            //     $userpass,
            //     $useremail
            // );

            $user_id = wp_insert_user(array(
                'user_email'    => $useremail,
                'user_login'    => $username,
                'user_pass'     => $userpass,
                'show_admin_bar_front' => false,
                'role'          => 'site_subscriber',
            ));

            if( !is_wp_error($user_id) ){
                $domain = SUBDOMAIN_INSTALL? "{$username}.{$_SERVER['HTTP_HOST']}" :  "{$_SERVER['HTTP_HOST']}";
                $path	= SUBDOMAIN_INSTALL? "/" : "/wp/wp-lms/{$username}/";
                $title 	= "Hi {$username}";
                if(function_exists('wpmu_create_blog')){                       
                    // $new_site_id = wpmu_create_blog( $domain, $path, $title, $user_id , array( 'public' => 1 ) );
                    $new_site_id = wp_insert_site(array(
                        'domain'    => $domain,
                        'path'      => $path,
                        'title'     => $title,
                        'user_id'   => $user_id
                    ));
                    
                    if( !is_wp_error($new_site_id) ){
                        switch_to_blog($new_site_id);
                        update_user_meta($user_id, "wp_{$new_site_id}_capabilities", array(
                            'site_subscriber' => true
                        ));
                        $link = SUBDOMAIN_INSTALL? "https://{$domain}/wp-admin/" : "http://{$domain}/wp/wp-lms/{$username}/wp-admin/";
                        wp_send_json_success('Congratulations! your site has been created.<a href="'.$link.'">Visit your site</a>');
                    }else{
                        wp_send_json_error('Sorry! the site could not be created.');
                    }
                }
            }else{
                wp_send_json_error('Sorry! the user already exists.');
            }
        }
        wp_die();
    }


    public static function instance(){
        if(!self::$instance){
            self::$instance = new self();
        }

        return self::$instance;
    }
}

Multisite::instance();