<?php
/**
 * Payment Class
 */
class Payment{

    private static $instance = false;

    public function __construct(){
        add_action('wp_enqueue_scripts', array($this, 'enqueue_scripts'));
        add_action('wp_ajax_stripe_payment_actions', array($this, 'stripe_payment_actions'));
        add_action('wp_ajax_nopriv_stripe_payment_actions', array($this, 'stripe_payment_actions'));
    }

    public function stripe_payment_actions(){
        $method = $_REQUEST['method'];
        if( $method == 'payment_intent' ){
           \Stripe\Stripe::setApiKey("sk_test_51MqkQXDvXhXIFQMYPxzvc4KPJExuHxnoVtVwQVMtcGPGJm2yETOe85gbRF8sYcnVJXQDX4vM83yD0YO7txjZSB3m00aDkAMQoM");
           try {
                // Create a PaymentIntent with amount and currency
                $paymentIntent = \Stripe\PaymentIntent::create([
                    'amount' => 1800,
                    'currency' => 'gbp',
                    'payment_method_types' => ['card', 'paypal'],
                    'metadata' => ['order_id' => '#6735'],
                    'statement_descriptor' => 'Event enrollment',
                ]);
            
                $output = array(
                    'paymentIntent' => $paymentIntent->id, 
                    'clientSecret'  => $paymentIntent->client_secret,
                );
            
                wp_send_json(json_encode($output));
            } catch (Error $e) {
                http_response_code(500);
                wp_send_json(json_encode(['error' => $e->getMessage()]));
            }
        }
    }

    public function enqueue_scripts(){
        wp_enqueue_script('stripe', '//js.stripe.com/v3/', array(), '1.0.0', false);
        wp_enqueue_script('checkout', OLX_URL.'payment/stripe/js/checkout.js', array('stripe'), '1.0.0', true);
        wp_localize_script('checkout', 'stripe_payment', array(
            'return_url'        => home_url('/olc-checkout/'),
            'admin_ajax_url'    => admin_url('admin-ajax.php'),
            'stripe_nonce'      => wp_create_nonce('stripe')
        ));
    }

    public static function checkout_form(){
        ?>
        <!-- Display a payment form -->
        <form id="payment-form">
            <div id="link-authentication-element">
            <!--Stripe.js injects the Link Authentication Element-->
            </div>
            <div id="payment-element">
            <!--Stripe.js injects the Payment Element-->
            </div>
            <button id="submit">
            <div class="spinner hidden" id="spinner"></div>
            <span id="button-text">Pay now</span>
            </button>
            <div id="payment-message" class="hidden"></div>
        </form>
        <?php
    }

    public static function instance(){
        if(!self::$instance){
            self::$instance = new self();
        }

        return self::$instance;
    }
}