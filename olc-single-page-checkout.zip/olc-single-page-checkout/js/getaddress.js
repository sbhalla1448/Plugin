getAddress.autocomplete("olc_checkout_autocomplete_field",olc_checkout.getaddress_api_key, {
   output_fields:{
      line_1:'student_address1',  /* The id of the element bound to 'line_1' */
      line_2:'student_address2',  /* The id of the element bound to 'line_2' */
      town_or_city:'student_city',  /* The id of the element bound to 'town_or_city' */
      postcode:'student_postcode',  /* The id of the element bound to 'postcode' */
  }
});
document.addEventListener("getaddress-autocomplete-address-selected", function(e){
   console.log(e.address);
   let address_data = e.address.country
   jQuery('#olc_checkout_address_lookup').hide()
   jQuery('.olc_checkout_student_address').show()
   
})
getAddress.autocomplete("olc_checkout_autocomplete_parent_field",olc_checkout.getaddress_api_key, {
   output_fields:{
      line_1:'billing_address1',  /* The id of the element bound to 'line_1' */
      line_2:'billing_address2',  /* The id of the element bound to 'line_2' */
      town_or_city:'billing_city',  /* The id of the element bound to 'town_or_city' */
      postcode:'billing_postcode',  /* The id of the element bound to 'postcode' */
  }
});
document.addEventListener("getaddress-autocomplete-address-selected", function(e){
   console.log(e.address);
   let address_data = e.address.country
   jQuery('#olc_checkout_parent_address_lookup').hide()
   jQuery('#olc_checkout_parent_billing_address').show()
})