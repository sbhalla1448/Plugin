<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Event_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'event';
	}

	/**
	 * Get widget event.
	 *
	 * Retrieve button widget event.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget event.
	 */
	public function get_title() {
		return esc_html__( 'Event', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 5, '', 'style_1');
        $this->text_control('_section_title', 'Section Title', 'Upcoming Events', array());
        $this->text_control('_section_subtitle', 'Section Sub Title', 'STIMULATED TO TAKE PART IN?', array());
        $this->repeater_controls('event_list', 'Event List', array(
            array(
                'name'  => 'event_post',
                'label' => 'Select a event',
                'type'  => \Elementor\Controls_Manager::SELECT2,
                'multiple'  => false,
                'options'   => $this->get_event_posts()
            )
        ), array());

        $this->end_controls_section();
    }


    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->typography_control('_section_title_typo', 'Section title typography', '.rbt-event-area .section-title .title');
        $this->color_control('_section_title_color', 'Section title color', '.rbt-event-area .section-title .title');

        $this->typography_control('_section_subtitle_typo', 'Section subtitle typography', '.rbt-event-area .section-title .subtitle');
        $this->color_control('_section_subtitle_color', 'Section subtitle color', '.rbt-event-area .section-title .subtitle');
        $this->background_control('_section_subtite_background', 'Section Subtitle Background', '.rbt-event-area .section-title .subtitle');


        $this->end_controls_section();
        
    }

    protected function get_event_posts(){
        $event_post = new \WP_Query(array(
            'post_type'         => 'olc_events',
            'post_status'       => 'publish',
            'posts_per_page'    => -1
        ));
        $event = array(-1 => 'None');
        if( $event_post->have_posts() ){
            while( $event_post->have_posts() ){
                $event_post->the_post();
                $event[get_the_ID()] = get_the_title();
            }
            wp_reset_query();
        }

        return $event;
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <script>
            jQuery(document).ready(function(){
                var swiper = new Swiper('.event-activation-1', {
                    slidesPerView: 1,
                    slidesPerGroup: 1,
                    loop: true,
                    spaceBetween: 30,
                    navigation: {
                        nextEl: '.rbt-arrow-left',
                        prevEl: '.rbt-arrow-right',
                        clickable: true,
                    },
                    scrollbar: {
                        el: '.swiper-scrollbar',
                            draggable: true,
                            hide: true,
                            snapOnRelease: true
                    },
                    pagination: {
                        el: '.rbt-swiper-pagination',
                        clickable: true,
                    },
                    breakpoints: {
                        575: {
                        slidesPerView: 1,
                        },

                        768: {
                        slidesPerView: 2,
                        },

                        992: {
                        slidesPerView: 3,
                        },
                        1200: {
                        slidesPerView: 4,
                        slidesPerGroup: 4,
                        },
                    },
                });
            })
        </script>
        <!-- Start Event Area  -->
        <div class="rbt-event-area">
            <div class="container">
                <div class="row mb--55">
                    <div class="section-title text-center">
                        <span class="subtitle"><?php echo esc_html($settings['_section_subtitle']); ?></span>
                        <h2 class="title"><?php echo esc_html($settings['_section_title']); ?></h2>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper event-activation-1 rbt-arrow-between rbt-dot-bottom-center pb--60 icon-bg-primary">

                            <div class="swiper-wrapper">
                                <?php
                                    if(!empty($settings['_event_list'])):
                                    foreach($settings['_event_list'] as $item ):
                                    $event_post = new \WP_Query(array(
                                        'post_type' => 'olc_events',
                                        'post_status'   => 'publish',
                                        'posts_per_page'    => 1,
                                        'post__in'          => array($item['event_post'])
                                    ));

                                    if($event_post->have_posts()):
                                    while($event_post->have_posts()): $event_post->the_post();
                                    $event_start_date   = function_exists('get_field')? get_field('start_date_time') : get_the_date();
                                    $event_end_date   = function_exists('get_field')? get_field('end_date_time') : get_the_date();
                                    $event_location     = function_exists('get_field')? get_field('location') : get_the_date();
                                    $event_date = date("D M", strtotime($event_start_date));
                                    $event_year = date("Y", strtotime($event_start_date));
                                ?>
                                <!-- Start Single Slide  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-card event-grid-card variation-01 rbt-hover">
                                            <div class="rbt-card-img">
                                                <a href="<?php the_permalink(); ?>">
                                                    <?php the_post_thumbnail(); ?>
                                                    <div class="rbt-badge-3 bg-white">
                                                        <span><?php echo esc_html($event_date); ?></span>
                                                        <span><?php echo esc_html($event_year); ?></span>
                                                    </div>
                                                </a>
                                            </div>
                                            <div class="rbt-card-body">
                                                <ul class="rbt-meta">
                                                    <li><i class="feather-map-pin"></i><?php echo esc_html($event_location); ?></li>
                                                    <li><i class="feather-clock"></i><?php echo date("h:m a", strtotime($event_start_date))." - ".date("h:m a", strtotime($event_end_date)); ?></li>
                                                </ul>
                                                <h4 class="rbt-card-title"><a href="<?php the_permalink(); ?>"><?php echo esc_html(get_the_title()); ?></a></h4>

                                                <div class="read-more-btn">
                                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="<?php the_permalink(); ?>">
                                                        <span class="icon-reverse-wrapper">
                                                        <span class="btn-text">Get Ticket</span>
                                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                                        </span>
                                                    </a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Slide  -->
                                <?php endwhile; endif; wp_reset_query(); ?>
                                <?php endforeach; endif; ?>
                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-left">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-left"></i>
                                    <i class="rbt-icon-top feather-arrow-left"></i>
                                </div>
                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-right">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-right"></i>
                                    <i class="rbt-icon-top feather-arrow-right"></i>
                                </div>
                            </div>

                            <div class="rbt-swiper-pagination"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Event Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Event Area  -->
        <div class="rbt-event-area bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row g-5 align-items-end mb--60">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="section-title text-start">
                            <h2 class="title">Our Events</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="load-more-btn text-start text-lg-end">
                            <a class="rbt-btn-link" href="#">University Upcoming Events<i
                                    class="feather-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-calendar"></i>11 Jan, 2023</li>
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">International Education Fair 2022</a></h4>
                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Vancouver</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Painting Art Contest 2020</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-03.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Paris</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Histudy Education Fair 2022</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-04.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html"> Elegant Light Box Paper Cut Dioramas</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- End Event Area  -->
        <div class="rbt-events-area rbt-section-gap bg-color-white">
            <div class="container">
                <div class="row g-5 align-items-center mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">Our <span class="theme-gradient">Events</span></h2>
                            <p class="description mt--20">Are You Want to <strong>Change Your Life?</strong></p>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/gym-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">This Is Why Gym Is So Famous!</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/gym-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Vancouver</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Ten Useful Tips From Experts In Gym.</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/gym-03.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Paris</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Why Is Gym Considered Underrated?</a>
                                </h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/gym-04.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Ten Quick Tips For Gym.</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-events-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-primary-opacity">Our Events</span>
                            <h2 class="title">Histudy Events</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn btn-gradient hover-icon-reverse radius-round" href="#">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">VIEW ALL EVENTS</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-calendar"></i>11 Jan, 2023</li>
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">International Education Fair 2022</a></h4>
                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Vancouver</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Painting Art Contest 2020</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-03.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Paris</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Histudy Education Fair 2022</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-04.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html"> Elegant Light Box Paper Cut Dioramas</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <div class="rbt-event-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">OUR EVENTS</span>
                            <h2 class="title">University Upcoming Events</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-01.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-calendar"></i>11 Jan, 2023</li>
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">International Education Fair 2022</a></h4>
                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-02.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Vancouver</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Painting Art Contest 2020</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-03.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>Paris</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html">Histudy Education Fair 2022</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->

                    <!-- Start Single Event  -->
                    <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                        <div class="rbt-card card-list-2 event-list-card variation-01 rbt-hover">
                            <div class="rbt-card-img">
                                <a href="event-details.html">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/event/grid-type-04.jpg" alt="Card image">
                                </a>
                            </div>
                            <div class="rbt-card-body">
                                <ul class="rbt-meta">
                                    <li><i class="feather-map-pin"></i>IAC Building</li>
                                    <li><i class="feather-clock"></i>8:00 am - 5:00 pm</li>
                                </ul>
                                <h4 class="rbt-card-title"><a href="event-details.html"> Elegant Light Box Paper Cut Dioramas</a></h4>

                                <div class="read-more-btn">
                                    <a class="rbt-btn btn-border hover-icon-reverse btn-sm radius-round" href="event-details.html">
                                        <span class="icon-reverse-wrapper">
                                <span class="btn-text">Get Ticket</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Event  -->
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Event_Widget() );