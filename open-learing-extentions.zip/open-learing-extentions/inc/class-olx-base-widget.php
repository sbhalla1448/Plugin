<?php
/**
 * Base widget class for core and common functionalites
 */
namespace Elementor;

defined('ABSPATH') || die();

abstract class OLX_Wc_Base_Widget extends \Elementor\Widget_Base {

    /**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */

    public function get_name() {

	}

    /**
	 * Get widget title.
	 *
	 * Retrieve button widget title.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget title.
	 */

	public function get_title() {

	}

    /**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */

	public function get_icon() {

	}


    /**
	 * Get widget categories.
	 *
	 * Retrieve the list of categories the button widget belongs to.
	 *
	 * Used to determine where to display the widget in the editor.
	 *
	 * @since 2.0.0
	 * @access public
	 *
	 * @return array Widget categories.
	 */
	public function get_categories() {
        return ['open-learning-ex'];
    }

	public function get_keywords() {}


	/**
	 * Must implement this function for content tab controls
	 */
	protected function register_content_controls(){}


	 /**
	 * Must implement this function for style tab controls
	 */
	protected function register_style_controls(){}
}