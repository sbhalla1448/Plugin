<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Progressbar_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'progressbar';
	}

	/**
	 * Get widget progressbar.
	 *
	 * Retrieve button widget progressbar.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget progressbar.
	 */
	public function get_title() {
		return esc_html__( 'Progressbar', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <script>
            jQuery(document).ready(function($){
                $(window).on('load', function(){
                    /* Check the location of each desired element */
                    $('.radial-progress').each( function(i){
                        var bottom_of_object = $(this).offset().top + $(this).outerHeight();
                        var bottom_of_window = $(window).scrollTop() + $(window).height();
                        /* If the object is completely visible in the window, fade it in */
                        if( bottom_of_window > bottom_of_object ){
                            $('.radial-progress').easyPieChart({
                                lineWidth: 10,
                                scaleLength: 0,
                                rotate: 0,
                                trackColor: false,
                                lineCap: 'round',
                                size: 180,
                                onStep: function(from, to, percent) {
                                $(this.el).find('.percent').text(Math.round(percent));
                            }
                        });
                        }
                    }); 
                })
            })
        </script>
		<!-- Start progress style-large  -->
        <div class="rbt-progressbar-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row row--15 align-items-center mb--25">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">Why <span class="theme-gradient">Choose</span> Us?</h2>
                            <p class="description mt--20">Are You Want to <strong>Change Your Life?</strong></p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="row">

                            <!-- Start Single Progress Bar  -->
                            <div class="col-lg-3 col-md-6 col-sm-6 mt--30 col-12">
                                <div class="radial-progress-single">
                                    <div class="radial-progress" data-percent="80" data-bar-color="#2f57ef" data-track-color="#F6F6F6">
                                        <div class="circle-text">
                                            <span class="count">80</span>
                                        </div>
                                    </div>
                                    <div class="circle-info">
                                        <h4 class="title">GYM</h4>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Progress Bar  -->

                            <!-- Start Single Progress Bar  -->
                            <div class="col-lg-3 col-md-6 col-sm-6 mt--30 col-12">
                                <div class="radial-progress-single">
                                    <div class="radial-progress" data-percent="60" data-bar-color="#2f57ef" data-track-color="#F6F6F6">
                                        <div class="circle-text">
                                            <span class="count">60</span>
                                        </div>
                                    </div>
                                    <div class="circle-info">
                                        <h4 class="title">YOGA</h4>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Progress Bar  -->

                            <!-- Start Single Progress Bar  -->
                            <div class="col-lg-3 col-md-6 col-sm-6 mt--30 col-12">
                                <div class="radial-progress-single">
                                    <div class="radial-progress" data-percent="70" data-bar-color="#2f57ef" data-track-color="#F6F6F6">
                                        <div class="circle-text">
                                            <span class="count">70</span>
                                        </div>
                                    </div>
                                    <div class="circle-info">
                                        <h4 class="title">NUTRITION</h4>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Progress Bar  -->

                            <!-- Start Single Progress Bar  -->
                            <div class="col-lg-3 col-md-6 col-sm-6 mt--30 col-12">
                                <div class="radial-progress-single">
                                    <div class="radial-progress" data-percent="95" data-bar-color="#2f57ef" data-track-color="#F6F6F6">
                                        <div class="circle-text">
                                            <span class="count">95</span>
                                        </div>
                                    </div>
                                    <div class="circle-info">
                                        <h4 class="title">RUNNING</h4>
                                    </div>
                                </div>
                            </div>
                            <!-- End Single Progress Bar  -->

                        </div>
                    </div>
                </div>

            </div>
        </div>
        <!-- End progress style-large  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Progressbar_Widget() );