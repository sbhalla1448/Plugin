<?php
/**
 * Plugin Name: Open Learning Extentions
 * Plugin URI: https://openlearning.com/
 * Description: An extentions plugin for open learing theme
 * Author: Open Learning
 * Version: 1.0.0
 * Author URI: https://openlearing.com/
 * Requires at least: 5.3
 * Tested up to: 6.1
 * Text Domain: open-learning-ex
 * Domain Path: /languages/
 */

 /**
 * Currently plugin version.
 * Start at version 1.0.0 and use SemVer - https://semver.org
 * Rename this for your plugin and update it as you release new versions.
 */
define( 'OLX_VERSION', '1.0.0' );
define( 'OLX_PATH', plugin_dir_path( __FILE__ ) );
define( 'OLX_URL', plugins_url( '/', __FILE__ ) );

/**
 * The code that runs during plugin activation.
 * This action is documented in includes/class-pure-wc-shopbuild-activator.php
 */
if( !function_exists('activate_olx_plugin') ){
	function activate_olx_plugin() {
		
	}
}

/**
 * The code that runs during plugin deactivation.
 * This action is documented in includes/class-pure-wc-shopbuild-deactivator.php
 */
if( !function_exists('deactivate_olx_plugin') ){
	function deactivate_olx_plugin() {
		
	}	
}
register_activation_hook( __FILE__, 'activate_olx_plugin' );
register_deactivation_hook( __FILE__, 'deactivate_olx_plugin' );


function olx_plugins_loaded(){
	load_plugin_textdomain(
		'open-learning-ex',
		false,
		OLX_PATH . '/languages/'
	);
	// Register Custom Post Types
	new OLX_Custom_Post_Type(array(
		'name'=> __( 'Mega Menu', 'open-learning-ex' ),
		'plural_name'=> __( 'Mega Menus', 'open-learning-ex' ),
		'singular_name'=> __( 'Mega Menu', 'open-learning-ex' ),
		'slug'=> 'mega_menu'
	), 'mega_menu');
}
add_action( 'plugins_loaded', 'olx_plugins_loaded' );

function olx_load_wp_widgets(){
	require_once( OLX_PATH .'widgets/wp/popular-posts.php' );
	register_widget('OLX_Popular_Posts');

	require_once( OLX_PATH .'widgets/wp/recent-posts.php' );
	register_widget('OLX_Recent_Posts');
}
add_action( 'widgets_init', 'olx_load_wp_widgets' );

add_filter( 'auto_update_plugin', '__return_false' );
add_filter( 'auto_update_core', '__return_false' );

require( OLX_PATH . 'functions/functions.php' );
require( OLX_PATH . 'inc/class-olx-widgets-manager.php' );
require( OLX_PATH . 'inc/class-olx-custom-post-type.php' );
require( OLX_PATH . 'widgets/traits/elementor-widget-traits.php' );
require( OLX_PATH . 'payment/stripe/vendor/autoload.php' );
require( OLX_PATH . 'payment/class-olx-payment.php' );
require( OLX_PATH . 'multisite/class-olx-multisite.php' );













