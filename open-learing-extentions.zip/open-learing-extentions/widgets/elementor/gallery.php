<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Gallery_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'gallery';
	}

	/**
	 * Get widget gallery.
	 *
	 * Retrieve button widget gallery.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget gallery.
	 */
	public function get_title() {
		return esc_html__( 'Gallery', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 3, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <!-- Start Gallery Area  -->
        <div class="rbt-gallery-area">
            <div class="row g-0 parent-gallery-container">
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-01.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-01.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-02.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-02.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-03.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-03.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-04.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-04.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-05.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-05.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-06.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-06.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-07.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-07.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-08.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-08.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-09.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-09.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-10.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-10.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-11.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-11.jpg" alt="Gallery Images">
                    </div>
                </a>
                <a href="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-12.jpg" class="child-gallery-single col-lg-2 col-md-4 col-sm-6 col-6">
                    <div class="rbt-gallery">
                        <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/kindergarten-thumb-12.jpg" alt="Gallery Images">
                    </div>
                </a>
            </div>
        </div>
        <!-- End Gallery Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
         <!-- Start Program Area  -->
        <div class="rbt-program-area rbt-section-gapTop bg-color-white" id="program">
            <div class="container">
                <div class="row g-5 align-items-end mb--60">
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="section-title text-start">
                            <h2 class="title">Our Program</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 col-12">
                        <div class="load-more-btn text-start text-lg-end">
                            <a class="rbt-btn-link" href="#">Browse Histudy Program<i class="feather-arrow-right"></i></a>
                        </div>
                    </div>
                </div>
                <div class="row g-5">

                    <!-- Start Single Program  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-category-gallery">
                            <div class="thumbnail">
                                <a href="#">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-03.jpg" alt="Gallery Images">
                                    <div class="rbt-bg-overlay"></div>
                                </a>
                                <div class="hover-content">
                                    <h3 class="title"><a href="#">Vue-Js</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Program  -->

                    <!-- Start Single Program  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-category-gallery">
                            <div class="thumbnail">
                                <a href="#">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-01.jpg" alt="Gallery Images">
                                    <div class="rbt-bg-overlay"></div>
                                </a>
                                <div class="hover-content">
                                    <h3 class="title"><a href="#">React Js</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Program  -->

                    <!-- Start Single Program  -->
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12">
                        <div class="rbt-category-gallery">
                            <div class="thumbnail">
                                <a href="#">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-05.jpg" alt="Gallery Images">
                                    <div class="rbt-bg-overlay"></div>
                                </a>
                                <div class="hover-content">
                                    <h3 class="title"><a href="#">Javascript</a></h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Program  -->
                </div>
            </div>
        </div>
        <!-- End Program Area  -->
       
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="gallery-area bg_image bg_image--8 bg_image_fixed height-650"></div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Gallery_Widget() );