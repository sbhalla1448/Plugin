<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Team_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'team';
	}

	/**
	 * Get widget team.
	 *
	 * Retrieve button widget team.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget event.
	 */
	public function get_title() {
		return esc_html__( 'Team', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 4, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <div class="rbt-team-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">Our Teacher</span>
                            <h2 class="title">Whose Inspirations You</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">

                    <div class="col-lg-7">
                        <!-- Start Tab Content  -->
                        <div class="rbt-team-tab-content tab-content" id="myTabContent">
                            <div class="tab-pane fade active show" id="team-tab1" role="tabpanel" aria-labelledby="team-tab1-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-01.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">Mames Mary</h4>
                                            <span class="designation theme-gradient">English Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="team-tab2" role="tabpanel" aria-labelledby="team-tab2-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-02.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">Robert Song</h4>
                                            <span class="designation theme-gradient">Math Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>Education The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="team-tab3" role="tabpanel" aria-labelledby="team-tab3-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-03.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">William Susan</h4>
                                            <span class="designation theme-gradient">React Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>React The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="team-tab4" role="tabpanel" aria-labelledby="team-tab4-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-04.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">Soseph Sara</h4>
                                            <span class="designation theme-gradient">Web Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="team-tab5" role="tabpanel" aria-labelledby="team-tab5-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-05.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">Thomas Dal</h4>
                                            <span class="designation theme-gradient">Graphic Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="tab-pane fade" id="team-tab6" role="tabpanel" aria-labelledby="team-tab6-tab">
                                <div class="inner">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-06.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                    <div class="rbt-team-details">
                                        <div class="author-info">
                                            <h4 class="title">Christopher Lisa</h4>
                                            <span class="designation theme-gradient">English Teacher</span>
                                            <span class="team-form">
                                <i class="feather-map-pin"></i>
                                <span class="location">CO Miego, AD,USA</span>
                                            </span>
                                        </div>
                                        <p>Histudy The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested.</p>
                                        <ul class="social-icon social-default mt--20 justify-content-start">
                                            <li><a href="https://www.facebook.com/">
                                                    <i class="feather-facebook"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.twitter.com">
                                                    <i class="feather-twitter"></i>
                                                </a>
                                            </li>
                                            <li><a href="https://www.instagram.com/">
                                                    <i class="feather-instagram"></i>
                                                </a>
                                            </li>
                                        </ul>
                                        <ul class="rbt-information-list mt--25">
                                            <li>
                                                <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                            </li>
                                            <li>
                                                <a href="mailto:hello@example.com"><i class="feather-mail"></i>example@gmail.com</a>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>

                            <div class="top-circle-shape"></div>
                        </div>
                        <!-- End Tab Content  -->
                    </div>

                    <div class="col-lg-5">
                        <!-- Start Tab Nav  -->
                        <ul class="rbt-team-tab-thumb nav nav-tabs" id="myTab" role="tablist">
                            <li>
                                <a class="active" id="team-tab1-tab" data-bs-toggle="tab" data-bs-target="#team-tab1" role="tab" aria-controls="team-tab1" aria-selected="true">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-01.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="team-tab2-tab" data-bs-toggle="tab" data-bs-target="#team-tab2" role="tab" aria-controls="team-tab2" aria-selected="false">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-02.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="team-tab3-tab" data-bs-toggle="tab" data-bs-target="#team-tab3" role="tab" aria-controls="team-tab3" aria-selected="false">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-03.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>
                            <li>
                                <a id="team-tab4-tab" data-bs-toggle="tab" data-bs-target="#team-tab4" role="tab" aria-controls="team-tab4" aria-selected="false">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-04.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="team-tab5-tab" data-bs-toggle="tab" data-bs-target="#team-tab5" role="tab" aria-controls="team-tab5" aria-selected="false">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-05.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                            <li>
                                <a id="team-tab6-tab" data-bs-toggle="tab" data-bs-target="#team-tab6" role="tab" aria-controls="team-tab6" aria-selected="false">
                                    <div class="rbt-team-thumbnail">
                                        <div class="thumb">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-06.jpg" alt="Testimonial Images">
                                        </div>
                                    </div>
                                </a>
                            </li>

                        </ul>
                        <!-- End Tab Content  -->
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>

        <div class="rbt-team-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Instructor</span>
                            <h2 class="title">Meet Our Teacher.</h2>
                            <p class="description has-medium-font-size mt--20">There are many variations of passages of the
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row row--15 mt_dec--30">
                    <!-- Start Single Team  -->
                    <div class="col-lg-4 col-md-6 col-12 mt--30">
                        <div class="rbt-team team-style-default style-three rbt-hover">
                            <div class="inner">
                                <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-07.jpg" alt="Corporate Template"></div>
                                <div class="content">
                                    <h2 class="title">Alejandro</h2>
                                    <h6 class="subtitle theme-gradient">Math Teacher</h6>
                                    <span class="team-form">
                            <i class="feather-map-pin"></i>
                            <span class="location">CO Miego, AD,USA</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-4 col-md-6 col-12 mt--30">
                        <div class="rbt-team team-style-default style-three rbt-hover">
                            <div class="inner">
                                <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-08.jpg" alt="Corporate Template"></div>
                                <div class="content">
                                    <h2 class="title">John Due</h2>
                                    <h6 class="subtitle theme-gradient">Depertment Head</h6>
                                    <span class="team-form">
                            <i class="feather-map-pin"></i>
                            <span class="location">CO Miego, AD,USA</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-4 col-md-6 col-12 mt--30">
                        <div class="rbt-team team-style-default style-three rbt-hover">
                            <div class="inner">
                                <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-09.jpg" alt="Corporate Template"></div>
                                <div class="content">
                                    <h2 class="title">Joo Bieden</h2>
                                    <h6 class="subtitle theme-gradient">Math Teacher</h6>
                                    <span class="team-form">
                            <i class="feather-map-pin"></i>
                            <span class="location">CO Miego, AD,USA</span>
                                    </span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Team  -->
                </div>

                <div class="row">
                    <div class="col-lg-12">
                        <div class="load-more-btn mt--60 text-center">
                            <a class="rbt-btn rbt-marquee-btn" href="#">
                                <span data-text="View All Teacher">
                                    View All Teacher
                                </span>
                            </a>
                        </div>
                    </div>
                </div>

            </div>
        </div>

        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="rbt-team-area bg-gradient-8 rbt-section-gap">
            <div class="container">
                <div class="row mb--60 g-5 align-items-end">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-white-opacity">Our Instructor</span>
                            <h2 class="title color-white">Expert Instructor</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn hover-icon-reverse radius-round btn-white" href="#">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">BECAME A INSTRUCTOR</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row g-5">

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-05.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-09.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-03.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-07.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-01.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-02.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-04.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-06.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-08.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-2 col-md-3 col-sm-4 col-12">
                        <div class="rbt-team-modal-thumb nav nav-tabs">
                            <a class="rbt-team-thumbnail" href="javascript:void(0)" data-bs-toggle="modal" data-bs-target="#exampleModal">
                                <div class="thumb">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-10.jpg" alt="Testimonial Images">
                                </div>
                            </a>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                </div>

                <div class="modal fade rbt-modal-default" id="exampleModal" tabindex="-1" aria-labelledby="exampleModal" aria-hidden="true">
                    <div class="modal-dialog modal-dialog-centered">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="rbt-round-btn" data-bs-dismiss="modal" aria-label="Close">
                                    <i class="feather-x"></i>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="inner">
                                    <div class="row g-5 row--30 align-items-center">
                                        <div class="col-lg-4">
                                            <div class="rbt-team-thumbnail">
                                                <div class="thumb">
                                                    <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-09.jpg" alt="Testimonial Images">
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-lg-8">
                                            <div class="rbt-team-details">
                                                <div class="author-info">
                                                    <h4 class="title">Mames Mary</h4>
                                                    <span class="designation theme-gradient">English Teacher</span>
                                                    <span class="team-form">
                                            <i class="feather-map-pin"></i>
                                            <span class="location">CO Miego, AD,USA</span>
                                                    </span>
                                                </div>
                                                <p class="mb--15">You can run Histudy easily. Any School, University, College can be use this histudy education template for their educational purpose. A university can be success you.</p>

                                                <p>Run their online leaning management system by histudy education template any where and time.</p>
                                                <ul class="social-icon social-default mt--20 justify-content-start">
                                                    <li><a href="https://www.facebook.com/">
                                                            <i class="feather-facebook"></i>
                                                        </a>
                                                    </li>
                                                    <li><a href="https://www.twitter.com">
                                                            <i class="feather-twitter"></i>
                                                        </a>
                                                    </li>
                                                    <li><a href="https://www.instagram.com/">
                                                            <i class="feather-instagram"></i>
                                                        </a>
                                                    </li>
                                                    <li>
                                                        <a href="https://www.linkdin.com/">
                                                            <i class="feather-linkedin"></i>
                                                        </a>
                                                    </li>
                                                </ul>
                                                <ul class="rbt-information-list mt--25">
                                                    <li>
                                                        <a href="#"><i class="feather-phone"></i>+1-202-555-0174</a>
                                                    </li>
                                                    <li>
                                                        <a href="mailto:hello@example.com"><i
                                                    class="feather-mail"></i>example@gmail.com</a>
                                                    </li>
                                                </ul>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="top-circle-shape"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-team-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-pink-opacity">Our Instructor</span>
                            <h2 class="title">Word Class Best Instructor</h2>
                            <p class="description has-medium-font-size mt--20">There are many variations of passages of the
                                Ipsum available, but the majority have suffered alteration in some form, by injected humour.
                            </p>
                        </div>
                    </div>
                </div>
                <div class="row row--15 mt_dec--30">
                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="team">
                            <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-05.jpg" alt="Blog Images">
                            </div>
                            <div class="content">
                                <h4 class="title">Aaron Griffin</h4>
                                <p class="designation">Depertment Head</p>
                            </div>
                            <ul class="social-icon">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="team">
                            <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-09.jpg" alt="Blog Images">
                            </div>
                            <div class="content">
                                <h4 class="title">Rafiq Bali</h4>
                                <p class="designation">Depertment Head</p>
                            </div>
                            <ul class="social-icon">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="team">
                            <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-03.jpg" alt="Blog Images">
                            </div>
                            <div class="content">
                                <h4 class="title">Fatima Usa</h4>
                                <p class="designation">Depertment Head</p>
                            </div>
                            <ul class="social-icon">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                    <!-- Start Single Team  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 mt--30">
                        <div class="team">
                            <div class="thumbnail"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/team/team-07.jpg" alt="Blog Images">
                            </div>
                            <div class="content">
                                <h4 class="title">John Due</h4>
                                <p class="designation">Depertment Head</p>
                            </div>
                            <ul class="social-icon">
                                <li><a href="#"><i class="fab fa-facebook-f"></i></a></li>
                                <li><a href="#"><i class="fab fa-linkedin-in"></i></a></li>
                                <li><a href="#"><i class="fab fa-twitter"></i></a></li>
                            </ul>
                        </div>
                    </div>
                    <!-- End Single Team  -->

                </div>
            </div>
        </div>
        <?php
        endif;

	}
}

$widgets_manager->register( new OLX_Team_Widget() );