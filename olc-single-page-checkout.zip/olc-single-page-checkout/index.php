<?php
/**
 * 
 * Plugin Name: Open learning custom checkout
 * Author: Md. Sarwar-A-Kawsar
 * Text Domain: olc-checkout
 * 
 */
if( !defined('ABSPATH') ) {
    exit;
}
require __DIR__.'/vendor/autoload.php';
define('OLC_CHECKOUT_PATH',plugin_dir_path(__FILE__));
define('OLC_CHECKOUT_URL',plugin_dir_url(__FILE__));
// includes
include( OLC_CHECKOUT_PATH . 'core/admin_menu.php' );
include( OLC_CHECKOUT_PATH . 'core/ajax_handle.php' );
include( OLC_CHECKOUT_PATH . 'core/woocommerce.php' );
add_filter( 'template_include', 'olc_checkout_page_template', 99 );
function olc_checkout_page_template( $template ) {
    if ( is_page( 'checkout' ) ) {
        $new_template = OLC_CHECKOUT_PATH . '/custom-checkout.php';
        if ( '' != $new_template ) {
            return $new_template ;
        }
    }
    return $template;
}
add_action('wp_enqueue_scripts','olc_checkout_enqueue');
add_action('admin_enqueue_scripts','olc_checkout_enqueue');
function olc_checkout_enqueue(){
    wp_enqueue_style('olc_checkout_custom_style', OLC_CHECKOUT_URL . 'css/custom-style.css');
    wp_enqueue_style('olc_checkout_select2_css', OLC_CHECKOUT_URL . 'css/select2.min.css');
    wp_register_style('olc_checkout_jquery-ui_css', OLC_CHECKOUT_URL . 'cart/css/jquery-ui.css');
    wp_register_style('olc_checkout_font', 'https://fonts.googleapis.com/css?family=Open+Sans:400,400i,600,700,700i');
    wp_register_style('olc_checkout_style', OLC_CHECKOUT_URL . '/css/style.css',array(), mt_rand(1,1000).mt_rand(1,1000));
    // js
    wp_enqueue_script('jquery');
    wp_enqueue_script('olc_checkout_getaddress_autocomplete', 'https://cdn.getaddress.io/scripts/getaddress-autocomplete-1.0.24.min.js');
    wp_enqueue_script('olc_checkout_getaddress_script', OLC_CHECKOUT_URL . '/js/getaddress.js', array(), mt_rand(0,1000).mt_rand(0,1000), true);
    wp_enqueue_script('olc_checkout_select2', OLC_CHECKOUT_URL . '/js/select2.min.js', array(), mt_rand(0,1000).mt_rand(0,1000));
    wp_enqueue_script('olc_checkout_swal2', OLC_CHECKOUT_URL . '/js/swal2.js');
    wp_enqueue_script('olc_checkout_loader', OLC_CHECKOUT_URL . '/js/loader.js');
    wp_enqueue_script('olc_checkout_ui', OLC_CHECKOUT_URL . '/js/ui.js');
    wp_enqueue_script('olc_checkout_script', OLC_CHECKOUT_URL . '/js/script.js',array(), mt_rand(1,1000).mt_rand(1,1000));
    wp_localize_script('olc_checkout_script', 'olc_checkout', array(
        'ajax_url' => admin_url( 'admin-ajax.php' ),
        'checkout_url' => wc_get_checkout_url(),
        'logged_in_user' => is_user_logged_in(),
        'getaddress_api_key' => get_option( 'olc_checkout_get_address_api_key' )
    ));
}