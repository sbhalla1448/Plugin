<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Courses_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-courses';
	}

	/**
	 * Get widget courses.
	 *
	 * Retrieve button widget courses.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget courses.
	 */
	public function get_title() {
		return esc_html__( 'OLC Courses', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );
        $this->text_control('_section_title', 'Section Title', 'Our <span>Courses</span>', array());
        $this->number_control('_total_courses', 'Total Courses', 12, array());

        $this->repeater_controls('courses_tab_list', 'Tab List', array(
            array(
                'name'  => '_tab_title',
                'label' => esc_html__( 'Tab Title', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::TEXT,
                'default' => esc_html__('Your text...', 'open-learning-ex')
            ),
            array(
                'name'  => '_tab_count',
                'label' => esc_html__( 'Tab Title', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::NUMBER,
                'default' => 0
            ),
            array(
                'name'      => '_tab_courses',
                'label'     => esc_html__( 'Tab Courses', 'open-learning-ex' ),
                'type'      => \Elementor\Controls_Manager::SELECT2,
                'multiple'  => true,
                'options'   => $this->get_courses(),
            ),
        ));

        $this->end_controls_section();
    }

    protected function get_courses(){
        $_courses = get_posts(array(
            'post_type' => 'courses',
            'order'     => 'DESC'
        ));

        $courses_array = array();

        foreach($_courses as $course){
            $courses_array[$course->ID] = $course->post_title;
        }

        return $courses_array;
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Section Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);

        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
		?>
<div class="rbt-course-area rbt-section-gap">
    <div class="container">
        <?php 
            if(!empty($settings['_section_title'])):
        ?>
        <div class="row mb--60">
            <div class="col-lg-12">
                <div class="section-title text-center">
                    <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                </div>
            </div>
        </div>
        <?php 
        endif;
            $_tab_list = $settings['_courses_tab_list'];
        ?>
        <div class="row">
            <div class="col-lg-12">
                <ul class="rbt-portfolio-filter filter-tab-button text-center nav nav-tabs" id="rbt-myTab"
                    role="tablist">
                    <li class="nav-item" role="presentation">
                        <button class="active" id="all-tab" data-bs-toggle="tab" data-bs-target="#all" type="button"
                            role="tab" aria-controls="all" aria-selected="true"><span class="filter-text">All
                                Courses</span> <span class="course-number"><?php echo $settings['_total_courses'] > 9? esc_html($settings['_total_courses']) : '0'.$settings['_total_courses']; ?></span></button>
                    </li>
                    <?php foreach($_tab_list as $item): ?>
                    <li class="nav-item" role="presentation">
                        <button id="tab-<?php echo esc_attr($item['_id']); ?>-tab" data-bs-toggle="tab" data-bs-target="#tab-<?php echo esc_attr($item['_id']); ?>" type="button"
                            role="tab" aria-controls="tab-<?php echo esc_attr($item['_id']); ?>" aria-selected="true">
                            <span class="filter-text"><?php echo esc_html($item['_tab_title']); ?></span> 
                            <span class="course-number"><?php echo $item['_tab_count'] > 9? esc_html($item['_tab_count']) : '0'.$item['_tab_count']; ?></span>
                        </button>
                    </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>
        <!-- Start Card Area -->
        <div class="row">
            <div class="col-lg-12">
                <div class="tab-content mt--60" id="rbt-myTabContent">
                    <div class="tab-pane fade show active" id="all" role="tabpanel" aria-labelledby="all">
                        <div class="row g-5">
                            <?php
                                $_get_courses = olx_get_courses_by_filter('all', array(), esc_html($settings['_total_courses']));
                            ?>
                            <?php if($_get_courses->have_posts()): ?>
                            <?php while($_get_courses->have_posts()): $_get_courses->the_post(); ?>
                            <!-- Start Single Course  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <?php
                                    /**
                                     * Usage Idea, you may keep a loop within a wrap, such as bootstrap col
                                     *
                                     * @hook tutor_course/archive/before_loop_course
                                     * @type action
                                     */
                                    do_action( 'tutor_course/archive/before_loop_course' );

                                    tutor_load_template( 'loop.course' );

                                    /**
                                     * Usage Idea, If you start any div before course loop, you can end it here, such as </div>
                                     *
                                     * @hook tutor_course/archive/after_loop_course
                                     * @type action
                                     */
                                    do_action( 'tutor_course/archive/after_loop_course' );
                                ?>
                            </div>
                            <!-- End Single Course  -->
                            <?php endwhile; wp_reset_query(); ?>
                            <?php else: ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <p>No course found!</p>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php foreach($_tab_list as $item): 
                        $_tab_courses = $item['_tab_courses'];
                        if(!empty($_tab_courses)):
                    ?>
                    <div class="tab-pane fade" id="tab-<?php echo esc_attr($item['_id']); ?>" role="tabpanel" aria-labelledby="tab-<?php echo esc_attr($item['_id']); ?>">
                        <div class="row g-5">
                            <?php 
                            $_get_tab_courses = olx_get_courses_by_filter('all', $_tab_courses, esc_html($settings['_total_courses']));
                            if($_get_tab_courses->have_posts()): 
                            ?>
                            <?php while($_get_tab_courses->have_posts()): $_get_tab_courses->the_post(); ?>
                            <!-- Start Single Course  -->
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <?php
                                    do_action( 'tutor_course/archive/before_loop_course' );

                                    tutor_load_template( 'loop.course' );

                                    do_action( 'tutor_course/archive/after_loop_course' );
                                ?>
                            </div>
                            <!-- End Single Course  -->
                            <?php endwhile; wp_reset_query(); ?>
                            <?php else: ?>
                            <div class="col-xl-3 col-lg-4 col-md-6 col-sm-12 col-12">
                                <p>No course found!</p>
                            </div>
                            <?php endif;?>
                        </div>
                    </div>
                    <?php endif; ?>
                    <?php endforeach; ?>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
	}
}

$widgets_manager->register( new OLX_Courses_Widget() );
