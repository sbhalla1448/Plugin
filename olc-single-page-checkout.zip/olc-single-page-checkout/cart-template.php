<?php
$user_id = get_current_user_id();
$payment_option = WC()->session->get('olc_payment_option');
$study_pack_qty = 0;
$cart_items = WC()->cart->get_cart();
$upsell_products_added = [];
foreach( $cart_items as $cart_item_id => $item ) {
      $product_id = $item['product_id'];
      // echo '<pre>';
      // print_r($data);
      // echo '</pre>';
      $product = wc_get_product( $product_id );
      if( isset($item['upsell_product']) ) {
         $upsell_products_added[$cart_item_id] = $product_id;
      }
      if( isset( $item['upsell_product'] ) ) continue;
      if( !isset( $item['study_option'] ) ) continue;
      $study_type = $item['study_option'] == "study_online" ? "Online" : "Study Pack";
      if( $study_type == "Study Pack" ) {
         $study_pack_qty += 1;
      }
?>
<div class="cart-item row">
      <div class="col-8 cart-item__header">
         <div class="cart-item__title-container">
            <h3 class="cart-item__title"><?php echo $product->get_name(); ?></h3>
         </div>
         <p class="cart-item__study-method">Study method: <?php echo $study_type; ?></p>
         <!-- <form action="https://openlearningcollege.ac/remove" method="POST" class="remove-form"> -->
            <input type="hidden" name="item_price" value="<?php echo $product->get_price(); ?>" />
            <button type="button" class="remove-btn" data-cart-item-key="<?php echo $cart_item_id; ?>">Remove</button>
         <!-- </form> -->
      </div>
      <div class="col-4 cart-item__price">
         <span>
            <?php
            if( $payment_option == 'pay_monthly' ) {
                  echo wc_price( $product->get_regular_price() );
            } else {
                  echo wc_price( $product->get_price() );
            }
            ?>
         </span>
      </div>
</div>
<?php } ?>
<?php
$extra_products = get_option('olc_checkout_upsell_products_list');
if( $extra_products != "" ) { ?>
         <div class="cart-options">
            <h4 class="payment-options__heading">Additional options</h4>
            <!-- <div class="cart-options__item">
                  <label class="cart-options__label">
                     <input type="checkbox" name="addon[]" value="4" cost="29.99" class="addonrow  cart-options__input" addon-text="career kickstart package">
                     <div class="cart-options__title">
                        <strong>Add career kickstart package</strong>
                        <span class="u-regular">+29.99</span>
                     </div>
                     <div class="cart-options__desc">Get a video consultation with our career expert, plus a CV review, LinkedIn profile support and interview coaching and tips!</div>
                  </label>
            </div> -->
            <?php
            $extra_products = explode(',', $extra_products);
            foreach( $extra_products as $key => $extra_product_id ) {
                  $extra_product = wc_get_product( $extra_product_id );
                  if( !$extra_product->get_price() ) continue;
                  ?>
                  <div class="cart-options__item">
                     <label class="cart-options__label">
                        <input <?php echo in_array( $extra_product_id, $upsell_products_added ) ? 'checked' : ''; ?> type="checkbox" name="addon[]" value="<?php echo $extra_product->get_price(); ?>" cost="<?php echo $extra_product->get_price(); ?>" class="addonrow cart-options__input additiona_cart_item" addon-text="career kickstart package" data-extra-id="<?php echo $key; ?>" data-product-id="<?php echo $extra_product_id; ?>" data-cart-id="<?php echo array_search($extra_product_id, $upsell_products_added); ?>"/>
                        <div class="cart-options__title">
                              <strong><?php echo $extra_product->get_name(); ?></strong>
                              <span class="u-regular">+<?php echo wc_price( $extra_product->get_price() ); ?></span>
                        </div>
                        <div class="cart-options__desc"><?php echo $extra_product->get_short_description(); ?></div>
                     </label>
                  </div>
            <?php } ?>
         </div>
<?php } ?>
<div class="col-12 col-lg-12 discount-code__row">
      <button class="discount-code__open-btn" id="discount-code-btn">Have a discount
         code?</button>

      <p class="discount-code__note-text">Please note: We only publish discount codes online via
         official Open Learning College channels.</p>

      <div class="cart-detail cart-studymethod discount-code">
         <div class="form__controls discount-code__form">
            <label for="discount-code" class="sr-only">Discount code</label>
            <input type="text" name="discount-code" class="discount-code__input"
                  id="discount-code" placeholder="Enter your discount code"
                  oninput="let p=this.selectionStart;this.value=this.value.toUpperCase();this.setSelectionRange(p, p);">
            <button class="discount-code__apply-btn" id="add-discount-code"
                  value="Apply">Apply</button>
         </div>
         <p class="discount-code__confirmation discount-code-applied" style="display: none">
            Discount code applied</p>
      </div>
</div>
<div class="cart-details cart-addons"></div>
<?php
$additional_fee = 0;
foreach( WC()->cart->get_cart() as $item_id => $item ) { 
      $product_id = $item['product_id'];
      $product = wc_get_product( $product_id );
      if( !isset($item['upsell_product']) ) continue;
      $additional_fee += floatval($product->get_sale_price());
}
?>
<div class="cart-detail cart-price cart-delivery mt-3 row">
      <div class="col-6 cart__total">Subtotal</div>
      <div class="col-6 u-right-align">
         <span>
            <strong class="sub-total ml-2">
                  <?php 
                  $sub_total = floatval(WC()->cart->subtotal) - $additional_fee;
                  echo wc_price( $sub_total );
                  ?>
            </strong>
         </span>
      </div>
</div>
<?php
$unit_delivery_fee = get_option('olc_checkout_study_pack_delivery_fee') ?: '49.99';
$delivery_fee = $study_pack_qty * floatval($unit_delivery_fee);
if( $study_pack_qty > 0 ) {
?>
<div class="cart-detai
l cart-studymethod cart-delivery row">
      <div class="col-6"><?php echo get_option('olc_checkout_study_pack_stripe_product_name') ?: 'Study pack delivery fee'; ?></div>
      <div class="col-6 u-right-align">
         <span><strong id="delivery_price"><?php echo $delivery_fee == 0 ? 'Free' : wc_price( $delivery_fee ); ?></strong></span>
      </div>
</div>
<?php } ?>
<?php
foreach( WC()->cart->get_cart() as $item_id => $item ) { 
      $product_id = $item['product_id'];
      $product = wc_get_product( $product_id );
      if( !isset($item['upsell_product']) ) continue;
?>
      <div class="cart-detail cart-studymethod cart-delivery row">
         <div class="col-6"><?php echo $product->get_name(); ?></div>
         <div class="col-6 u-right-align">
            <span><strong id="delivery_price"><?php echo wc_price( $product->get_sale_price() ); ?></strong></span>
         </div>
      </div>
<?php
}
?>
<?php if( WC()->cart->get_discount_total() ) { ?>
<div class="cart-detail cart-price cart-delivery mt-3 row">
      <div class="col-6">Discount</div>
      <div class="col-6 u-right-align">
         <span>
            <strong class="sub-total ml-2">
                  <?php 
                  echo '-'.wc_price( WC()->cart->get_discount_total() );
                  ?>
            </strong>
         </span>
      </div>
</div>
<?php } ?>
<div class="cart-detail cart-studymethod cart-addons row"></div>
<div class="cart-detail cart-price row <?php echo $payment_option == 'pay_monthly' ? 'cart-delivery' : ''; ?>">
      <div class="col-6 cart__total">Total</div>
      <div class="col-6 u-right-align">
         <span>
            <strong class="current_total">
                  <?php
                  $the_grand_total = floatval(WC()->cart->total) + $delivery_fee;
                  echo wc_price( $the_grand_total ); 
                  ?>
            </strong>
         </span>
      </div>
</div>
<?php

if( $payment_option == 'pay_monthly' ) {
      $payment_slot = floatval(get_option('olc_checkout_instalment_qty') ?: 5);
      $sub_fee = floatval(get_option('olc_checkout_additional_fee') ?: 0);
?>
<div class="cart-detail cart-delivery cart-price row">
      <div class="col-6">Monthly Instalment x4</div>
      <div class="col-6 u-right-align">
         <span>
            <!-- <strong class="finance-on-checkout finance-deposit"></strong> -->
            <strong class="current_total">
                  <?php
                     $the_grand_total = floatval(WC()->cart->total);
                     $instalment_of_grand_total = ($the_grand_total / $payment_slot);
                     echo wc_price( $instalment_of_grand_total );
                  ?>
            </strong>
         </span>
      </div>
</div>
<div class="cart-detail cart-price row">
      <div class="col-6 cart__total">Initial Deposit</div>
      <div class="col-6 u-right-align">
         <span>
            <!-- <strong class="finance-on-checkout finance-deposit"></strong> -->
            <strong class="current_total">
                  <?php
                  $intial_deposit = $the_grand_total / $payment_slot + $delivery_fee;
                  echo wc_price( $intial_deposit );
                  ?>
            </strong>
         </span>
      </div>
</div>
<?php } ?>