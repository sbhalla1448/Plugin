<?php
/**
 * 
 * Elementor widgets manager class
 */

 class OLX_Widget_Manager {

    /** store all widgets map */
    private static $widgets_map;

    private static $widget_nonce = 'tp_save_widgets'; 


    /**
     * init the class
     */
    public function __construct(){
      add_action( 'elementor/widgets/register', array( $this, 'register_widgets') );
      add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );
      add_action( 'elementor/elements/categories_registered', array( $this, 'widget_categories' ) );
    }

    /**
     * Load scripts
     */

   public function enqueue_scripts(){
      // wp_enqueue_script( 'open-learning-ex-elementor', PURE_WC_SHOPBUILD_URL . 'admin/js/open-learning-ex-elementor.js', array( 'jquery' ), PURE_WC_SHOPBUILD_VERSION, true );
      // wp_localize_script( 'open-learning-ex-elementor', 'pure_wc_shopbuild_elementor', array(
      //    'ajax_url'  => admin_url( 'admin-ajax.php' ),
      //    'action'    => self::$widget_nonce,
      //    'nonce'     => wp_create_nonce( self::$widget_nonce )
      // ) );
   }

    /**
     * get all the widgets
     */
    public static function get_widgets(){
      return apply_filters('olx_elementor_addons_widgets_map', array());
    }

    /**
     * Map all the widgets here
     */
    public static function set_widgets( $widgets = array() ){
      self::$widgets_map = $widgets;
    }


    /**
     * Get widget option from DB
     */
    public static function get_inactive_widgets(){
      $widget_arr = get_option('tp_inactive_widgets')? get_option('tp_inactive_widgets') : self::merge_inactives_widgets();
      $all_widgets = self::get_widgets();

      foreach( $all_widgets as $key => $val ){
         if( in_array($key, $widget_arr) ){
            if( $val['is_active'] ){
               $find_key = array_search($key, $widget_arr);
               unset($widget_arr[$find_key]);
               
            }
         }else{
            if( !$val['is_active'] ){
               $widget_arr[] = $key;
            }
         }
      }
      
      return $widget_arr;
    }


    /**
     * Merge inactives widgets
     */

   public static function merge_inactives_widgets( $widgets = array() ){
      
      $default_inactive_widgets = self::get_widgets();
      array_walk( $default_inactive_widgets, function($widget, $name)  use ( &$widgets ) {
         if( $widget['is_active'] == false ){
            $widgets[] =  $name; 
         }
      });

      return $widgets;
   }

   /**
    * Register Elementor Categories
    */

   public function widget_categories( $elements_manager ) {

      $elements_manager->add_category(
         'open-learning-ex',
         [
            'title' => esc_html__( 'OLX Widgets', 'open-learning-ex' ),
            'icon' => 'fa fa-plug',
         ]
      );

   }


    /**
     * Register all widgets
     */
    public function register_widgets( $widgets_manager ){
      $all_widgets  = $this->get_widgets();
      if( !empty($all_widgets) ){
         require_once( OLX_PATH . 'inc/class-olx-base-widget.php' );
         
         $inactive_widgets = self::get_inactive_widgets();

         foreach( $all_widgets as $key => $val ){
            if( !in_array( $key, $inactive_widgets) ){
               if( file_exists(OLX_PATH . "widgets/elementor/{$key}.php") ){
                  require_once( OLX_PATH . "widgets/elementor/{$key}.php" );
               } 
            }
         }
      }
    }


}


new OLX_Widget_Manager();