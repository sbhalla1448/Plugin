<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Contact_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'contact';
	}

	/**
	 * Get widget contact.
	 *
	 * Retrieve button widget contact.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget contact.
	 */
	public function get_title() {
		return esc_html__( 'Contact', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 4, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <!-- Start Contact Me Area  -->
        <div class="rbt-contact-me bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title"><span class="theme-gradient">Contact</span> With Me</h2>
                            <p class="description has-medium-font-size mt--20">Learning new technology, data sience,
                                university, communicate to global world and build a bright future with our histudy.</p>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="thumbnail">
                            <img class="w-100 radius-10" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/contact-2.jpg" alt="Contact Images">
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="rbt-contact-form contact-form-style-1 max-width-auto">
                            <div class="section-title text-start">
                                <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                            </div>
                            <h3 class="title">Get a Free Course You Can Contact With Me</h3>
                            <form id="contact-form" class="w-100">
                                <div class="form-group">
                                    <input name="con_name" type="text" />
                                    <label>Name</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input name="con_email" type="email">
                                    <label>Email</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input type="text">
                                    <label>Phone</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <textarea></textarea>
                                    <label>Message</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-submit-group">
                                    <button type="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">GET IT NOW</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contact Me Area  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Contact Me Area  -->
        <div class="rbt-contact-me bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <div class="content">
                            <div class="section-title text-start">
                                <h2 class="title">Want to stay informed about new courses & histudy?</h2>
                                <p class="description mt--20">Histudy educational platform ipsum dolor sit amet consectetur adipisicing elit. Nam inventore praesentium alias incidunt! Veritatis.</p>
                                <div class="social-share-wrapper mt--30">
                                    <h5>You can also follow us on:</h5>
                                    <ul class="social-icon social-default transparent-with-border justify-content-start mt--30">
                                        <li><a href="https://www.facebook.com/">
                                                <i class="feather-facebook"></i>
                                            </a>
                                        </li>
                                        <li><a href="https://www.twitter.com">
                                                <i class="feather-twitter"></i>
                                            </a>
                                        </li>
                                        <li><a href="https://www.instagram.com/">
                                                <i class="feather-instagram"></i>
                                            </a>
                                        </li>
                                        <li><a href="https://www.linkdin.com/">
                                                <i class="feather-linkedin"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-5 offset-xl-1">
                        <div class="rbt-contact-form contact-form-style-1 max-width-auto">

                            <form id="contact-form" class="w-100">
                                <div class="form-group">
                                    <input name="con_name" type="text" />
                                    <label>Name</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input name="con_email" type="email">
                                    <label>Email</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input type="text">
                                    <label>Phone</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <textarea></textarea>
                                    <label>Message</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-submit-group">
                                    <button type="submit" class="rbt-btn radius-round btn-gradient hover-icon-reverse">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">GET IT NOW</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Contact Me Area  -->
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="rbt-conatct-area bg-gradient-11 rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center mb--60">
                            <span class="subtitle bg-secondary-opacity">Contact Us</span>
                            <h2 class="title">Histudy Course Contact <br> can join with us.</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12 sal-animate">
                        <div class="rbt-address">
                            <div class="icon">
                                <i class="feather-headphones"></i>
                            </div>
                            <div class="inner">
                                <h4 class="title">Contact Phone Number</h4>
                                <p><a href="tel:+444555666777">+444 555 666 777</a></p>
                                <p><a href="tel:+222222222333">+222 222 222 333</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12 sal-animate">
                        <div class="rbt-address">
                            <div class="icon">
                                <i class="feather-mail"></i>
                            </div>
                            <div class="inner">
                                <h4 class="title">Our Email Address</h4>
                                <p><a href="mailto:admin@gmail.com">admin@gmail.com</a></p>
                                <p><a href="mailto:example@gmail.com">example@gmail.com</a></p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-6 col-12 sal-animate">
                        <div class="rbt-address">
                            <div class="icon">
                                <i class="feather-map-pin"></i>
                            </div>
                            <div class="inner">
                                <h4 class="title">Our Location</h4>
                                <p>5678 Bangla Main Road, cities 580 <br> GBnagla, example 54786</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-contact-address">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="thumbnail">
                            <img class="w-100 radius-6" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/about/contact.jpg" alt="Contact Images">
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="rbt-contact-form contact-form-style-1 max-width-auto">
                            <div class="section-title text-start">
                                <span class="subtitle bg-primary-opacity">EDUCATION FOR EVERYONE</span>
                            </div>
                            <h3 class="title">Get a Free Course You Can Contact With Me</h3>
                            <form id="contact-form" method="POST" action="mail.php" class="rainbow-dynamic-form max-width-auto">
                                <div class="form-group">
                                    <input name="contact-name" id="contact-name" type="text">
                                    <label>Name</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input name="contact-phone" type="email">
                                    <label>Email</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <input type="text" id="subject" name="subject">
                                    <label>Your Subject</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-group">
                                    <textarea name="contact-message" id="contact-message"></textarea>
                                    <label>Message</label>
                                    <span class="focus-border"></span>
                                </div>
                                <div class="form-submit-group">
                                    <button name="submit" type="submit" id="submit" class="rbt-btn btn-md btn-gradient hover-icon-reverse w-100">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">GET IT NOW</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </button>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Contact_Widget() );