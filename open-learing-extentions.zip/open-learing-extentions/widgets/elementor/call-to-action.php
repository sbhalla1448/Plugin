<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_CallToAction_Widget extends OLX_Wc_Base_Widget {
    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'call-to-action';
	}

	/**
	 * Get widget call-to-action.
	 *
	 * Retrieve button widget call-to-action.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget call-to-action.
	 */
	public function get_title() {
		return esc_html__( 'Call To Action', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 9, '');

        $this->image_control('_image', null, array(
            '_style' => array( 'style_4', 'style_2', 'style_8' )
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
		<!-- Start Call To Action  -->
        <div class="rbt-callto-action-area mt_dec--half">
            <div class="container">
                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12 col-xl-5">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">New Collection</a>
                                        </div>
                                        <h4 class="title mb--15">Online Courses from Histudy</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                    </div>
                                </div>
                                <div class="col-lg-12 col-xl-7">
                                    <div class="video-popup-wrapper mt_lg--10 mt_md--20 mt_sm--20">
                                        <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-01.jpg" alt="Video Images">
                                        <a class="rbt-btn rounded-player-2 sm-size popup-video position-to-top with-animation" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                            <span class="play-icon"></span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="rbt-callto-action callto-action-default bg-color-white rbt-radius shadow-1">
                            <div class="row align-items-center">
                                <div class="col-lg-12">
                                    <div class="inner">
                                        <div class="rbt-category mb--20">
                                            <a href="#">Top Teacher</a>
                                        </div>
                                        <h4 class="title mb--10">Free Online Courses from Histudy School To Education</h4>
                                        <p class="mb--15">Top instructors from around the world</p>
                                        <div class="read-more-btn">
                                            <a class="rbt-btn rbt-switch-btn btn-gradient btn-sm" href="#">
                                                <span data-text="Join Now">Join Now</span>
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Call To Action  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Button Area  -->
        <div class="rbt-video-area bg-color-white rbt-section-gapTop" id="about">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <div class="video-popup-wrapper">
                            <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-06.jpg" alt="Video Images">
                            <a class="rbt-btn rounded-player popup-video position-to-top" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                <span><i class="feather-play"></i></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="inner pl--50 pl_lg--0 pl_md--0 pl_sm--0">
                            <div class="section-title text-start">
                                <h4 class="title">Build your Career Life.</h4>
                                <p class="description mt--30">Far far away, behind the word mountains, far from the
                                    countries Vokalia and Consonantia, there live the blind texts.</p>
                                <div class="rbt-feature-wrapper mt--40">
                                    <div class="rbt-feature feature-style-1 align-items-center">
                                        <div class="icon bg-pink-opacity">
                                            <i class="feather-heart"></i>
                                        </div>
                                        <div class="feature-content">
                                            <h6 class="feature-title">Flexible Classes</h6>
                                        </div>
                                    </div>

                                    <div class="rbt-feature feature-style-1 align-items-center">
                                        <div class="icon bg-primary-opacity">
                                            <i class="feather-book"></i>
                                        </div>
                                        <div class="feature-content">
                                            <h6 class="feature-title">Learn From Anywhere</h6>
                                        </div>
                                    </div>

                                    <div class="rbt-feature feature-style-1 align-items-center">
                                        <div class="icon bg-coral-opacity">
                                            <i class="feather-monitor"></i>
                                        </div>
                                        <div class="feature-content">
                                            <h6 class="feature-title">Experienced Teacher's service.</h6>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Button Area  -->
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- Start CallTo Action Area  -->
        <div class="rbt-call-to-action-area rbt-section-gap bg-color-secondary-alt">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="rbt-cta-6 text-center">
                            <div class="content">
                                <h1 class="title">Download our mobile app, <br /> start learning today</h1>
                                <p>Includes all Course && Features</p>
                                <div class="rbt-button-group justify-content-center">
                                    <a class="rbt-btn btn-gradient" href="#">Get Bundle</a>
                                    <a class="rbt-btn btn-border" href="#">See Features</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End CallTo Action Area  -->
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <!-- Start Call To Action  -->
        <div class="rbt-callto-action-area">
            <div class="rbt-callto-action rbt-cta-default style-4 variation-2 bg-gradient-6 mt--75">
                <div class="container">
                    <div class="row align-items-center content-wrapper row--30 mt_dec--30 position-relative">
                        <div class="col-lg-8 mt--30 offset-lg-3">
                            <div class="inner">
                                <div class="content text-left">
                                    <h2 class="title">Ready to start creating a Educational Website?</h2>
                                    <div class="call-to-btn text-start mt--30">
                                        <a class="rbt-btn btn-gradient hover-icon-reverse" href="#">
                                            <span class="icon-reverse-wrapper">
                                                <span class="btn-text">Purchase Histudy</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="thumbnail">
                            <img class="w-100" src="<?php echo esc_url($settings['_image']['url']); ?>" alt="Shape Images">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Call To Action  -->
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <!-- Start CallTo Action Area  -->
        <div class="rbt-call-to-action-area rbt-section-gap bg-gradient-6 rbt-call-to-action-5">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="rbt-cta-5">
                                <div class="content">
                                    <h1 class="title">Download our mobile app, start learning today</h1>
                                    <p>Includes all Course && Features</p>
                                    <div class="rbt-button-group justify-content-start">
                                        <a class="rbt-btn btn-gradient" href="#">Get Bundle</a>
                                        <a class="rbt-btn btn-border" href="#">See Features</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="shape-images">
                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/three-shape.png" alt="Shape Images">
            </div>
        </div>
        <!-- End CallTo Action Area  -->
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <!-- Start CallTo Action Area  -->
        <div class="rbt-call-to-action-area rbt-section-gap bg-gradient-8">
            <div class="rbt-callto-action rbt-cta-default style-6">
                <div class="container">
                    <div class="row g-5 align-items-center content-wrapper">
                        <div class="col-xxl-3 col-xl-3 col-lg-6">
                            <div class="inner">
                                <div class="content text-start">
                                    <h2 class="title color-white mb--0">Scholarship Programs</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-6">
                            <div class="inner-content text-start">
                                <p class="color-white">Apply for Admission in Post Graduate Diploma. Application Deadline: 26th September 2022 · Undergraduate & Graduate Admission: Fall 2022 Semester · 20% Waiver on ...
                                </p>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-xl-3 col-lg-6">
                            <div class="call-to-btn text-start text-xl-end">
                                <a class="rbt-btn btn-white hover-icon-reverse" href="#">
                                    <span class="icon-reverse-wrapper">
                                <span class="btn-text">Histudy Financial Aid</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End CallTo Action Area  -->
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
        <!-- Start Call To Action  -->
        <div class="rbt-callto-action-area rbt-section-gapTop">
            <div class="rbt-callto-action rbt-cta-default style-4 bg-gradient-6 mt--75">
                <div class="container">
                    <div class="row align-items-center content-wrapper row--30 mt_dec--30 position-relative">
                        <div class="col-lg-8 mt--30 offset-lg-3">
                            <div class="inner">
                                <div class="content text-left">
                                    <h2 class="title">Ready to start creating a Educational Website?</h2>
                                    <div class="call-to-btn text-start mt--30">
                                        <a class="rbt-btn btn-gradient hover-icon-reverse radius-round" href="#">
                                            <span class="icon-reverse-wrapper">
                                        <span class="btn-text">Purchase Histudy</span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                            </span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="thumbnail">
                            <img class="w-100" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/shape/cta.png" alt="Shape Images">
                        </div>
                    </div>
                </div>
            </div>

        </div>
        <!-- End Call To Action  -->
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <!-- Start Video Area  -->
        <div class="rbt-video-area bg-color-white rbt-section-gap" id="career">
            <div class="container">
                <div class="row g-5 align-items-center">
                    <div class="col-lg-6">
                        <div class="video-popup-wrapper">
                            <img class="w-100 rbt-radius" src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/others/video-05.jpg" alt="Video Images">
                            <a class="rbt-btn rounded-player popup-video position-to-top" href="https://www.youtube.com/watch?v=nA1Aqp0sPQo">
                                <span><i class="feather-play"></i></span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="inner pl--50 pl_lg--0 pl_md--0 pl_sm--0">
                            <div class="section-title text-start">
                                <h4 class="title">Build your Career Life.</h4>
                                <p class="description mt--30 mt_md--15 mt_sm--15 mb_md--15 mb_sm--15">Far far away, behind the word mountains, far from the
                                    countries Vokalia and Consonantia, there live the blind texts.</p>
                                <p class="mb_md--15 mb_sm--15">Convenient practice dolor sit adipisicing elit. Minima error reiciendis. far from the
                                    countries Vokalia and Consonantia, there live the blind texts far from the
                                    countries Vokalia and Consonantia.</p>
                                <div class="view-all-button">
                                    <a class="rbt-btn btn-border hover-icon-reverse" href="#">
                                        <span class="icon-reverse-wrapper">
                                            <span class="btn-text">View All Courses</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Video Area  -->
        <?php elseif( $settings['_style'] == 'style_9' ): ?>
        <!-- Start CallTo Action Area  -->
        <div class="rbt-call-to-action-area rbt-section-gap bg-gradient-8">
            <div class="rbt-callto-action rbt-cta-default style-6">
                <div class="container">
                    <div class="row g-5 align-items-center content-wrapper">
                        <div class="col-xxl-3 col-xl-3 col-lg-6">
                            <div class="inner">
                                <div class="content text-start">
                                    <h2 class="title color-white mb--0">Scholarship Programs</h2>
                                </div>
                            </div>
                        </div>
                        <div class="col-xxl-6 col-xl-6 col-lg-6">
                            <div class="inner-content text-start">
                                <p class="color-white">Apply for Admission in Post Graduate Diploma. Application Deadline: 26th September 2022 · Undergraduate & Graduate Admission: Fall 2022 Semester · 20% Waiver on ...
                                </p>
                            </div>
                        </div>
                        <div class="col-xxl-3 col-xl-3 col-lg-6">
                            <div class="call-to-btn text-start text-xl-end">
                                <a class="rbt-btn btn-white hover-icon-reverse" href="#">
                                    <span class="icon-reverse-wrapper">
                                <span class="btn-text">Histudy Financial Aid</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End CallTo Action Area  -->
		<?php

        endif;
	}
}

$widgets_manager->register( new OLX_CallToAction_Widget() );