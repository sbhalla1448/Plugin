<?php
/**
 * 
 * This file is for developer for extending the plugin features
 */

/**
 * Map all the widgets to be registered
 */
function olx_elementor_addons_set_widgets(){
    return array(
        'faculties' => array(
            'title'     => __('Faculties', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'courses' => array(
            'title'     => __('Courses', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'mega-menu' => array(
            'title'     => __('Mega Menu', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'events' => array(
            'title'     => __('Events', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'teams' => array(
            'title'     => __('Teams', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'testimonials' => array(
            'title'     => __('Testimonials', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        ),
        'category' => array(
            'title'     => __('Categories', 'open-learning-ex'),
            'icon'      => 'eicon-button',
            'preview'   => 'https://preview',
            'is_pro'    => false,
            'is_active' => true,
        )
    );
}
add_filter('olx_elementor_addons_widgets_map', 'olx_elementor_addons_set_widgets');

/**
* Woocommerce Product last product id return
*/
function olx_wc_get_last_product_id(){
    global $wpdb;
    
    // Getting last Product ID (max value)
    $results = $wpdb->get_col( "
        SELECT MAX(ID) FROM {$wpdb->prefix}posts
        WHERE post_type LIKE 'product'
        AND post_status = 'publish'" 
    );
    return reset($results);
}

/*
 * HTML Tag Validation
 * return strig
 */
function olx_wc_validate_html_tag( $tag ) {
    $allowed_html_tags = [
        'article',
        'aside',
        'footer',
        'header',
        'section',
        'nav',
        'main',
        'div',
        'h1',
        'h2',
        'h3',
        'h4',
        'h5',
        'h6',
        'p',
        'span',
    ];
    return in_array( strtolower( $tag ), $allowed_html_tags ) ? $tag : 'div';
}


/**
 * Course Functions
 */
if(!function_exists('olx_get_courses_by_filter')){
    function olx_get_courses_by_filter( $filter = 'all', $post_in = array(), $limit = -1 ){
        $course_loop = new WP_Query(array(
            'post_type'     => 'courses',
            'post_status'   => 'publish',
            'posts_per_page'    => $limit,
            'post__in'          => $post_in
        ));

        return $course_loop;
    }
}

/**
 * Events Functions
 */
if(!function_exists('olx_get_events_by_filter')){
    function olx_get_events_by_filter( $filter = 'all', $post_in = array(), $limit = -1 ){
        $event_loop = new WP_Query(array(
            'post_type'     => 'olc_events',
            'post_status'   => 'publish',
            'posts_per_page'    => $limit,
            'post__in'          => $post_in
        ));

        return $event_loop;
    }
}


/**
 * Custom Header & Footer Styles
 */
if( function_exists('acf_add_local_field_group') ):

    acf_add_local_field_group(array(
        'key' => 'olc_header_footer',
        'title' => 'Header & Footer',
        'fields' => array(
            array(
                'key' => 'olc_header_footer',
                'label' => 'Header Style',
                'name' => 'header_style',
                'type' => 'select',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'choices' => array(
                    'header-style-1' => 'Header 1',
                    'header-style-2' => 'Header 2',
                ),
                'default_value' => 'header-style-2',
                'return_format' => 'value',
                'multiple' => 0,
                'allow_null' => 0,
                'ui' => 0,
                'ajax' => 0,
                'placeholder' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'page',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'side',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 1,
    ));
    
endif;

/**
 * Custom Mega Menu
 */
if( function_exists('acf_add_local_field_group') ):

    acf_add_local_field_group(array(
        'key' => 'mega_menu',
        'title' => 'Menu',
        'fields' => array(
            array(
                'key' => 'mega_menu',
                'label' => 'Mega Menu',
                'name' => 'mega_menu',
                'type' => 'post_object',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'post_type' => array(
                    0 => 'mega_menu',
                ),
                'taxonomy' => '',
                'return_format' => 'object',
                'multiple' => 0,
                'allow_null' => 0,
                'ui' => 1,
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'nav_menu_item',
                    'operator' => '==',
                    'value' => 'location/main_menu',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ));
    
endif;


/**
 * OLC Events Meta
 */
if( function_exists('acf_add_local_field_group') ):

    acf_add_local_field_group(array(
        'key' => 'group_646cecb233ffe',
        'title' => 'Events Meta',
        'fields' => array(
            array(
                'key' => 'field_646cf18728574',
                'label' => 'Type',
                'name' => 'type',
                'type' => 'radio',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'choices' => array(
                    'free' => 'Free',
                    'paid' => 'Paid',
                ),
                'default_value' => '',
                'return_format' => 'array',
                'allow_null' => 0,
                'other_choice' => 0,
                'save_other_choice' => 0,
                'layout' => 'vertical',
            ),
            array(
                'key' => 'field_646cf1e128575',
                'label' => 'Price',
                'name' => 'price',
                'type' => 'number',
                'instructions' => '',
                'required' => 1,
                'conditional_logic' => array(
                    array(
                        array(
                            'field' => 'field_646cf18728574',
                            'operator' => '==',
                            'value' => 'paid',
                        ),
                    ),
                ),
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => 10,
                'min' => 5,
                'max' => 1000,
                'placeholder' => '',
                'step' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_646cecb276496',
                'label' => 'Start Date Time',
                'name' => 'start_date_time',
                'type' => 'date_time_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'display_format' => 'F j, Y g:i a',
                'return_format' => 'F j, Y g:i a',
                'first_day' => 1,
            ),
            array(
                'key' => 'field_646ced3838e4a',
                'label' => 'End Date Time',
                'name' => 'end_date_time',
                'type' => 'date_time_picker',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'display_format' => 'F j, Y g:i a',
                'return_format' => 'F j, Y g:i a',
                'first_day' => 1,
            ),
            array(
                'key' => 'field_646ced5f38e4b',
                'label' => 'Location',
                'name' => 'location',
                'type' => 'text',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '',
                'maxlength' => '',
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_646ced9238e4c',
                'label' => 'Language',
                'name' => 'language',
                'type' => 'text',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => 'English, Arabic',
                'maxlength' => '',
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_646cedff38e4d',
                'label' => 'FAQs',
                'name' => 'faqs',
                'type' => 'repeater',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'layout' => 'row',
                'pagination' => 1,
                'rows_per_page' => 10,
                'min' => 0,
                'max' => 0,
                'collapsed' => '',
                'button_label' => 'Add Row',
                'sub_fields' => array(
                    array(
                        'key' => 'field_646cee2438e4e',
                        'label' => 'Question',
                        'name' => 'question',
                        'type' => 'text',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'maxlength' => '',
                        'placeholder' => '',
                        'prepend' => '',
                        'append' => '',
                        'parent_repeater' => 'field_646cedff38e4d',
                    ),
                    array(
                        'key' => 'field_646cee3f38e4f',
                        'label' => 'answer',
                        'name' => 'answer',
                        'type' => 'wysiwyg',
                        'instructions' => '',
                        'required' => 0,
                        'conditional_logic' => 0,
                        'wrapper' => array(
                            'width' => '',
                            'class' => '',
                            'id' => '',
                        ),
                        'default_value' => '',
                        'delay' => 0,
                        'tabs' => 'all',
                        'toolbar' => 'full',
                        'media_upload' => 1,
                        'parent_repeater' => 'field_646cedff38e4d',
                    ),
                ),
            ),
            array(
                'key' => 'field_646cee8938e50',
                'label' => 'Instructors',
                'name' => 'instructors',
                'type' => 'user',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'role' => array(
                    0 => 'tutor_instructor',
                ),
                'return_format' => 'array',
                'multiple' => 1,
                'allow_null' => 0,
            ),
            array(
                'key' => 'field_646cef7c38e51',
                'label' => 'Contact No',
                'name' => 'contact_no',
                'type' => 'text',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => '+444 555 666 777',
                'maxlength' => '',
                'placeholder' => '',
                'prepend' => '',
                'append' => '',
            ),
            array(
                'key' => 'field_649ace558b73c',
                'label' => 'Promo Video URL',
                'name' => 'promo_video_url',
                'type' => 'url',
                'instructions' => '',
                'required' => 0,
                'conditional_logic' => 0,
                'wrapper' => array(
                    'width' => '',
                    'class' => '',
                    'id' => '',
                ),
                'default_value' => 'https://www.youtube.com/watch?v=B6vSq4KiZeM',
                'placeholder' => '',
            ),
        ),
        'location' => array(
            array(
                array(
                    'param' => 'post_type',
                    'operator' => '==',
                    'value' => 'olc_events',
                ),
            ),
        ),
        'menu_order' => 0,
        'position' => 'normal',
        'style' => 'default',
        'label_placement' => 'top',
        'instruction_placement' => 'label',
        'hide_on_screen' => '',
        'active' => true,
        'description' => '',
        'show_in_rest' => 0,
    ));
endif;	


function register_olc_events() {

    $labels = array(
        'name'                  => 'OLC Events',
        'singular_name'         => 'OLC Event',
        'menu_name'             => 'OLC Events',
        'name_admin_bar'        => 'OLC Event',
        'archives'              => 'eventArchives',
        'attributes'            => 'Event Attributes',
        'parent_item_colon'     => 'Parent Event:',
        'all_items'             => 'All Events',
        'add_new_item'          => 'Add New Event',
        'add_new'               => 'Add New Event',
        'new_item'              => 'New Event',
        'edit_item'             => 'Edit Event',
        'update_item'           => 'Update Event',
        'view_item'             => 'View Event',
        'view_items'            => 'View Events',
        'search_items'          => 'Search Events',
        'not_found'             => 'Not found',
        'not_found_in_trash'    => 'Not found in Trash',
        'featured_image'        => 'Featured Image',
        'set_featured_image'    => 'Set featured image',
        'remove_featured_image' => 'Remove featured image',
        'use_featured_image'    => 'Use as featured image',
        'insert_into_item'      => 'Insert into event',
        'uploaded_to_this_item' => 'Uploaded to this event',
        'items_list'            => 'Events list',
        'items_list_navigation' => 'EVents list navigation',
        'filter_items_list'     => 'Filter events list',
    );
    $args = array(
        'label'                 => 'OLC Events',
        'description'           => 'Event Description',
        'labels'                => $labels,
        'supports'              => array( 'title', 'editor', 'thumbnail' ),
        'taxonomies'            => array( 'olc_event_category' ),
        'hierarchical'          => false,
        'public'                => true,
        'show_ui'               => true,
        'show_in_menu'          => true,
        'show_in_rest'          => true,
        'menu_position'         => 5,
        'show_in_admin_bar'     => true,
        'show_in_nav_menus'     => true,
        'can_export'            => true,
        'has_archive'           => true,
        'exclude_from_search'   => true,
        'publicly_queryable'    => true,
        'capability_type'       => 'post',
    );
    register_post_type( 'olc_events', $args );
}
add_action( 'init', 'register_olc_events', 0 );

/**
 * OLC Event's Custom Taxonomies
 */
function olc_event_custom_taxonomies() {
    $args = array(
        'hierarchical'      => true, // Set to false if you want a non-hierarchical taxonomy like tags
        'labels'            => array(
            'name'              => __('Event Categories', 'open-learning-ex'),
            'singular_name'     => __('Event Category', 'open-learning-ex'),
            'menu_name'         => __('Event Categories', 'open-learning-ex'),
        ),
        'public'            => true,
        'show_admin_column' => true,
        'show_in_rest'      => true,
    );

    register_taxonomy( 'olc_event_category', 'olc_events', $args );

    $args = array(
        'hierarchical'      => false, // Set to false if you want a non-hierarchical taxonomy like tags
        'labels'            => array(
            'name'              => __('Event Tags', 'open-learning-ex'),
            'singular_name'     => __('Event Tag', 'open-learning-ex'),
            'menu_name'         => __('Event Tags', 'open-learning-ex'),
        ),
        'public'            => true,
        'show_admin_column' => false,
        'show_in_rest'      => true,
    );

    register_taxonomy( 'olc_event_tag', 'olc_events', $args );
}
add_action( 'init', 'olc_event_custom_taxonomies' );


/**
 * OLC Event's Admin Custom Table's Columns
 */
// Add custom columns to the admin table
function olc_event_table_columns($columns) {
    // Add your existing columns
    $columns['start_date_time'] = 'Start Date Time';
    $columns['end_date_time'] = 'End Date Time';
    $columns['price'] = 'Price';
    $columns['location'] = 'Location';
    // Add more columns as needed
    
    return $columns;
}
add_filter('manage_olc_events_posts_columns', 'olc_event_table_columns');

// Populate custom column values with ACF data
function olc_event_table_column_values($column, $post_id) {
    switch ($column) {
        case 'start_date_time':
            $start_date_time = function_exists('get_field')? get_field('start_date_time', $post_id) : '';
            echo $start_date_time;
            break;
            
        case 'end_date_time':
            $end_date_time = function_exists('get_field')? get_field('end_date_time', $post_id) : '';
            echo $end_date_time;
            break;
        case 'price':
            $type = function_exists('get_field')? get_field('type', $post_id) : '';
            if(!empty($type) && $type['value'] == 'paid'){
                $price = function_exists('get_field')? get_field('price', $post_id) : '';
                if(function_exists('get_woocommerce_currency_symbol')){
                    echo get_woocommerce_currency_symbol().$price;
                }else{
                    echo '$'.$price;
                }
            }else{
                echo !empty($type)? $type['label'] : '';
            }
            break;
        case 'location':
            $location = function_exists('get_field')? get_field('location', $post_id) : '';
            echo $location;
            break;
        default:
            break;
    }
}
add_action('manage_olc_events_posts_custom_column', 'olc_event_table_column_values', 10, 2);

function olc_event_archive_posts_per_page( $query ) {
    if ( ! is_admin() && $query->is_main_query() && is_post_type_archive( 'olc_events' ) ) {
        $query->set( 'posts_per_page', 10 ); // Replace 10 with the desired number of posts per page
    }
}
add_action( 'pre_get_posts', 'olc_event_archive_posts_per_page' );

/**
 * Save Events As Product
 */
// Hook into the save_post action
// function olc_events_as_product($post_id, $post, $update) {
//     $_event_type = get_field('type', $post_id);
//     $_price = 0;

//     // Check if it's your custom post type
//     if ($post->post_type !== 'olc_events') {
//         return;
//     }
    
//     // Check if WooCommerce is active
//     if (!class_exists('WooCommerce')) {
//         return;
//     }

//     if(isset($_event_type['value']) && $_event_type['value'] == 'paid'){
//         $_price = get_field('price', $post_id);
//     }

//     if( $update ){
//         $_event_product_id = get_field("_event_{$post_id}_product_id", $post_id);
//         if(!empty($_event_product_id)){
//             $data = array(
//                 'ID'            => $_event_product_id,
//                 'post_title'    => $post->post_title,
//                 'post_content'  => $post->post_content,
//                 'post_name'     => $post->post_name,
//             );
              
//             $new_post_id = wp_update_post( $data );
//             if( $new_post_id ){
//                 update_post_meta($_event_product_id, '_price', $_price);
//             }
//         }else{
//             // Create a new WooCommerce product
//             $product_data = array(
//                 'post_title'    => $post->post_title,
//                 'post_content'  => $post->post_content,
//                 'post_name'     => $post->post_name,
//                 'post_status'   => 'publish',
//                 'post_type'     => 'product'
//             );
            
//             // Insert the product into the database
//             $product_id = wp_insert_post($product_data);
            
//             // Update the product meta data
//             if ( $product_id ) {
//                 update_post_meta($post_id, "_event_{$post_id}_product_id", $product_id);
//                 update_post_meta($product_id, '_price', $_price);
//             }
//         }
//     }else{
//         // Create a new WooCommerce product
//         $product_data = array(
//             'post_title'    => $post->post_title,
//             'post_content'  => $post->post_content,
//             'post_name'     => $post->post_name,
//             'post_status'   => 'publish',
//             'post_type'     => 'product'
//         );
        
//         // Insert the product into the database
//         $product_id = wp_insert_post($product_data);
        
//         // Update the product meta data
//         if ( $product_id ) {
//             update_post_meta($post_id, "_event_{$post_id}_product_id", $product_id);
//             update_post_meta($product_id, '_price', $_price);
//         }
//     }
// }
// add_action('save_post', 'olc_events_as_product', 10, 3);



