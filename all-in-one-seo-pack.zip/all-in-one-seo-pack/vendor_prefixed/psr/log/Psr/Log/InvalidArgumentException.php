<?php

namespace AIOSEO\Vendor\Psr\Log;

class InvalidArgumentException extends \InvalidArgumentException
{
}
