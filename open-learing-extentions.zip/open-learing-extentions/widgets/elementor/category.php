<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Category_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;
	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'category';
	}

	/**
	 * Get widget category.
	 *
	 * Retrieve button widget category.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget category.
	 */
	public function get_title() {
		return esc_html__( 'Category', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 9, '', 'style_8');
        $this->text_control('_section_title', 'Section title', 'Popular Categores', array(
            '_style'    => 'style_8'
        ));
        $this->text_control('_section_btn_text', 'Section Button Text', 'View All', array(
            '_style'    => 'style_8'
        ));
        $this->url_control('_section_btn_url', 'Section Button URL', '#', array(
            '_style'    => 'style_8'
        ));
        $this->repeater_controls('category_list', 'Category List', array(
            array(
                'name'  => 'course_category_image',
                'label' => esc_html__( 'Category Image', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::MEDIA,
                'default' => array(
                    'url'   => \Elementor\Utils::get_placeholder_image_src()
                )
            ),
            array(
                'name'  => 'course_category',
                'label' => esc_html__('Course Category', 'open-learning-ex'),
                'type'  => \Elementor\Controls_Manager::SELECT2,
				'multiple'      => false,
				'options'       => $this->get_course_categories()
            ),
            array(
                'name'  => 'course_category_image_style',
                'label' => esc_html__('Course Category Image Style', 'open-learning-ex'),
                'type'  => \Elementor\Controls_Manager::SELECT,
				'multiple'      => false,
				'options'       => [
                    'square'    => 'Square',
                    'rounded-circle'    => 'Rounded Circle',
                ],
                'default'   => 'rounded-circle'
            )
        ), array(
            array(
                'course_category_image' => array(
                    'url'   => \Elementor\Utils::get_placeholder_image_src()
                )
            )
        ));

        $this->switch_control('_switch', null, null, array(
            '_style' => 'style_2' 
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        $this->background_control('_section_backgroun', 'Section Background', '.rbt-categories-area');

        $this->typography_control('_section_title_typo', 'Section title typography', '.rbt-categories-area .section-title .title');
        $this->color_control('_section_title_color', 'Section title color', '.rbt-categories-area .section-title .title');

        $this->typography_control('_section_btn_typo', 'Section Button typography', '.rbt-categories-area .read-more-btn .rbt-btn span');
        $this->color_control('_section_btn_color', 'Section Button color', '.rbt-categories-area .read-more-btn .rbt-btn span');
        $this->background_control('_section_btn_color', 'Section Button Background', '.rbt-categories-area .read-more-btn .rbt-btn');
        $this->add_control(
            '_course_category_box_margin',
            array(
                'name'  => 'course_category_margin',
                'label' => esc_html__( 'Category Thumb Margin', 'open-learning-ex' ),
				'type'  => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'     => [
					'{{WRAPPER}} .rbt-cat-box .inner .thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            )
        );
        $this->background_control('_course_category_box_background', 'Category Box Background', '.rbt-categories-area .rbt-cat-box .inner');
        $this->boxshadow_control('_course_category_box_shadow', 'Category Box Shadow', '.rbt-categories-area .rbt-cat-box .inner');
        $this->color_control('_category_title_color', 'Category Title color', '.rbt-categories-area .rbt-cat-box .content .title');
        $this->color_control('_category_count_color', 'Category Posts Count color', '.rbt-categories-area .rbt-cat-box .content .read-more-btn .rbt-btn-link');


        $this->end_controls_section();
        
    }

    protected function get_course_categories(){
        $course_categories = get_terms(array(
            'taxonomy' 		=> 'course-category',
            'hide_empty'    => false
        ));
        $categories = array('none' => 'None');
        foreach( $course_categories as $cat ){
            $categories[$cat->slug] = $cat->name;
        }

        return $categories;
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

        if( $settings['_style'] == 'style_1' ):
		?>
		<div class="rbt-categories-area bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">CATEGORIES</span>
                            <h2 class="title">Explore Top Courses Caterories <br /> That Change Yourself</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5 mt--20">
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/web-design.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Web Design</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">25 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/design.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Graphic Design</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">30 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/personal.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Personal Development</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">20 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/server.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">IT and Software</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/pantone.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Sales Marketing</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/paint-palette.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Art & Humanities</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/smartphone.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Mobile Application</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 text-center" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="icons">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/infographic.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Finance & Accounting</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): 
            $warrper_class = 'rbt-section-gapTop';
            if( $settings['_switch'] == 'yes' ){
                $warrper_class = 'rbt-section-gapBottom';
            }
        ?>
        <!-- Start category Area  -->
        <div class="rbt-category-area bg-color-white <?php echo esc_attr($warrper_class); ?>">
            <div class="container">
                <?php if( $settings['_switch'] == 'yes' ): ?>
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title"><span class="theme-gradient">Courses</span> Category</h2>
                            <p class="description has-medium-font-size mt--20">Learning new technology, data sience,
                                university, communicate to global world and build a bright future with our histudy.</p>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <div class="row g-5">
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Web Design</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Graphic Design</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a href="course-filter-one-toggle.html" class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/personal-development.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Personal Development</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">IT and Software</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/sales.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Sales Marketing</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/arts.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Art & Humanities</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/mobile.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Mobile Application</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->

                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <a class="rbt-cat-box rbt-cat-box-1 image-overlaping-content on-hover-content-visible" href="course-filter-one-toggle.html">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/finance.jpg" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title">Finance & Accounting</h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link">15 Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->
                </div>
            </div>
        </div>
        <!-- End category Area  -->
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <!-- Start Category Area  -->
        <div class="rbt-category-area bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row g-5">
                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Chemistry</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Graphic Design</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Software</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/mobile.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Mobile App</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/finance.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Finance</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->

                    <!-- Start Service Grid  -->
                    <div class="col-lg-2 col-xl-2 col-xxl-2 col-md-3 col-sm-4 col-6">
                        <div class="service-card service-card-5 variation-2">
                            <div class="inner">
                                <div class="icon">
                                    <a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/arts.jpg" alt="Shape Images"></a>
                                </div>
                                <div class="content">
                                    <h6 class="title"><a href="#">Art & Humanities</a></h6>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Service Grid  -->
                </div>
            </div>
        </div>
        <!-- End Category Area  -->
        <?php elseif( $settings['_style'] == 'style_4' ): ?>
        <div class="rbt-categories-area bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row g-5">
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-5 text-start">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Web Design</a></h5>
                                    <div class="read-more-btn">
                                        <a href="course-filter-one-toggle.html"><i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-5 text-start">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Graphic Design</a></h5>
                                    <div class="read-more-btn">
                                        <a href="course-filter-one-toggle.html"><i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-5 text-start">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/personal-development.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Personal Development</a></h5>
                                    <div class="read-more-btn">
                                        <a href="course-filter-one-toggle.html"><i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-5 text-start">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">IT and Software</a></h5>
                                    <div class="read-more-btn">
                                        <a href="course-filter-one-toggle.html"><i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_5' ): ?>
        <div class="rbt-categories-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity">Course Category</span>
                            <h2 class="title">Let the journey of organizing <br> your own learning begin</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5 mt--30">
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="icons">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/web-design.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Web Design</a></h5>
                                    <div class="read-more-btn">
                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">35 Courses<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="icons">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/graphic-designer.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Graphic Design</a></h5>
                                    <div class="read-more-btn">
                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">20 Courses<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/image/personal-development.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="icons">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/personal.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Personal Development</a></h5>
                                    <div class="read-more-btn">
                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">15 Courses<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/image/software.jpg" alt="Category Images">
                                    </a>
                                </div>
                                <div class="icons">
                                    <img src="<?php echo get_template_directory_uri(); ?>/assets/images/category/server.png" alt="Icons Images">
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">IT and Software</a></h5>
                                    <div class="read-more-btn">
                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">50 Courses<i class="feather-arrow-right"></i></a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                </div>
                <div class="row">
                    <div class="col-lg-12">
                        <div class="read-more-btn text-center mt--40">
                            <a class="rbt-btn btn-border-gradient hover-icon-reverse radius-round btn-md" href="archive.html">
                                <div class="icon-reverse-wrapper">
                                    <span class="btn-text">VIEW ALL CATEGORIES</span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_6' ): ?>
        <div class="rbt-categories-area bg-color-extra2 rbt-section-gap">
            <div class="container">
                <div class="row g-5">
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-3 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Category Images">
                                        <div class="read-more-btn">
                                            <span class="rbt-btn btn-sm btn-white radius-round">20 Courses</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Web Design</a></h5>
                                    <p class="description">Web App Application</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-3 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Category Images">
                                        <div class="read-more-btn">
                                            <span class="rbt-btn btn-sm btn-white radius-round">15 Courses</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Graphic Design</a></h5>
                                    <p class="description">Design is Art</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-3 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/personal-development.jpg" alt="Category Images">
                                        <div class="read-more-btn">
                                            <span class="rbt-btn btn-sm btn-white radius-round">9 Courses</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">Personal Development</a></h5>
                                    <p class="description">Web App Application</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12">
                        <div class="rbt-cat-box rbt-cat-box-1 variation-3 text-center">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Category Images">
                                        <div class="read-more-btn">
                                            <span class="rbt-btn btn-sm btn-white radius-round">15 Courses</span>
                                        </div>
                                    </a>
                                </div>
                                <div class="content">
                                    <h5 class="title"><a href="course-filter-one-toggle.html">IT and Software</a></h5>
                                    <p class="description">Web App Application</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Category Box Layout  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_7' ): ?>
            <script>
                jQuery(document).ready(function(){
                    var swiper = new Swiper('.category-activation-three', {
                        slidesPerView: 1,
                        spaceBetween: 0,
                        loop: true,
                        navigation: {
                            nextEl: '.rbt-arrow-left',
                            prevEl: '.rbt-arrow-right',
                            clickable: true,
                        },
                        scrollbar: {
                            el: '.swiper-scrollbar',
                                draggable: true,
                                hide: true,
                                snapOnRelease: true
                        },
                        breakpoints: {
                            480: {
                            slidesPerView: 1,
                            },
                            481: {
                            slidesPerView: 2,
                            },
                            768: {
                            slidesPerView: 2,
                            },
                            992: {
                            slidesPerView: 3,
                            },
                            1200: {
                            slidesPerView: 4,
                            },
                        },
                    });
                });
            </script>
        <div class="rbt-categories-area bg-color-white rbt-section-gapBottom">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="swiper category-activation-three rbt-arrow-between icon-bg-gray gutter-swiper-30 ptb--20">
                            <div class="swiper-wrapper">

                                <!-- Start Single Category  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                                            <div class="inner">
                                                <div class="thumbnail">
                                                    <a href="course-filter-one-toggle.html">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/web-design.jpg" alt="Category Images">
                                                    </a>
                                                </div>
                                                <div class="icons">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/web-design.png" alt="Icons Images">
                                                </div>
                                                <div class="content">
                                                    <h5 class="title"><a href="course-filter-one-toggle.html">Web Design</a></h5>
                                                    <div class="read-more-btn">
                                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">35 Courses<i class="feather-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category  -->

                                <!-- Start Single Category  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                                            <div class="inner">
                                                <div class="thumbnail">
                                                    <a href="course-filter-one-toggle.html">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/graphic-design.jpg" alt="Category Images">
                                                    </a>
                                                </div>
                                                <div class="icons">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/graphic-designer.png" alt="Icons Images">
                                                </div>
                                                <div class="content">
                                                    <h5 class="title"><a href="course-filter-one-toggle.html">Graphic Design</a></h5>
                                                    <div class="read-more-btn">
                                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">20 Courses<i class="feather-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category  -->

                                <!-- Start Single Category  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                                            <div class="inner">
                                                <div class="thumbnail">
                                                    <a href="course-filter-one-toggle.html">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/personal-development.jpg" alt="Category Images">
                                                    </a>
                                                </div>
                                                <div class="icons">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/personal.png" alt="Icons Images">
                                                </div>
                                                <div class="content">
                                                    <h5 class="title"><a href="course-filter-one-toggle.html">Personal Development</a></h5>
                                                    <div class="read-more-btn">
                                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">15 Courses<i class="feather-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category  -->

                                <!-- Start Single Category  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                                            <div class="inner">
                                                <div class="thumbnail">
                                                    <a href="course-filter-one-toggle.html">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Category Images">
                                                    </a>
                                                </div>
                                                <div class="icons">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/server.png" alt="Icons Images">
                                                </div>
                                                <div class="content">
                                                    <h5 class="title"><a href="course-filter-one-toggle.html">IT and Software</a></h5>
                                                    <div class="read-more-btn">
                                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">50 Courses<i class="feather-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category  -->

                                <!-- Start Single Category  -->
                                <div class="swiper-slide">
                                    <div class="single-slide">
                                        <div class="rbt-cat-box rbt-cat-box-1 variation-2 text-center">
                                            <div class="inner">
                                                <div class="thumbnail">
                                                    <a href="course-filter-one-toggle.html">
                                                        <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/image/software.jpg" alt="Category Images">
                                                    </a>
                                                </div>
                                                <div class="icons">
                                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/category/server.png" alt="Icons Images">
                                                </div>
                                                <div class="content">
                                                    <h5 class="title"><a href="course-filter-one-toggle.html">IT and Software</a></h5>
                                                    <div class="read-more-btn">
                                                        <a class="rbt-btn-link" href="course-filter-one-toggle.html">50 Courses<i class="feather-arrow-right"></i></a>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End Single Category  -->

                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-left">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-left"></i>
                                    <i class="rbt-icon-top feather-arrow-left"></i>
                                </div>
                            </div>

                            <div class="rbt-swiper-arrow rbt-arrow-right">
                                <div class="custom-overfolow">
                                    <i class="rbt-icon feather-arrow-right"></i>
                                    <i class="rbt-icon-top feather-arrow-right"></i>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_8' ): ?>
        <!-- Start Service Area -->
        <div class="rbt-categories-area">
            <div class="container">
                <div class="row g-5 align-items-start mb--30">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title">
                            <h4 class="title"><?php echo esc_html($settings['_section_title']); ?></h4>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="read-more-btn text-start text-md-end">
                            <a class="rbt-btn rbt-switch-btn btn-sm" href="<?php echo esc_url($settings['_section_btn_url']['url']); ?>">
                                <span data-text="<?php echo esc_html($settings['_section_btn_text']); ?>"><?php echo esc_html($settings['_section_btn_text']); ?></span>
                            </a>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <?php
                    
                    if(!empty($settings['_category_list'])):
                    foreach( $settings['_category_list'] as $list_category ): 
                        $course_cat = get_term_by('slug', $list_category['course_category'], 'course-category');
                        $category_link = get_category_link( $course_cat );
                        if($course_cat):
                        $image_style = $list_category['course_category_image_style'];
                    ?>
                    <!-- Start Category Box Layout  -->
                    <div class="col-lg-3 col-md-6 col-sm-6 col-12 <?php echo 'elementor-repeater-item-'.esc_attr($list_category['_id']); ?>">
                        <a class="rbt-cat-box rbt-cat-box-1 list-style" href="<?php echo esc_url( $category_link ); ?>">
                            <div class="inner">
                                <div class="thumbnail">
                                    <img src="<?php echo esc_url($list_category['course_category_image']['url']); ?>" alt="<?php echo \Elementor\Control_Media::get_image_alt($list_category['course_category_image']); ?>" class="<?php echo esc_attr($image_style); ?>">
                                </div>
                                <div class="content">
                                    <h5 class="title"><?php echo esc_html($course_cat->name); ?></h5>
                                    <div class="read-more-btn">
                                        <span class="rbt-btn-link"><?php echo esc_html($course_cat->count); ?> Courses<i class="feather-arrow-right"></i></span>
                                    </div>
                                </div>
                            </div>
                        </a>
                    </div>
                    <!-- End Category Box Layout  -->
                    <?php endif; endforeach; endif; ?>
                </div>

            </div>
        </div>
        <!-- End Service Area -->
        <?php elseif( $settings['_style'] == 'style_9' ): ?>
        <!-- Start Course Category Area  -->
        <div class="rbt-course-category rbt-section-gap overflow-hidden">
            <div class="container">
                <div class="row mb--25">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h5 class="subtitle bg-secondary-opacity">Histudy Feature Category</h5>
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-12 col-lg-12 col-xl-12">
                        <div class="rbt-categori-leftbar">
                            <div class="rbt-categori-list">
                                <a class="blank" href="#"></a>
                                <a href="#">Healthcare</a>
                                <a href="#">Beauty & fashion</a>
                                <a href="#">Education & Travel</a>
                                <a class="blank" href="#"></a>
                            </div>
                            <div class="rbt-categori-list">
                                <a class="blank" href="#"></a>
                                <a href="#">Kitchen</a>
                                <a href="#">Medicle & entertain</a>
                                <a href="#">Medicle & Science</a>
                                <a href="#">Tour & Travel</a>
                                <a class="blank" href="#"></a>
                            </div>
                            <div class="rbt-categori-list">
                                <a class="blank" href="#"></a>
                                <a href="#">Kitchen</a>
                                <a href="#">Featured</a>
                                <a href="#">Popular</a>
                                <a href="#">Latest</a>
                                <a class="blank" href="#"></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Course Category Area  -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Category_Widget() );