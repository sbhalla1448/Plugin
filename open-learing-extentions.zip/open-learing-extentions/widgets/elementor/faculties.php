<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Faculties_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;
	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-faculties';
	}

	/**
	 * Get widget faculties.
	 *
	 * Retrieve button widget faculties.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget faculties.
	 */
	public function get_title() {
		return esc_html__( 'OLC Faculties', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );
        $this->text_control('_section_title', 'Section title', 'Our <span>Faculties</span>', array());
        $this->text_control('_section_sub_title', 'Section subtitle', 'Categores', array());
        $this->repeater_controls('category_list', 'Category List', array(
            array(
                'name'  => 'category_icon',
                'label' => esc_html__( 'Category icon', 'open-learning-ex' ),
                'type'  => \Elementor\Controls_Manager::ICONS,
                'default' => array(
                    'url'   => \Elementor\Utils::get_placeholder_image_src()
                )
            ),
            array(
                'name'  => 'category',
                'label' => esc_html__('Course category', 'open-learning-ex'),
                'type'  => \Elementor\Controls_Manager::SELECT2,
				'multiple'      => false,
				'options'       => $this->get_course_categories()
            ),
        ),array());

        $this->switch_control('_switch', null, null, array(
            '_style' => 'style_2' 
        ));

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);
        $this->background_control('_section_backgroun', 'Section Background', '.rbt-categories-area');

        $this->typography_control('_section_title_typo', 'Section title typography', '.rbt-categories-area .section-title .title');
        $this->color_control('_section_title_color', 'Section title color', '.rbt-categories-area .section-title .title');

        $this->typography_control('_section_btn_typo', 'Section Button typography', '.rbt-categories-area .read-more-btn .rbt-btn span');
        $this->color_control('_section_btn_color', 'Section Button color', '.rbt-categories-area .read-more-btn .rbt-btn span');
        $this->background_control('_section_btn_color', 'Section Button Background', '.rbt-categories-area .read-more-btn .rbt-btn');
        $this->add_control(
            '_course_category_box_margin',
            array(
                'name'  => 'course_category_margin',
                'label' => esc_html__( 'Category Thumb Margin', 'open-learning-ex' ),
				'type'  => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units'    => [ 'px', '%', 'em', 'rem', 'custom' ],
				'selectors'     => [
					'{{WRAPPER}} .rbt-cat-box .inner .thumbnail' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
            )
        );
        $this->background_control('_course_category_box_background', 'Category Box Background', '.rbt-categories-area .rbt-cat-box .inner');
        $this->boxshadow_control('_course_category_box_shadow', 'Category Box Shadow', '.rbt-categories-area .rbt-cat-box .inner');
        $this->color_control('_category_title_color', 'Category Title color', '.rbt-categories-area .rbt-cat-box .content .title');
        $this->color_control('_category_count_color', 'Category Posts Count color', '.rbt-categories-area .rbt-cat-box .content .read-more-btn .rbt-btn-link');


        $this->end_controls_section();
        
    }

    protected function get_course_categories(){
        $course_categories = get_terms(array(
            'taxonomy' 		=> 'course-category',
            'hide_empty'    => false
        ));
        $categories = array('none' => 'None');
        foreach( $course_categories as $cat ){
            $categories[$cat->slug] = $cat->name;
        }

        return $categories;
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
    ?>
    <div class="rbt-faculties-area rbt-section-gap overflow-hidden">
        <div class="wrapper">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-primary-opacity"><?php echo esc_html($settings['_section_sub_title']); ?></span>
                            <h2 class="title"><?php echo wp_kses_post($settings['_section_title']); ?></h2>
                        </div>

                    </div>
                </div>
            </div>
        </div>
        <?php
            $categories_list = $settings['_category_list'];
            if(!empty($categories_list)):
        ?>
        <div class="scroll-animation-wrapper mt--50">
            <div class="scroll-animation scroll-right-left">
                <?php foreach($categories_list as $category_item): 
                    $get_category_by_slug = get_term_by('slug', $category_item['category'], 'course-category'); 
                    $category_name = !empty($get_category_by_slug)? $get_category_by_slug->name : 'No category';   
                    $post_count = !empty($get_category_by_slug)? $get_category_by_slug->count : 0;
                    $term_link = !empty($get_category_by_slug)? get_term_link($get_category_by_slug) : '';
                ?>
                <div class="single-column-20">
                    <a class="rbt-cat-box rbt-cat-box-1 list-style" href="<?php echo esc_url($term_link); ?>">
                        <div class="inner">
                            <div class="thumbnail">
                                <?php \Elementor\Icons_Manager::render_icon($category_item['category_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="content">
                                <h5 class="title"><?php echo esc_html($category_name); ?></h5>
                                <div class="read-more-btn">
                                    <span class="rbt-btn-link"><?php echo esc_html($post_count); ?> Courses<i class="feather-arrow-right"></i></span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php
            $categories_list = $settings['_category_list'];
            if(!empty($categories_list)):
        ?>
        <div class="scroll-animation-wrapper mt--30">
            <div class="scroll-animation scroll-left-right">
                <?php foreach($categories_list as $category_item): 
                    $get_category_by_slug = get_term_by('slug', $category_item['category'], 'course-category'); 
                    $category_name = !empty($get_category_by_slug)? $get_category_by_slug->name : 'No category';   
                    $post_count = !empty($get_category_by_slug)? $get_category_by_slug->count : 0;   
                    $term_link = !empty($get_category_by_slug)? get_term_link($get_category_by_slug) : '';
                ?>
                <div class="single-column-20">
                    <a class="rbt-cat-box rbt-cat-box-1 list-style" href="<?php echo esc_url($term_link); ?>">
                        <div class="inner">
                            <div class="thumbnail">
                                <?php \Elementor\Icons_Manager::render_icon($category_item['category_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="content">
                                <h5 class="title"><?php echo esc_html($category_name); ?></h5>
                                <div class="read-more-btn">
                                    <span class="rbt-btn-link"><?php echo esc_html($post_count); ?> Courses<i class="feather-arrow-right"></i></span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php
            $categories_list = $settings['_category_list'];
            if(!empty($categories_list)):
        ?>
        <div class="scroll-animation-wrapper mt--50">
            <div class="scroll-animation scroll-right-left">
                <?php foreach($categories_list as $category_item): 
                    $get_category_by_slug = get_term_by('slug', $category_item['category'], 'course-category'); 
                    $category_name = !empty($get_category_by_slug)? $get_category_by_slug->name : 'No category';   
                    $post_count = !empty($get_category_by_slug)? $get_category_by_slug->count : 0;  
                    $term_link = !empty($get_category_by_slug)? get_term_link($get_category_by_slug) : '';
                ?>
                <div class="single-column-20">
                    <a class="rbt-cat-box rbt-cat-box-1 list-style" href="<?php echo esc_url($term_link); ?>">
                        <div class="inner">
                            <div class="thumbnail">
                                <?php \Elementor\Icons_Manager::render_icon($category_item['category_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="content">
                                <h5 class="title"><?php echo esc_html($category_name); ?></h5>
                                <div class="read-more-btn">
                                    <span class="rbt-btn-link"><?php echo esc_html($post_count); ?> Courses<i class="feather-arrow-right"></i></span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>

        <?php
            $categories_list = $settings['_category_list'];
            if(!empty($categories_list)):
        ?>
        <div class="scroll-animation-wrapper mt--30">
            <div class="scroll-animation scroll-left-right">
                <?php foreach($categories_list as $category_item): 
                    $get_category_by_slug = get_term_by('slug', $category_item['category'], 'course-category'); 
                    $category_name = !empty($get_category_by_slug)? $get_category_by_slug->name : 'No category';   
                    $post_count = !empty($get_category_by_slug)? $get_category_by_slug->count : 0;   
                    $term_link = !empty($get_category_by_slug)? get_term_link($get_category_by_slug) : '';
                ?>
                <div class="single-column-20">
                    <a class="rbt-cat-box rbt-cat-box-1 list-style" href="<?php echo esc_url($term_link); ?>">
                        <div class="inner">
                            <div class="thumbnail">
                                <?php \Elementor\Icons_Manager::render_icon($category_item['category_icon'], ['aria-hidden' => 'true']); ?>
                            </div>
                            <div class="content">
                                <h5 class="title"><?php echo esc_html($category_name); ?></h5>
                                <div class="read-more-btn">
                                    <span class="rbt-btn-link"><?php echo esc_html($post_count); ?> Courses<i class="feather-arrow-right"></i></span>
                                </div>
                            </div>
                        </div>
                    </a>
                </div>
                <?php endforeach; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
    <?php
	}
}

$widgets_manager->register( new OLX_Faculties_Widget() );