<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Pricing_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'pricing';
	}

	/**
	 * Get widget pricing.
	 *
	 * Retrieve button widget pricing.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget pricing.
	 */
	public function get_title() {
		return esc_html__( 'Pricing', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 3, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <div class="rbt-pricing-area bg-color-light rbt-section-gap">
            <div class="container">
                <div class="row g-5 mb--60">
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="section-title text-start">
                            <span class="subtitle bg-pink-opacity">COURSE PRICING</span>
                            <h2 class="title">Histudy Course Plan</h2>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-6 col-12">
                        <div class="pricing-billing-duration text-start text-md-end">
                            <ul>
                                <li class="nav-item">
                                    <button class="nav-link yearly-plan-btn" type="button">Yearly Plan</button>
                                </li>
                                <li class="nav-item">
                                    <button class="nav-link monthly-plan-btn active" type="button">Monthly Plan</button>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="row gx-0 ">
                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table style-3">
                            <div class="icon-image text-center">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/pricing-icon-01.png" alt="Pricing Image Icons">
                            </div>
                            <div class="pricing-header">
                                <h3 class="title">6 weeks to 12 months</h3>
                                <span class="rbt-badge mb--15">Free for a Month</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$1475</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$12.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li>5 Full Days</li>
                                    <li>7:00 am to 6:00 pm</li>
                                    <li class="off">High Resolution Videos</li>
                                    <li class="off">24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn btn-border radius-round hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->

                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table style-3 active">
                            <div class="icon-image text-center">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/pricing-icon-02.png" alt="Pricing Image Icons">
                            </div>
                            <div class="pricing-header">
                                <h3 class="title">12 months to 24 months</h3>
                                <span class="rbt-badge mb--15">Free for a Month</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$30.99</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$20.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li>8 Full Days</li>
                                    <li>7:00 am to 6:00 pm</li>
                                    <li class="off">High Resolution Videos</li>
                                    <li class="off">24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn btn-gradient radius-round hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->

                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table style-3">
                            <div class="icon-image text-center">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/icons/pricing-icon-03.png" alt="Pricing Image Icons">
                            </div>
                            <div class="pricing-header">
                                <h3 class="title">Pre Primary Community</h3>
                                <span class="rbt-badge mb--15">Free for a Month</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$1245.99</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$30.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li>Pre Primary Community</li>
                                    <li>Kindergarten Community</li>
                                    <li>High Resolution Videos</li>
                                    <li>24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn btn-border radius-round hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->

                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <div class="rbt-pricing-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row g-5 mb--60">
                    <div class="section-title text-center">
                        <h2 class="title">Choose the <span class="theme-gradient">Program</span></h2>
                        <p class="description mt--20">Are You Want to <strong>Change Your Life?</strong></p>
                    </div>
                    <div class="pricing-billing-duration text-center">
                        <ul>
                            <li class="nav-item">
                                <button class="nav-link yearly-plan-btn" type="button">Yearly Plan</button>
                            </li>
                            <li class="nav-item">
                                <button class="nav-link monthly-plan-btn active" type="button">Monthly Plan</button>
                            </li>
                        </ul>
                    </div>
                </div>
                <div class="row g-5">
                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table">
                            <div class="pricing-header">
                                <h3 class="title">Basic Plan</h3>
                                <span class="rbt-badge mb--35">Free for a Month</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$30.99</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$8.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li><i class="feather-check"></i> Unlimited Access Courses</li>
                                    <li><i class="feather-check"></i> Certificate After Completion</li>
                                    <li><i class="feather-check"></i> High Resolution Videos</li>
                                    <li><i class="feather-check"></i> 24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn bg-primary-opacity hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->

                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table active">
                            <div class="pricing-header">
                                <h3 class="title">Standard Plan</h3>
                                <span class="rbt-badge mb--35">Most Popular</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$100.99</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$20.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li><i class="feather-check"></i> Unlimited Access Courses</li>
                                    <li><i class="feather-check"></i> Certificate After Completion</li>
                                    <li><i class="feather-check"></i> High Resolution Videos</li>
                                    <li><i class="feather-check"></i> 24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->

                    <!-- Start Single Pricing  -->
                    <div class="col-xl-4 col-lg-6 col-md-6 col-12">
                        <div class="pricing-table">
                            <div class="pricing-header">
                                <h3 class="title">Exclusive Plan</h3>
                                <span class="rbt-badge mb--35">Free for a Month</span>
                                <div class="price-wrap">
                                    <div class="yearly-pricing" style="display: none;">
                                        <span class="amount">$99.99</span>
                                        <span class="duration">/yearly</span>
                                    </div>
                                    <div class="monthly-pricing" style="display: block;">
                                        <span class="amount">$39.00</span>
                                        <span class="duration">/monthly</span>
                                    </div>
                                </div>
                            </div>
                            <div class="pricing-body">
                                <ul class="list-item">
                                    <li><i class="feather-check"></i> Unlimited Access Courses</li>
                                    <li><i class="feather-check"></i> Certificate After Completion</li>
                                    <li><i class="feather-check"></i> High Resolution Videos</li>
                                    <li><i class="feather-check"></i> 24/7 Dedicated Support</li>
                                </ul>
                            </div>
                            <div class="pricing-btn">
                                <a class="rbt-btn bg-primary-opacity hover-icon-reverse w-100" href="#">
                                    <div class="icon-reverse-wrapper">
                                        <span class="btn-text">Join Course Plan</span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Pricing  -->
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_3' ): ?>
        <div class="rbt-pricing-area bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row g-5 mb--60">
                    <div class="col-12">
                        <div class="section-title text-center">
                            <h2 class="title"><span class="theme-gradient">My</span> Courses Plan</h2>
                            <p class="description has-medium-font-size mt--20">Learning new technology, data sience, university, communicate to global world and build a bright future with our histudy.</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-8 offset-lg-2">
                        <div class="advance-pricing">
                            <div class="inner">
                                <div class="row row--0">
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="pricing-left">
                                            <h3 class="main-title">Active Plan Mode.</h3>
                                            <p class="description">Lorem ipsum dolor sit amet consectetur
                                                adipisicing elit. Nemo, quisquam.</p>
                                            <div class="price-wrapper">
                                                <span class="price-amount">$129<sup>/mo</sup></span>
                                            </div>
                                            <div class="pricing-btn-group">
                                                <button class="rbt-btn btn-gradient w-100">Purchase Now</button>
                                                <button class="rbt-btn btn-border w-100">Upgrade</button>
                                            </div>
                                            <div class="rating">
                                                <a href="#rating">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
                                                    </svg>
                                                </a>
                                                <a href="#rating">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
                                                    </svg>
                                                </a>
                                                <a href="#rating">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
                                                    </svg>
                                                </a>
                                                <a href="#rating">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
                                                    </svg>
                                                </a>
                                                <a href="#rating">
                                                    <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor" class="bi bi-star-fill" viewBox="0 0 16 16">
                                                        <path d="M3.612 15.443c-.386.198-.824-.149-.746-.592l.83-4.73L.173 6.765c-.329-.314-.158-.888.283-.95l4.898-.696L7.538.792c.197-.39.73-.39.927 0l2.184 4.327 4.898.696c.441.062.612.636.282.95l-3.522 3.356.83 4.73c.078.443-.36.79-.746.592L8 13.187l-4.389 2.256z"></path>
                                                    </svg>
                                                </a>
                                            </div>
                                            <small class="subtitle">rated 4.5/5 Stars in 1000+ reviews.</small>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-12">
                                        <div class="pricing-right position-relative">
                                            <div class="pricing-offer">
                                                <div class="single-list">
                                                    <h4 class="price-title">Advance Plans You can Get.</h4>
                                                    <ul class="plan-offer-list">
                                                        <li>
                                                            <i class="feather-check"></i> 5 PPC Campaigns
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Digital Marketing
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Marketing Agency
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Seo Friendly
                                                        </li>
                                                    </ul>
                                                </div>
                                                <div class="single-list mt--40">
                                                    <h4 class="price-title">Basic Plans You can Get.</h4>
                                                    <ul class="plan-offer-list">
                                                        <li>
                                                            <i class="feather-check"></i> 5 PPC Campaigns
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Digital Marketing
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Marketing Agency
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> Seo Friendly
                                                        </li>
                                                        <li>
                                                            <i class="feather-check"></i> App Development
                                                        </li>
                                                        <li class="off">
                                                            <i class="feather-x"></i> 24/7 Dedicated Support
                                                        </li>
                                                    </ul>
                                                </div>
                                            </div>
                                            <div class="pricing-badge"><span>Popular</span></div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Pricing_Widget() );