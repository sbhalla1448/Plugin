<?php
use Stripe\StripeClient;
use Stripe\Stripe;
function olc_checkout_enroll_by_order( $order_id ) {
   $order = wc_get_order( $order_id );
   foreach ( $order->get_items() as $item ) {
      $product_id    = $item->get_product_id();
      $if_has_course = tutor_utils()->product_belongs_with_course( $product_id );
      if ( $if_has_course ) {
         $course_id   = $if_has_course->post_id;
         $customer_id = $order->get_customer_id();
         tutor_utils()->do_enroll( $course_id, $order_id, $customer_id );
      }
   }
}
add_action('woocommerce_api_finalize_enrollment','olc_checkout_finalize_enrollment');
function olc_checkout_finalize_enrollment() {
   $data = json_decode(file_get_contents('php://input'), true);
   update_option('finalize_enrollment',$data);
   $subscription = $data['data']['object'];
   $subscription_id = $subscription['id'];
   $order_id = $subscription['metadata']['order_id'];
   $user_id = $subscription['metadata']['user_id'];
   $event_type = $data['type'];
   if( $event_type == "charge.succeeded" && isset($subscription['metadata']['order_id']) ) {
      $order = wc_get_order( $order_id );
      olc_checkout_enroll_by_order( $order_id );
      $order->update_status('processing');
   }
   if( $event_type == "customer.subscription.created" ) {
      $max_payment_slot = get_post_meta($order_id,'olc_checkout_payment_slot',true);
      $is_cancelled = get_post_meta($order_id,'olc_checkout_cancelled_subscription',true);
      if( !$max_payment_slot ) return;
      // enroll to the course once subscription created
      if( $event_type == "customer.subscription.created" ) {
         $order = wc_get_order( $order_id );
         olc_checkout_enroll_by_order( $order_id );
         $order->update_status('processing');
         update_post_meta($order_id,'olc_checkout_subscription_id', $subscription_id);
      }
      // $payment_done = get_post_meta( $order_id, 'olc_checkout_payment_done', true) ?: 0;
      // $payment_done++;
      // // update payment count
      // update_post_meta( $order_id, 'olc_checkout_payment_done', $payment_done);
   }
   if( $event_type == "invoice.payment_succeeded" ) {
      $sub_id = $subscription['subscription'];
      if( isset($subscription['subscription_details']['metadata']['order_id']) ) {
         $order_id = $subscription['subscription_details']['metadata']['order_id'];
         $is_cancelled = get_post_meta($order_id,'olc_checkout_cancelled_subscription',true);
         if( $is_cancelled ) return;
         $order = wc_get_order( $order_id );
         $max_payment_slot = get_post_meta($order_id,'olc_checkout_payment_slot',true);
         $payment_done = get_post_meta( $order_id, 'olc_checkout_payment_done', true) ?: 0;
         $payment_done++;
         // update payment count
         update_post_meta( $order_id, 'olc_checkout_payment_done', $payment_done);
         if( $payment_done >= $max_payment_slot ) {
            // cancel subscription
            $private_key = get_option('olc_checkout_stripe_private_key');
            $stripe = new \Stripe\StripeClient($private_key);
            $stripe->subscriptions->cancel($sub_id, []);
            update_post_meta($order_id,'olc_checkout_cancelled_subscription',true);
            $order->update_status('completed');
         }
         wp_send_json_success(array(
            'payment_done' => $payment_done,
            'max_payment_slot' => $max_payment_slot,
            'order_id' => $order_id,
            'sub_id' => $sub_id
         ));
      }
      wp_send_json_success(array(
         // 'payment_done' => $payment_done,
         // 'max_payment_slot' => $max_payment_slot,
         'order_id' => $data['subscription_details']['metadata']['order_id'],
         'sub_id' => $sub_id
      ));
   }
   if( $event_type == "customer.subscription.deleted" ) {
      $order = wc_get_order( $order_id );
      $max_payment_slot = get_post_meta($order_id,'olc_checkout_payment_slot',true);
      $payment_done = get_post_meta( $order_id, 'olc_checkout_payment_done', true);
      if( $payment_done < $max_payment_slot ) {
         $order->update_status('cancelled');
         $order->add_order_note('Cancelled after collecting '.$payment_done.' payment(s) among '.$max_payment_slot);
         update_post_meta($order_id,'olc_checkout_cancelled_subscription',true);
         wp_send_json_success(array(
            'payment_done' => $payment_done,
            'max_payment_slot' => $max_payment_slot,
            'order_id' => $order_id
            // 'sub_id' => $sub_id
         ));
      }
   }
   wp_send_json_success($data);
}
add_action('template_redirect','olc_checkout_cart_to_checkout_redirect');
function olc_checkout_cart_to_checkout_redirect(){
   if( is_cart() ) {
      $items = WC()->cart->get_cart();
      if( !empty( $items ) ) {
         wp_redirect(wc_get_checkout_url(), 301);
         die();
      } else { 
         wp_redirect(get_option('olc_checkout_add_more_course') ?: home_url('/'),301);
         die();
      }
   }
}
add_action('woocommerce_before_calculate_totals','olc_checkout_update_price_to_regular_price');
function olc_checkout_update_price_to_regular_price( $cart ){
   if( WC()->session->get('olc_payment_option') != 'pay_monthly' ) return;
   foreach($cart->get_cart() as $cart_item_key => $cart_item ) {
      $product_id = $cart_item['product_id'];
      $product = wc_get_product($product_id);
      $payment_slot = floatval(get_option('olc_checkout_instalment_qty') ?: 5);
      $sub_fee = floatval(get_option('olc_checkout_additional_fee') ?: 0);
      $sale_price = $product->get_sale_price();
      $subscription_fee = ($sale_price * $sub_fee / 100);
      $regular_price = $sale_price + $subscription_fee;
      if( !$regular_price ) {
         $regular_price = $sale_price;
      }
      $cart_item['data']->set_price( $regular_price );
   }
}
function mfht_create_custom_user( $email, $password ) {
   // $exists = username_exists($email);
   // if( $exists ) {
   //    throw new Exception("User already exists with this email");
   // }
   // Create user
   $user_id = wp_create_user( $email, $password, $email );
   if( is_wp_error($user_id) ) {
      throw new Exception( $user_id->get_error_message() );
   }
   // Set user role
   $user = new WP_User( $user_id );
   $user->set_role( 'customer' );

   // Add user meta
   // update_user_meta( $user_id, 'first_name', $first_name );
   // update_user_meta( $user_id, 'last_name', $last_name );
   // update_user_meta( $user_id, 'billing_phone', $phone );
   // update_user_meta( $user_id, 'billing_email', $email);
   // update_user_meta( $user_id, 'billing_address_1', $address );
   // update_user_meta( $user_id, 'billing_city', $city );
   // update_user_meta( $user_id, 'billing_state', $state );
   // update_user_meta( $user_id, 'billing_country', $country );
   // update_user_meta( $user_id, 'billing_postcode', $postcode );
   // Redirect or perform additional actions
   // ...
   return $user_id;
}
// keep the user logged in
function olc_checkout_programmatic_login( $username ) {
   if ( is_user_logged_in() ) {
       wp_logout();
   }
   add_filter( 'authenticate', 'olc_checkout_allow_programmatic_login', 10, 3 );
   $user = wp_signon( array( 'user_login' => $username ) );
   remove_filter( 'authenticate', 'allow_programmatic_login', 10, 3 );

   if ( is_a( $user, 'WP_User' ) ) {
      wp_set_current_user( $user->ID, $user->user_login );

      if ( is_user_logged_in() ) {
         return true;
      }
   }
   return false;
}
function olc_checkout_allow_programmatic_login( $user, $username, $password ) {
   return get_user_by( 'login', $username );
}