<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Tabs_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'tabs';
	}

	/**
	 * Get widget tabs.
	 *
	 * Retrieve button widget tabs.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget tabs.
	 */
	public function get_title() {
		return esc_html__( 'Tabs', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
		<!-- Start Advance Tab  -->
        <div class="rbt-advance-tab-area rbt-section-gapTop bg-color-white">
            <div class="container">
                <div class="row mb--60">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <h2 class="title">About Us.</h2>
                            <p class="description mt--30">Far far away, behind the word mountains, far from the
                                countries Vokalia and Consonantia, there live the blind texts.</p>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <div class="col-lg-4 col-md-12 col-sm-12 col-12 mt_md--30 mt_sm--30 order-2 order-lg-1">
                        <div class="advance-tab-button advance-tab-button-1">
                            <ul class="nav nav-tabs tab-button-list" id="aboutmyTab" role="tablist">
                                <li class="nav-item" role="presentation">
                                    <a href="#" class="nav-link tab-button active" id="home-tab" data-bs-toggle="tab" data-bs-target="#home" role="tab" aria-controls="home" aria-selected="true">
                                        <div class="tab">
                                            <h4 class="title">Histudy Vision.</h4>
                                            <p class="description">Use Doob template you can build a corporate
                                                website a short time.</p>
                                        </div>
                                    </a>
                                </li>

                                <li class="nav-item" role="presentation">
                                    <a href="#" class="nav-link tab-button" id="profile-tab" data-bs-toggle="tab" data-bs-target="#profile" role="tab" aria-controls="profile" aria-selected="false">
                                        <div class="tab">
                                            <h4 class="title">Histudy Mission.</h4>
                                            <p class="description">Use Doob template you can build a corporate
                                                website a short time.</p>
                                        </div>
                                    </a>
                                </li>

                                <li class="nav-item" role="presentation">
                                    <a href="#" class="nav-link tab-button" id="contact-tab" data-bs-toggle="tab" data-bs-target="#contact" role="tab" aria-controls="contact" aria-selected="false">
                                        <div class="tab">
                                            <h4 class="title">Histudy Planning.</h4>
                                            <p class="description">Use Doob template you can build a corporate
                                                website a short time.</p>
                                        </div>
                                    </a>
                                </li>

                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-8 col-md-12 col-sm-12 col-12 order-1 order-lg-2">
                        <div class="tab-content">
                            <div class="tab-pane fade advance-tab-content-1 active show" id="home" role="tabpanel" aria-labelledby="home-tab">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/tab/tabs-03.jpg" alt="advance-tab-image">
                                </div>

                            </div>
                            <div class="tab-pane fade advance-tab-content-1" id="profile" role="tabpanel" aria-labelledby="profile-tab">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/tab/tabs-02.jpg" alt="advance-tab-image">
                                </div>
                            </div>
                            <div class="tab-pane fade advance-tab-content-1" id="contact" role="tabpanel" aria-labelledby="contact-tab">
                                <div class="thumbnail">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/tab/tabs-01.jpg" alt="advance-tab-image">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Advance Tab  -->
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <div class="rbt-advance-tab-area bg-gradient-2 rbt-section-gapTop">
            <div class="container">
                <div class="row mb--40">
                    <div class="col-lg-12">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">University Status</span>
                            <h2 class="title">University Overview.</h2>
                        </div>
                    </div>
                </div>
                <div class="row g-5">
                    <div class="col-lg-10 offset-lg-1">
                        <div class="advance-tab-button">
                            <ul class="nav nav-tabs tab-button-style-2" id="myTab-4" role="tablist">
                                <li role="presentation">
                                    <a href="#" class="tab-button" id="home-tab-4" data-bs-toggle="tab" data-bs-target="#home-4" role="tab" aria-controls="home-4" aria-selected="false">
                                        <span class="title">University History</span>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#" class="tab-button active" id="profile-tab-4" data-bs-toggle="tab" data-bs-target="#profile-4" role="tab" aria-controls="profile-4" aria-selected="true">
                                        <span class="title">Mission</span>
                                    </a>
                                </li>
                                <li role="presentation">
                                    <a href="#" class="tab-button" id="contact-tab-4" data-bs-toggle="tab" data-bs-target="#contact-4" role="tab" aria-controls="contact-4" aria-selected="false">
                                        <span class="title">Campus Info</span>
                                    </a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-lg-10 offset-lg-1">
                        <div class="tab-content advance-tab-content-style-2">
                            <div class="tab-pane fade" id="home-4" role="tabpanel" aria-labelledby="home-tab-4">
                                <div class="content">
                                    <p>University History ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi
                                        doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab
                                        quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade active show" id="profile-4" role="tabpanel" aria-labelledby="profile-tab-4">
                                <div class="content">
                                    <p>Mission ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi doloremque
                                        dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab quisquam cum
                                        numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                            <div class="tab-pane fade" id="contact-4" role="tabpanel" aria-labelledby="contact-tab-4">
                                <div class="content">
                                    <p>Campus Info ipsum dolor sit amet consectetur, adipisicing elit. Tempora sequi
                                        doloremque dicta quia unde odio nam minus reiciendis ullam aliquam, dolorum ab
                                        quisquam cum numquam nemo iure cumque iste. Accusamus necessitatibus.</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row g-5 mt--40">
                    <div class="col-lg-6">
                        <div class="rbt-category-gallery">
                            <div class="thumbnail">
                                <a href="#">
                                    <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-01.jpg" alt="Gallery Images">
                                </a>
                                <div class="rbt-bg-overlay"></div>
                                <div class="hover-content">
                                    <h3 class="title">Education</h3>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="row g-5">
                            <div class="col-lg-12">
                                <div class="rbt-category-gallery">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-02.jpg" alt="Gallery Images">
                                        </a>
                                        <div class="rbt-bg-overlay"></div>
                                        <div class="hover-content">
                                            <h3 class="title">React</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="rbt-category-gallery">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-03.jpg" alt="Gallery Images">
                                        </a>
                                        <div class="rbt-bg-overlay"></div>
                                        <div class="hover-content">
                                            <h3 class="title">Javascript</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-6 col-md-6 col-sm-6 col-12">
                                <div class="rbt-category-gallery">
                                    <div class="thumbnail">
                                        <a href="#">
                                            <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/gallery/gallery-04.jpg" alt="Gallery Images">
                                        </a>
                                        <div class="rbt-bg-overlay"></div>
                                        <div class="hover-content">
                                            <h3 class="title">Vue-Js</h3>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Tabs_Widget() );