<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Brand_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'brand';
	}

	/**
	 * Get widget brand.
	 *
	 * Retrieve button widget brand.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget brand.
	 */
	public function get_title() {
		return esc_html__( 'Brand', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 3, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <div class="rbt-brand-area bg-color-white rbt-section-gap">
            <div class="container">
                <div class="row align-items-center g-5">
                    <div class="col-lg-3">
                        <div class="brand-content-left">
                            <h4 class="mb--0">Trusted by world’s education template</h4>
                        </div>
                    </div>
                    <div class="col-lg-9">
                        <ul class="brand-list brand-style-2 justify-content-center justify-content-lg-between">
                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-01.png" alt="Brand Image"></a></li>
                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-02.png" alt="Brand Image"></a></li>
                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-03.png" alt="Brand Image"></a></li>
                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-04.png" alt="Brand Image"></a></li>
                            <li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-05.png" alt="Brand Image"></a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
		<div class="rbt-brand-area bg-color-white ptb--60">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-10 offset-lg-1">
						<div class="section-title text-center mb--40">
							<span class="small-title w-600">The Best Trasted Client in This Education World</span>
						</div>
						<ul class="brand-list brand-style-3 justify-content-center justify-content-lg-between">
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-01.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-02.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-03.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-05.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-06.png" alt="Brand Image"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<?php elseif( $settings['_style'] == 'style_3' ): ?>
		<!-- Start Brand Area  -->
		<div class="rbt-brand-area bg-color-secondary-alt rbt-section-gap">
			<div class="container">
				<div class="row align-items-center">
					<div class="col-lg-12">
						<div class="section-title text-center mb--40">
							<span class="small-title w-600">The Best Trasted Client in This Education World</span>
						</div>
						<ul class="brand-list brand-style-3 justify-content-center justify-content-lg-between">
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-01.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-02.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-03.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-05.png" alt="Brand Image"></a></li>
							<li><a href="#"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/brand/brand-06.png" alt="Brand Image"></a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
		<!-- End Brand Area  -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Brand_Widget() );