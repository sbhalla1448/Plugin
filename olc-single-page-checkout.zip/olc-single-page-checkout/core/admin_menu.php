<?php
add_action('admin_menu','olc_checkout_admin_menu');
function olc_checkout_admin_menu(){
   add_options_page('OLC checkout settings', 'OLC checkout settings', 'manage_options', 'olc_checkout_settings', 'olc_checkout_admin_menu_callback');
}
function olc_checkout_admin_menu_callback(){
   ?>
   <h1>OLC checkout settings</h1>
   <?php
   if( isset($_POST['save_settings']) ) {
      $pub_key = sanitize_text_field( $_POST['olc_checkout_stripe_public_key'] );
      update_option('olc_checkout_stripe_public_key', $pub_key);
      $sec_key = sanitize_text_field( $_POST['olc_checkout_stripe_private_key'] );
      update_option('olc_checkout_stripe_private_key', $sec_key);
      $sel_products = sanitize_text_field( $_POST['olc_checkout_upsell_products_list'] );
      update_option( 'olc_checkout_upsell_products_list', $sel_products );
      $olc_checkout_add_more_course = sanitize_text_field( $_POST['olc_checkout_add_more_course'] );
      update_option( 'olc_checkout_add_more_course', $olc_checkout_add_more_course );
      $olc_checkout_checkout_success_url = sanitize_text_field( $_POST['olc_checkout_checkout_success_url'] );
      update_option( 'olc_checkout_checkout_success_url', $olc_checkout_checkout_success_url );
      $olc_checkout_failed_url = sanitize_text_field( $_POST['olc_checkout_failed_url'] );
      update_option( 'olc_checkout_failed_url', $olc_checkout_failed_url );
      $olc_checkout_additional_fee = sanitize_text_field( $_POST['olc_checkout_additional_fee'] );
      update_option( 'olc_checkout_additional_fee', $olc_checkout_additional_fee );
      $olc_checkout_instalment_qty = sanitize_text_field( $_POST['olc_checkout_instalment_qty'] );
      update_option( 'olc_checkout_instalment_qty', $olc_checkout_instalment_qty );
      $olc_checkout_study_pack_stripe_product_name = sanitize_text_field( $_POST['olc_checkout_study_pack_stripe_product_name'] );
      update_option( 'olc_checkout_study_pack_stripe_product_name', $olc_checkout_study_pack_stripe_product_name );
      $olc_checkout_study_pack_delivery_fee = sanitize_text_field( $_POST['olc_checkout_study_pack_delivery_fee'] );
      update_option( 'olc_checkout_study_pack_delivery_fee', $olc_checkout_study_pack_delivery_fee );
      $olc_checkout_get_address_api_key = sanitize_text_field( $_POST['olc_checkout_get_address_api_key'] );
      update_option( 'olc_checkout_get_address_api_key', $olc_checkout_get_address_api_key );
      printf('<div class="notice notice-success is-dismissible"><p>%s</p></div>',__('Settings has been saved.','olc_checkout'));
   }
   ?>
   <table class="form-table">
      <form action="" method="post">
         <tr>
            <th>Stripe public key</th>
            <td>
               <input type="text" name="olc_checkout_stripe_public_key" id="" value="<?php echo get_option('olc_checkout_stripe_public_key'); ?>">
            </td>
         </tr>
         <tr>
            <th>Stripe secret key</th>
            <td>
               <input type="password" name="olc_checkout_stripe_private_key" id="" value="<?php echo get_option('olc_checkout_stripe_private_key'); ?>">
            </td>
         </tr>
         <tr>
            <th>Get Address API Key</th>
            <td>
               <input type="text" name="olc_checkout_get_address_api_key" id="" value="<?php echo get_option('olc_checkout_get_address_api_key'); ?>">
            </td>
         </tr>
         <tr>
            <th>Add more course page url</th>
            <td>
               <input type="text" name="olc_checkout_add_more_course" id="" value="<?php echo get_option('olc_checkout_add_more_course'); ?>">
            </td>
         </tr>
         <tr>
            <th>Checkout success url</th>
            <td>
               <input type="text" name="olc_checkout_checkout_success_url" id="" value="<?php echo get_option('olc_checkout_checkout_success_url'); ?>">
            </td>
         </tr>
         <tr>
            <th>Checkout failed url</th>
            <td>
               <input type="text" name="olc_checkout_failed_url" id="" value="<?php echo get_option('olc_checkout_failed_url'); ?>">
            </td>
         </tr>
         <tr>
            <th>Additional fee for monthly payment (%)</th>
            <td>
               <input type="number" name="olc_checkout_additional_fee" id="" value="<?php echo get_option('olc_checkout_additional_fee'); ?>">
            </td>
         </tr>
         <tr>
            <th>Number of subscription for monthly payment</th>
            <td>
               <input type="number" name="olc_checkout_instalment_qty" id="" value="<?php echo get_option('olc_checkout_instalment_qty'); ?>">
            </td>
         </tr>
         <tr>
            <th>Study pack delivery fee label</th>
            <td>
               <input type="text" placeholder="Study pack delivery fee" name="olc_checkout_study_pack_stripe_product_name" id="" value="<?php echo get_option('olc_checkout_study_pack_stripe_product_name'); ?>">
            </td>
         </tr>
         <tr>
            <th>Study pack delivery fee</th>
            <td>
               <input type="number" step="0.01" name="olc_checkout_study_pack_delivery_fee" id="" value="<?php echo get_option('olc_checkout_study_pack_delivery_fee'); ?>">
            </td>
         </tr>
         <tr>
            <th>Checkout upsell products</th>
            <td>
               <select name="olc_checkout_upsell_products" id="olc_checkout_upsell_products" multiple>
                  <?php
                     $products = new WP_Query(array(
                        'post_type' => 'product',
                        'post_status' => 'publish',
                        'posts_per_page' => -1
                     ));
                     if( $products->have_posts() ) {
                        while( $products->have_posts() ) {
                           $products->the_post();
                           printf("<option value='%s'>%s</option>",get_the_ID(), get_the_title());
                        }
                     }
                  ?>
               </select>
               <input type="hidden" name="olc_checkout_upsell_products_list" id="olc_checkout_upsell_products_list" value="<?php echo get_option('olc_checkout_upsell_products_list'); ?>">
            </td>
         </tr>
         <tr>
            <th>
               <input type="submit" value="Save settings" name="save_settings" class="button button-primary">
            </th>
         </tr>
      </form>
   </table>
   <?php
}