<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Mega_Menu_Widget extends OLX_Wc_Base_Widget {
    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'olc-mega-menu';
	}

	/**
	 * Get widget mega-menu.
	 *
	 * Retrieve button widget mega-menu.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget mega-menu.
	 */
	public function get_title() {
		return esc_html__( 'OLC Mega Menu', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->add_control(
			'_category_list',
			[
				'label' => esc_html__( 'Category List', 'open-learning-ex' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
					[
						'name'      => '_cat_thumbnail',
						'label'     => esc_html__( 'Category Thumbnail', 'open-learning-ex' ),
						'type'      => Controls_Manager::MEDIA,
						'default'   => [
                            'url' => \Elementor\Utils::get_placeholder_image_src()
                        ],
						'label_block' => true,
					],
					[
						'name'          => '_cat_name',
						'label'         => esc_html__( 'Category Name', 'open-learning-ex' ),
						'type'          => Controls_Manager::TEXT,
						'default'       => esc_html__( 'Category Name' , 'open-learning-ex' )
					],
					[
						'name'          => '_cat_link',
						'label'         => esc_html__( 'Category Link', 'open-learning-ex' ),
						'type'          => Controls_Manager::URL,
                        'placeholder'   => esc_html__( 'https://your-link.com', 'open-learning-ex' ),
                        'options'       => [ 'url', 'is_external', 'nofollow', 'custom_attributes' ],
                        'default'       => [
                            'url' => '#',
                            'is_external' => true,
                            'nofollow' => true,
                            'custom_attributes' => '',
                        ],
                        'label_block'   => true
					]
                ],
                'default' => [
                    [
                        '_cat_thumbnail' => [
                            'url' => get_parent_theme_file_uri() ."/assets/images/splash/demo/coming-soon-1.png"
                        ],
                        '_cat_name' => esc_html__('Comming Soon 1', 'open-learning-ex'),
                        '_cat_link' => [
                            'url' => '#'
                        ],
                    ],
                    [
                        '_cat_thumbnail' => [
                            'url' => get_parent_theme_file_uri() ."/assets/images/splash/demo/coming-soon-2.png"
                        ],
                        '_cat_name' => esc_html__('Comming Soon 2', 'open-learning-ex'),
                        '_cat_link' => [
                            'url' => '#'
                        ],
                    ],
                    [
                        '_cat_thumbnail' => [
                            'url' => get_parent_theme_file_uri() ."/assets/images/splash/demo/coming-soon-3.png"
                        ],
                        '_cat_name' => esc_html__('Comming Soon 3', 'open-learning-ex'),
                        '_cat_link' => [
                            'url' => '#'
                        ],
                    ],
                ],
				'title_field' => '{{{ _cat_name }}}',
                'condition'   => [
                    '_style' => 'style_1'
                ]
			]
		);

        $this->add_control(
			'_mega_menu_items',
			[
				'label' => esc_html__( 'Mega Menu Items', 'open-learning-ex' ),
				'type' => Controls_Manager::REPEATER,
				'fields' => [
                    [
						'name'          => '_item_title',
						'label'         => esc_html__( 'Menu Title', 'open-learning-ex' ),
						'type'          => Controls_Manager::TEXT,
                        'default'       => 'Get Started'
					],
					[
						'name'          => '_item_menu',
						'label'         => esc_html__( 'Select menu', 'open-learning-ex' ),
						'type'          => Controls_Manager::SELECT2,
                        'options'       => $this->get_menus(),
                        'label_block'   => true
					]
                ],
                'default' => [

                ],
				'title_field' => '{{{ _item_title }}}',
                'condition'   => [
                    '_style' => 'style_2'
                ]
			]
		);

        $this->end_controls_section();
    }

    protected function get_menus(){
        $menus = wp_get_nav_menus();
        $menus_array = array();
        if(!empty($menus)){
            foreach( $menus as $menu ){
                $menus_array[$menu->slug] = $menu->name;
            }

            return $menus_array;
        }

        return $menus_array;
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();
        if( $settings['_style'] == 'style_1' ):
		?>
        <!-- Start Mega Menu  -->
        <div class="rbt-megamenu menu-skin-dark">
            <div class="wrapper">
                <?php if( $settings['_category_list']): ?>
                <div class="row row--15 home-plesentation-wrapper single-dropdown-menu-presentation">
                    <?php foreach( $settings['_category_list'] as $item ): 
                        if ( ! empty( $item['_cat_link']['url'] ) ) {
                            $this->add_link_attributes( '_cat_link', $item['_cat_link'], true );
                        }
                    ?>
                    <!-- Start Single Demo  -->
                    <div class="col-lg-12 col-xl-2 col-xxl-2 col-md-12 col-sm-12 col-12 single-mega-item coming-soon">
                        <div class="demo-single">
                            <div class="inner">
                                <div class="thumbnail">
                                    <a <?php echo $this->get_render_attribute_string( '_cat_link' ); ?>><img
                                            src="<?php echo esc_url($item['_cat_thumbnail']['url']); ?>"
                                            alt="Demo Images">
                                    </a>
                                </div>
                                <div class="content">
                                    <h4 class="title">
                                        <a <?php echo $this->get_render_attribute_string( '_cat_link' ); ?>>
                                            <?php echo esc_html($item['_cat_name']); ?>
                                            <span class="btn-icon"><i class="feather-arrow-right"></i></span>
                                        </a>
                                    </h4>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- End Single Demo  -->
                    <?php endforeach; ?>
                </div>
                <?php endif; ?>

                <div class="load-demo-btn text-center">
                    <a class="rbt-btn-link color-white" href="#">Scroll to view more <svg
                            xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-arrow-down-up" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M11.5 15a.5.5 0 0 0 .5-.5V2.707l3.146 3.147a.5.5 0 0 0 .708-.708l-4-4a.5.5 0 0 0-.708 0l-4 4a.5.5 0 1 0 .708.708L11 2.707V14.5a.5.5 0 0 0 .5.5zm-7-14a.5.5 0 0 1 .5.5v11.793l3.146-3.147a.5.5 0 0 1 .708.708l-4 4a.5.5 0 0 1-.708 0l-4-4a.5.5 0 0 1 .708-.708L4 13.293V1.5a.5.5 0 0 1 .5-.5z" />
                        </svg></a>
                </div>
            </div>
        </div>
        <!-- End Mega Menu  -->
        
        <?php elseif( $settings['_style'] == 'style_2' ): ?>
        <!-- Start Mega Menu  -->
        <div class="rbt-megamenu grid-item-4">
            <div class="wrapper">
                
                <div class="row row--15">
                    <?php if( $settings['_mega_menu_items'] ): 
                        
                        foreach( $settings['_mega_menu_items'] as $item ):
                             
                    ?>
                    <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                        <h3 class="rbt-short-title"><?php echo esc_html($item['_item_title']); ?></h3>
                        <?php
                        wp_nav_menu( array(
                            'menu' => $item['_item_menu'],
                            'menu_class' => 'mega-menu-item', // Replace with your menu class
                            'container' => 'ul', // Replace with your desired HTML element
                            'container_class' => 'my-menu-container', // Replace with your desired container class
                        ));
                        ?>
                    </div>
                    <?php 
                        endforeach;
                    endif; 
                    ?>

                    <div class="col-lg-12 col-xl-3 col-xxl-3 single-mega-item">
                        <div class="mega-category-item">
                            <!-- Start Single Category  -->
                            <div class="nav-category-item">
                                <div class="thumbnail">
                                    <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/category-2.png" alt="Course images"></div>
                                    <a href="course-filter-one-toggle.html">
                                        <span>Online Education</span>
                                        <i class="feather-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- End Single Category  -->

                            <!-- Start Single Category  -->
                            <div class="nav-category-item">
                                <div class="thumbnail">
                                    <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/category-1.png" alt="Course images"></div>
                                    <a href="course-filter-one-toggle.html">
                                        <span>Language Club</span>
                                        <i class="feather-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- End Single Category  -->

                            <!-- Start Single Category  -->
                            <div class="nav-category-item">
                                <div class="thumbnail">
                                    <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/category-4.png" alt="Course images"></div>
                                    <a href="course-filter-one-toggle.html">
                                        <span>University Status</span>
                                        <i class="feather-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- End Single Category  -->

                            <!-- Start Single Category  -->
                            <div class="nav-category-item">
                                <div class="thumbnail">
                                    <a href="course-filter-one-toggle.html">
                                        <span>Course School</span>
                                        <i class="feather-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- End Single Category  -->

                            <!-- Start Single Category  -->
                            <div class="nav-category-item">
                                <div class="thumbnail">
                                    <div class="image"><img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/course/category-9.png" alt="Course images"></div>
                                    <a href="course-filter-one-toggle.html">
                                        <span>Academy</span>
                                        <i class="feather-chevron-right"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- End Single Category  -->

                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Mega Menu  -->
		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Mega_Menu_Widget() );