<?php
namespace Elementor\Widgets\Traits;

use Elementor\Controls_Manager;
use Elementor\Widget_Base;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

trait OLX_Widget_Controls_Traits {
	/**
	 * Get button sizes.
	 *
	 * Retrieve an array of button sizes for the button widget.
	 *
	 * @since 3.4.0
	 * @access public
	 * @static
	 *
	 * @return array An array containing button sizes.
	 */
	public static function get_styles( $limit  ) {
		$style = array(
			'style_1' => esc_html__( 'Style 1', 'open-learning-ex' ),
			'style_2' => esc_html__( 'Style 2', 'open-learning-ex' ),
			'style_3' => esc_html__( 'Style 3', 'open-learning-ex' ),
			'style_4' => esc_html__( 'Style 4', 'open-learning-ex' ),
			'style_5' => esc_html__( 'Style 5', 'open-learning-ex' ),
			'style_6' => esc_html__( 'Style 6', 'open-learning-ex' ),
			'style_7' => esc_html__( 'Style 7', 'open-learning-ex' ),
			'style_8' => esc_html__( 'Style 8', 'open-learning-ex' ),
			'style_9' => esc_html__( 'Style 9', 'open-learning-ex' ),
			'style_10' => esc_html__( 'Style 10', 'open-learning-ex' ),
			'style_11' => esc_html__( 'Style 11', 'open-learning-ex' ),
			'style_12' => esc_html__( 'Style 12', 'open-learning-ex' ),
			'style_13' => esc_html__( 'Style 13', 'open-learning-ex' ),
			'style_14' => esc_html__( 'Style 14', 'open-learning-ex' ),
			'style_15' => esc_html__( 'Style 15', 'open-learning-ex' ),
			'style_16' => esc_html__( 'Style 16', 'open-learning-ex' ),
		);


		if( $limit >= 2 ){
			$number_of_styles = array();
			for( $i = 1; $i <= $limit; $i++ ){
				$number_of_styles['style_' . $i] =  esc_html__( 'Style ' .$i, 'open-learning-ex' );
			}
			return $number_of_styles;
		}

		return $style;
	}

    protected function style_controls( $id = 'style', $label = 'Style', $limit = 2, $condition = '', $default = 'style_3'){
        $this->add_control(
			'_' .$id,
			[
				'label' 	=> esc_html__( $label, 'open-learning-ex' ),
				'type' 		=> \Elementor\Controls_Manager::SELECT,
				'default' 	=> $default,
				'options' 	=> self::get_styles($limit),
				'condition' => $condition
			]
		);
    }

	protected function repeater_controls( $id = 'repeater', $label = 'Repeater List', $fields = array(), $default = array() ){
		$repeater = new \Elementor\Repeater();
		if(!empty($fields)):
			foreach( $fields as $field ){
				if( isset($field['group']) ){
					$repeater->add_group_control($field['group'], $field['args']);
				}else{
					$repeater->add_control($field['name'], $field);
				}
			}
		endif;
		$this->add_control(
			'_' . $id,
			[
				'label' 	=> esc_html__( $label, 'open-learning-ex' ),
				'type' 		=> \Elementor\Controls_Manager::REPEATER,
				'fields' 	=> $repeater->get_controls(),
				'default' 	=> $default
			]
		);
	}

	protected function bg_controls( $id = '_bg', $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( 'Choose Background', 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::SELECT,
				'default' 		=> 'bg-color-white',
				'options' 		=> array(
					'bg-color-white' 	=> esc_html__( 'White', 'open-learning-ex' ),
					'bg-gradient-1' 	=> esc_html__( 'Gradient', 'open-learning-ex' ),
				),
				'condition' 	=> $condition
			]
		);
    }

	protected function switch_control( $id = '_switch', $label = 'Show Title', $default = 'yes', $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::SWITCHER,
				'label_on' 		=> esc_html__( 'Show', 'open-learning-ex' ),
				'label_off' 	=> esc_html__( 'Hide', 'open-learning-ex' ),
				'return_value' 	=> 'yes',
				'default' 		=> $default,
				'condition' 	=> $condition
			]
		);
    }

	protected function text_control( $id = '_text', $label = 'Label', $default = 'Creating A Community Of <br /> Life Long Learners.', $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::TEXT,
				'rows' 			=> 10,
				'default' 		=> wp_kses_post( $default ),
				'placeholder' 	=> esc_html__( 'Type your text here', 'open-learning-ex' ),
				'condition' 	=> $condition
			]
		);
    }

	protected function number_control( $id = '_text', $label = 'Label', $default = 0, $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::NUMBER,
				'rows' 			=> 10,
				'default' 		=> esc_html($default),
				'condition' 	=> $condition
			]
		);
    }

	protected function textarea_control( $id = '_text', $label = 'Label', $default = 'Creating A Community Of <br /> Life Long Learners.', $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::TEXTAREA,
				'rows' 			=> 10,
				'default' 		=> wp_kses_post( $default ),
				'placeholder' 	=> esc_html__( 'Type your text here', 'open-learning-ex' ),
				'condition' 	=> $condition
			]
		);
    }

	protected function editor_control( $id = '_editor', $label = 'Label', $default = 'Creating A Community Of <br /> Life Long Learners.', $condition = '' ){
        $this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::WYSIWYG,
				'rows' 			=> 10,
				'default' 		=> wp_kses_post( $default ),
				'placeholder' 	=> esc_html__( 'Type your text here', 'open-learning-ex' ),
				'condition' 	=> $condition
			]
		);
    }

	protected function image_control( $id = '_image', $label = 'Choose Image', $condition = '' ){
		$this->add_control(
			$id,
			[
				'label' 		=> esc_html__( $label, 'open-learning-ex' ),
				'type' 			=> \Elementor\Controls_Manager::MEDIA,
				'default' 		=> [
					'url' 	=> \Elementor\Utils::get_placeholder_image_src(),
				],
				'condition' 	=> $condition
			]
		);
    }

	protected function url_control( $id = '_url', $label = 'Label', $default = '#', $condition = '' ){
		$this->add_control(
			$id,
			[
				'label' => esc_html__( $label, 'open-learning-ex' ),
				'type' => \Elementor\Controls_Manager::URL,
				'placeholder' => esc_html__( 'https://your-link.com', 'open-learning-ex' ),
				'options' => [ 'url', 'is_external', 'nofollow' ],
				'default' => [
					'url' => $default,
					'is_external' => true,
					'nofollow' => true
				],
				'label_block' => true,
				'condition' 	=> $condition
			]
		);
	}

	protected function color_control( $id = '_color', $label = 'Label', $selectors = '.your-class'){
		$this->add_control(
			$id,
			[
				'label' => esc_html__( $label, 'open-learning-ex' ),
				'type' => \Elementor\Controls_Manager::COLOR,
				'selectors' => [
					'{{ WRAPPER }} '.$selectors => 'color: {{VALUE}}',
				],
			]
		);
	}

	protected function typography_control( $id = '_typography', $label = 'Label', $selectors = '.your-class'){
		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			[
				'label' => esc_html__( $label, 'open-learning-ex' ),
				'name' => $id,
				'selector' => '{{WRAPPER}} '.$selectors,
			]
		);
	}

	protected function background_control( $id = '_background', $label = 'Label', $selectors = '.your-class'){
		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			[
				'label' => esc_html__( $label, 'open-learning-ex' ),
				'name' => $id,
				'selector' => '{{WRAPPER}} '.$selectors,
			]
		);
	}

	protected function boxshadow_control($id = '_box_shadow', $label = 'Label', $selectors = '.your-class'){
		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			[
				'name' => $id,
				'selector' => '{{WRAPPER}} '.$selectors,
			]
		);
	}
}
