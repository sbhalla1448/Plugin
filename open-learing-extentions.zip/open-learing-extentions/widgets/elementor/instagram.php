<?php

namespace Elementor;


use Elementor\Controls_Manager;
use Elementor\Plugin;
use Elementor\Widgets\Traits\OLX_Widget_Controls_Traits;

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

/**
 * Elementor button widget.
 *
 * Elementor widget that displays a button with the ability to control every
 * aspect of the button design.
 *
 * @since 1.0.0
 */
class OLX_Instagram_Widget extends OLX_Wc_Base_Widget {

    use OLX_Widget_Controls_Traits;

	/**
	 * Get widget name.
	 *
	 * Retrieve button widget name.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget name.
	 */
	public function get_name() {
		return 'instagram';
	}

	/**
	 * Get widget instagram.
	 *
	 * Retrieve button widget instagram.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget instagram.
	 */
	public function get_title() {
		return esc_html__( 'Instagram', 'open-learning-ex' );
	}

	/**
	 * Get widget icon.
	 *
	 * Retrieve button widget icon.
	 *
	 * @since 1.0.0
	 * @access public
	 *
	 * @return string Widget icon.
	 */
	public function get_icon() {
		return 'eicon-button';
	}

	protected function register_controls() {

		$this->register_content_controls();
        $this->register_style_controls();

	}


    protected function register_content_controls(){
        $this->start_controls_section(
            'section_content',
            [
                'label' => esc_html__('Content Controls', 'open-learning-ex'),
            ]
        );

        $this->style_controls('style', 'Style', 2, '');

        $this->end_controls_section();
    }

    protected function register_style_controls(){

        $this->start_controls_section(
			'section_style',
			[
				'label' => esc_html__( 'Style Controls', 'open-learning-ex' ),
				'tab' => \Elementor\Controls_Manager::TAB_STYLE,
			]
		);


        $this->end_controls_section();
        
    }

	

	/**
	 * Render button widget output on the frontend.
	 *
	 * Written in PHP and used to generate the final HTML.
	 *
	 * @since 1.0.0
	 * @access protected
	 */
	protected function render() {

        $settings   = $this->get_settings_for_display();

		?>
        <?php if( $settings['_style'] == 'style_1' ): ?>
        <div class="rbt-instagram-area bg-color-white rbt-section-gapTop">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12 mb--60">
                        <div class="section-title text-center">
                            <span class="subtitle bg-secondary-opacity">Instagram</span>
                            <h2 class="title">Follow Histudy On <span class="color-primary">Instagram</span></h2>
                        </div>
                    </div>
                </div>
            </div>
            <div class="container-fluid">
                <div class="row g-3">
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-01.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-02.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-03.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-04.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-05.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-2 col-md-4 col-sm-6 col-6">
                        <div class="instagram-grid">
                            <a href="#">
                                <img src="<?php echo get_parent_theme_file_uri(); ?>/assets/images/instagram/instagram-06.jpg" alt="instagram">
                                <span class="user-info">
                            <span class="icon"><i class="icon-instagram"></i></span>
                                <span class="user-name">@Histudy</span>
                                </span>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php elseif( $settings['_style'] == 'style_2' ): ?>

		<?php
        endif;
	}
}

$widgets_manager->register( new OLX_Instagram_Widget() );